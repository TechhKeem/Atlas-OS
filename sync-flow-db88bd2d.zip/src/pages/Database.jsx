import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import DatabaseHeader from "../components/database/DatabaseHeader";
import DatabaseTable from "../components/database/DatabaseTable";
import RecordModal from "../components/database/RecordModal";
import FilterModal from "../components/database/FilterModal";
import FieldsModal from "../components/database/FieldsModal";
import SaveViewModal from "../components/database/SaveViewModal";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2, CheckCircle, ChevronDown, ChevronRight } from "lucide-react";
import { format, startOfWeek, startOfMonth, startOfYear, getYear, getMonth, getWeek } from "date-fns";

export default function DatabasePage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [activeView, setActiveView] = useState(null);
  const [sortField, setSortField] = useState("created_date");
  const [sortDirection, setSortDirection] = useState("desc");
  const [filters, setFilters] = useState([]);
  const [filterOperator, setFilterOperator] = useState("and");
  const [visibleFields, setVisibleFields] = useState([]);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [isFieldsModalOpen, setIsFieldsModalOpen] = useState(false);
  const [isSaveViewModalOpen, setIsSaveViewModalOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [bulkStatusValue, setBulkStatusValue] = useState("");
  const [groupBy, setGroupBy] = useState(null);
  const [groupByType, setGroupByType] = useState("month");
  const [expandedGroups, setExpandedGroups] = useState(new Set());
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = React.useRef(null);

  const queryClient = useQueryClient();

  const { data: records = [], isLoading } = useQuery({
    queryKey: ["database-records"],
    queryFn: () => base44.entities.DatabaseRecord.list("-created_date")
  });

  const { data: views = [] } = useQuery({
    queryKey: ["database-views"],
    queryFn: async () => {
      const viewsList = await base44.entities.DatabaseView.list();
      if (viewsList.length === 0) {
        // Create default views
        const allRecords = await base44.entities.DatabaseView.create({
          name: "All Records",
          type: "table",
          is_default: true
        });
        const byStatus = await base44.entities.DatabaseView.create({
          name: "By Status",
          type: "table",
          group_by: "status"
        });
        return [allRecords, byStatus];
      }
      return viewsList;
    }
  });

  const { data: fields = [] } = useQuery({
    queryKey: ["database-fields"],
    queryFn: () => base44.entities.DatabaseField.list("order")
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.DatabaseRecord.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-records"] });
      setIsModalOpen(false);
      setSelectedRecord(null);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.DatabaseRecord.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-records"] });
      setIsModalOpen(false);
      setSelectedRecord(null);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.DatabaseRecord.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-records"] });
      setIsModalOpen(false);
      setSelectedRecord(null);
    }
  });

  const bulkDeleteMutation = useMutation({
    mutationFn: async (ids) => {
      await Promise.all(Array.from(ids).map(id => base44.entities.DatabaseRecord.delete(id)));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-records"] });
      setSelectedIds(new Set());
    }
  });

  const bulkUpdateStatusMutation = useMutation({
    mutationFn: async ({ ids, status }) => {
      await Promise.all(Array.from(ids).map(id => base44.entities.DatabaseRecord.update(id, { status })));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-records"] });
      setSelectedIds(new Set());
      setBulkStatusValue("");
    }
  });

  const saveViewMutation = useMutation({
    mutationFn: ({ id, data }) => {
      if (id) {
        return base44.entities.DatabaseView.update(id, data);
      }
      return base44.entities.DatabaseView.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-views"] });
    }
  });

  const deleteViewMutation = useMutation({
    mutationFn: (id) => base44.entities.DatabaseView.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-views"] });
      setActiveView(null);
    }
  });

  const handleCreateRecord = () => {
    setSelectedRecord(null);
    setIsModalOpen(true);
  };

  const handleRecordClick = (record) => {
    setSelectedRecord(record);
    setIsModalOpen(true);
  };

  const handleSaveRecord = (recordData) => {
    if (recordData.id) {
      const { id, created_date, updated_date, created_by, ...data } = recordData;
      updateMutation.mutate({ id, data });
    } else {
      const { created_date, updated_date, created_by, ...data } = recordData;
      createMutation.mutate(data);
    }
  };

  const handleDeleteRecord = (id) => {
    deleteMutation.mutate(id);
  };

  const handleSaveView = (viewName, isDefault) => {
    const viewData = {
      name: viewName,
      type: activeView?.type || "table",
      filters: filters,
      filter_operator: filterOperator,
      sorts: sortField ? [{ field: sortField, direction: sortDirection }] : [],
      visible_fields: visibleFields,
      group_by: groupBy,
      is_default: isDefault
    };

    if (activeView && !activeView.is_default) {
      saveViewMutation.mutate({ id: activeView.id, data: viewData });
    } else {
      saveViewMutation.mutate({ data: viewData });
    }
  };

  const handleGroupChange = (field, type) => {
    setGroupBy(field);
    setGroupByType(type || "month");
  };

  const toggleGroup = (groupKey) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(groupKey)) {
      newExpanded.delete(groupKey);
    } else {
      newExpanded.add(groupKey);
    }
    setExpandedGroups(newExpanded);
  };

  const handleDeleteView = (id) => {
    if (window.confirm("Are you sure you want to delete this view?")) {
      deleteViewMutation.mutate(id);
    }
  };

  const handleBulkDelete = () => {
    if (selectedIds.size === 0) return;
    if (window.confirm(`Are you sure you want to delete ${selectedIds.size} record(s)?`)) {
      bulkDeleteMutation.mutate(selectedIds);
    }
  };

  const handleBulkStatusChange = () => {
    if (selectedIds.size === 0 || !bulkStatusValue) return;
    bulkUpdateStatusMutation.mutate({ ids: selectedIds, status: bulkStatusValue });
  };

  const handleExport = async () => {
    try {
      const { data } = await base44.functions.invoke('exportDatabase');
      const blob = new Blob([data], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `database_export_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
    } catch (error) {
      alert('Export failed: ' + error.message);
    }
  };

  const handleImport = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(
        `/api/v1/apps/${base44.appId}/functions/importDatabase/invoke`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${await base44.auth.getToken()}`
          },
          body: formData
        }
      );

      const result = await response.json();
      
      if (response.ok) {
        alert(result.message || 'Import successful!');
        queryClient.invalidateQueries({ queryKey: ["database-records"] });
      } else {
        alert('Import failed: ' + (result.error || 'Unknown error'));
      }
    } catch (error) {
      alert('Import failed: ' + error.message);
    } finally {
      setIsImporting(false);
      e.target.value = '';
    }
  };

  // Set default active view
  React.useEffect(() => {
    if (views.length > 0 && !activeView) {
      const defaultView = views.find((v) => v.is_default) || views[0];
      setActiveView(defaultView);
      setFilters(defaultView.filters || []);
      setFilterOperator(defaultView.filter_operator || "and");
      setVisibleFields(defaultView.visible_fields || []);
    }
  }, [views, activeView]);

  // Load view settings when view changes
  React.useEffect(() => {
    if (activeView) {
      setFilters(activeView.filters || []);
      setFilterOperator(activeView.filter_operator || "and");
      setVisibleFields(activeView.visible_fields || []);
      setGroupBy(activeView.group_by || null);
    }
  }, [activeView]);

  // Auto-expand all groups when grouping changes
  React.useEffect(() => {
    if (groupBy) {
      const allGroupKeys = Object.keys(groupedRecords);
      setExpandedGroups(new Set(allGroupKeys));
    }
  }, [groupBy, groupByType]);

  // Filter, sort, and group records
  const processedRecords = React.useMemo(() => {
    let result = records.filter(record => !record.parent_id);

    // Apply view filters
    if (activeView?.filters && activeView.filters.length > 0) {
      result = result.filter(record => {
        return activeView.filters.every(filter => {
          const value = record[filter.field] || record.custom_fields?.[filter.field];
          if (!value) return false;
          
          const filterValue = filter.value.toLowerCase();
          const recordValue = String(value).toLowerCase();
          
          switch (filter.operator) {
            case "equals": return recordValue === filterValue;
            case "contains": return recordValue.includes(filterValue);
            case "not_equals": return recordValue !== filterValue;
            default: return true;
          }
        });
      });
    }

    // Apply manual filters
    if (filters.length > 0) {
      result = result.filter(record => {
        const checkFilter = (filter) => {
          if (!filter.field || !filter.value) return true;
          const value = record[filter.field] || record.custom_fields?.[filter.field];
          if (!value) return false;
          
          const filterValue = filter.value.toLowerCase();
          const recordValue = String(value).toLowerCase();
          
          switch (filter.operator) {
            case "equals": return recordValue === filterValue;
            case "contains": return recordValue.includes(filterValue);
            case "not_equals": return recordValue !== filterValue;
            default: return true;
          }
        };

        if (filterOperator === "or") {
          return filters.some(checkFilter);
        } else {
          return filters.every(checkFilter);
        }
      });
    }

    // Sort
    if (sortField) {
      result.sort((a, b) => {
        let aVal = a[sortField] || a.custom_fields?.[sortField];
        let bVal = b[sortField] || b.custom_fields?.[sortField];
        
        if (!aVal && !bVal) return 0;
        if (!aVal) return 1;
        if (!bVal) return -1;
        
        if (sortField.includes('date')) {
          aVal = new Date(aVal).getTime();
          bVal = new Date(bVal).getTime();
        }
        
        if (typeof aVal === 'string') {
          aVal = aVal.toLowerCase();
          bVal = bVal.toLowerCase();
        }
        
        const comparison = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
        return sortDirection === 'asc' ? comparison : -comparison;
      });
    }

    return result;
  }, [records, activeView, filters, filterOperator, sortField, sortDirection]);

  // Group by field if specified
  const groupedRecords = React.useMemo(() => {
    if (!groupBy) return { "": processedRecords };
    
    const groups = {};
    const field = fields.find(f => f.name === groupBy);
    
    processedRecords.forEach(record => {
      const fieldMapping = {
        'full_name': 'title',
        'phone': 'client_phone',
        'email': 'client_email',
        'appointment_date': 'scheduled_date'
      };
      
      const actualFieldName = fieldMapping[groupBy] || groupBy;
      let groupValue = record[actualFieldName] || record.custom_fields?.[groupBy];
      
      if (!groupValue) {
        groupValue = "Ungrouped";
      } else if (field?.type === "date" && groupByType) {
        const date = new Date(groupValue);
        switch (groupByType) {
          case "year":
            groupValue = format(date, "yyyy");
            break;
          case "month":
            groupValue = format(date, "MMMM yyyy");
            break;
          case "week":
            const weekStart = startOfWeek(date);
            groupValue = `Week of ${format(weekStart, "MMM d, yyyy")}`;
            break;
          case "day":
            groupValue = format(date, "MMMM d, yyyy");
            break;
          default:
            groupValue = format(date, "MMMM yyyy");
        }
      }
      
      if (!groups[groupValue]) groups[groupValue] = [];
      groups[groupValue].push(record);
    });
    
    // Sort groups
    const sortedGroups = {};
    Object.keys(groups).sort((a, b) => {
      if (a === "Ungrouped") return 1;
      if (b === "Ungrouped") return -1;
      return a.localeCompare(b);
    }).forEach(key => {
      sortedGroups[key] = groups[key];
    });
    
    return sortedGroups;
  }, [processedRecords, groupBy, groupByType, fields]);

  return (
    <div className="h-screen flex flex-col bg-white overflow-hidden">
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv"
        onChange={handleFileChange}
        className="hidden"
      />
      <DatabaseHeader
        views={views}
        activeView={activeView}
        onViewChange={setActiveView}
        onCreateRecord={handleCreateRecord}
        onOpenFilter={() => setIsFilterModalOpen(true)}
        onOpenFields={() => setIsFieldsModalOpen(true)}
        onSaveView={() => setIsSaveViewModalOpen(true)}
        onDeleteView={handleDeleteView}
        fields={fields}
        sortField={sortField}
        sortDirection={sortDirection}
        onSortChange={(field, direction) => {
          setSortField(field);
          setSortDirection(direction);
        }}
        hasActiveFilters={filters.length > 0}
        groupBy={groupBy}
        groupByType={groupByType}
        onGroupChange={handleGroupChange}
        onExport={handleExport}
        onImport={handleImport}
      />

      <div className="flex-1 overflow-hidden flex flex-col">
        {selectedIds.size > 0 && (
          <div className="h-14 px-3 md:px-6 border-b border-[#e8e8e8] bg-[#fafafa] flex items-center gap-2 md:gap-4 flex-shrink-0 overflow-x-auto">
            <span className="text-[13px] text-[#666]">
              {selectedIds.size} selected
            </span>
            <div className="flex items-center gap-2">
              <Select value={bulkStatusValue} onValueChange={setBulkStatusValue}>
                <SelectTrigger className="h-9 w-40 rounded-none border-[#e8e8e8]">
                  <SelectValue placeholder="Change status..." />
                </SelectTrigger>
                <SelectContent className="rounded-none">
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="contacted">Contacted</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
              <Button
                size="sm"
                onClick={handleBulkStatusChange}
                disabled={!bulkStatusValue || bulkUpdateStatusMutation.isPending}
                className="h-9 rounded-none bg-[#20242d] hover:bg-[#2d323d]"
              >
                <CheckCircle className="h-4 w-4 mr-1.5" />
                Update Status
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={handleBulkDelete}
                disabled={bulkDeleteMutation.isPending}
                className="h-9 rounded-none"
              >
                <Trash2 className="h-4 w-4 mr-1.5" />
                Delete
              </Button>
            </div>
          </div>
        )}
        
        <div className="flex-1 overflow-hidden">
          {isLoading ? (
            <div className="h-full flex items-center justify-center">
              <div className="w-6 h-6 border-2 border-[#20242d] border-t-transparent animate-spin" />
            </div>
          ) : groupBy ? (
            <div className="flex-1 overflow-auto">
              {Object.entries(groupedRecords).map(([groupName, groupRecords]) => {
                const isExpanded = expandedGroups.has(groupName);
                return (
                  <div key={groupName} className="border-b border-[#e8e8e8]">
                    <button
                      onClick={() => toggleGroup(groupName)}
                      className="w-full px-6 py-3 flex items-center gap-2 hover:bg-[#fafafa] transition-colors text-left"
                    >
                      {isExpanded ? (
                        <ChevronDown className="h-4 w-4 text-[#666]" />
                      ) : (
                        <ChevronRight className="h-4 w-4 text-[#666]" />
                      )}
                      <span className="text-[14px] font-semibold text-[#20242d]">
                        {groupName}
                      </span>
                      <span className="text-[13px] text-[#999]">
                        ({groupRecords.length})
                      </span>
                    </button>
                    {isExpanded && (
                      <div className="border-t border-[#e8e8e8]">
                        <DatabaseTable
                          records={groupRecords}
                          fields={fields}
                          onRecordClick={handleRecordClick}
                          visibleFields={visibleFields}
                          selectedIds={selectedIds}
                          onSelectionChange={setSelectedIds}
                        />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <DatabaseTable
              records={processedRecords}
              fields={fields}
              onRecordClick={handleRecordClick}
              visibleFields={visibleFields}
              selectedIds={selectedIds}
              onSelectionChange={setSelectedIds}
            />
          )}
        </div>
      </div>

      <RecordModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedRecord(null);
        }}
        record={selectedRecord}
        fields={fields}
        onSave={handleSaveRecord}
        onDelete={handleDeleteRecord}
      />

      <FilterModal
        isOpen={isFilterModalOpen}
        onClose={() => setIsFilterModalOpen(false)}
        fields={fields}
        filters={filters}
        filterOperator={filterOperator}
        onFiltersChange={(newFilters, newOperator) => {
          setFilters(newFilters);
          setFilterOperator(newOperator);
        }}
      />

      <SaveViewModal
        isOpen={isSaveViewModalOpen}
        onClose={() => setIsSaveViewModalOpen(false)}
        currentView={activeView}
        onSave={handleSaveView}
      />

      <FieldsModal
        isOpen={isFieldsModalOpen}
        onClose={() => setIsFieldsModalOpen(false)}
        fields={fields}
        visibleFields={visibleFields}
        onVisibleFieldsChange={setVisibleFields}
      />
    </div>
  );
}