import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import FormCard from "../components/forms/FormCard";
import FormModal from "../components/forms/FormModal";

export default function FormsPage({ embedded = false }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedForm, setSelectedForm] = useState(null);
  const { toast } = useToast();

  const queryClient = useQueryClient();

  const { data: forms = [], isLoading } = useQuery({
    queryKey: ["forms"],
    queryFn: () => base44.entities.Form.list("-created_date")
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Form.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["forms"] });
      setIsModalOpen(false);
      setSelectedForm(null);
      toast({ title: "Form created" });
    },
    onError: (error) => {
      toast({
        title: "Error creating form",
        description: error.message || "An unknown error occurred.",
        variant: "destructive",
      });
      console.error("Error creating form:", error);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Form.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["forms"] });
      setIsModalOpen(false);
      setSelectedForm(null);
      toast({ title: "Form updated" });
    },
    onError: (error) => {
      toast({
        title: "Error updating form",
        description: error.message || "An unknown error occurred.",
        variant: "destructive",
      });
      console.error("Error updating form:", error);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Form.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["forms"] });
      toast({ title: "Form deleted" });
    }
  });

  const handleCreate = () => {
    setSelectedForm(null);
    setIsModalOpen(true);
  };

  const handleEdit = (form) => {
    setSelectedForm(form);
    setIsModalOpen(true);
  };

  const handleDelete = (id) => {
    deleteMutation.mutate(id);
  };

  const handleSave = (data) => {
    if (data.id) {
      const { id, created_date, updated_date, created_by, ...updateData } = data;
      updateMutation.mutate({ id, data: updateData });
    } else {
      createMutation.mutate(data);
    }
  };

  const containerClass = embedded 
    ? "flex-1 overflow-auto p-6" 
    : "h-screen flex flex-col bg-[#fafafa]";

  return (
    <div className={containerClass}>
      {!embedded && (
        <div className="flex items-center justify-between h-14 px-6 border-b border-[#e8e8e8] bg-white">
          <h1 className="text-[15px] font-semibold text-[#20242d]">Forms</h1>
          <Button
            onClick={handleCreate}
            className="h-8 px-3 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
          >
            <Plus className="h-4 w-4 mr-1.5" />
            New Form
          </Button>
        </div>
      )}

      <div className={embedded ? "" : "flex-1 overflow-auto p-6"}>
        {embedded && (
          <div className="flex justify-end mb-4">
            <Button
              onClick={handleCreate}
              className="h-8 px-3 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
            >
              <Plus className="h-4 w-4 mr-1.5" />
              New Form
            </Button>
          </div>
        )}

        {isLoading ? (
          <div className="h-64 flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-[#20242d] border-t-transparent animate-spin" />
          </div>
        ) : forms.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center">
            <p className="text-[#666] text-[14px] mb-4">
              No forms yet. Create one to collect information from clients.
            </p>
            <Button
              onClick={handleCreate}
              className="h-9 px-4 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
            >
              <Plus className="h-4 w-4 mr-1.5" />
              Create Form
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {forms.map((form) => (
              <FormCard
                key={form.id}
                form={form}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}
      </div>

      <FormModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedForm(null);
        }}
        form={selectedForm}
        onSave={handleSave}
      />
    </div>
  );
}