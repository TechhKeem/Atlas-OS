import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import BookingPageCard from "../components/booking/BookingPageCard";
import BookingPageModal from "../components/booking/BookingPageModal";
import EmbedModal from "../components/booking/EmbedModal";
import { createPageUrl } from "@/utils";

export default function BookingPagesPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEmbedModalOpen, setIsEmbedModalOpen] = useState(false);
  const [selectedBookingPage, setSelectedBookingPage] = useState(null);
  const { toast } = useToast();

  const queryClient = useQueryClient();

  const { data: bookingPages = [], isLoading } = useQuery({
    queryKey: ["booking-pages"],
    queryFn: () => base44.entities.BookingPage.list("-created_date")
  });

  const { data: forms = [] } = useQuery({
    queryKey: ["forms"],
    queryFn: () => base44.entities.Form.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.BookingPage.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["booking-pages"] });
      setIsModalOpen(false);
      setSelectedBookingPage(null);
      toast({ title: "Booking page created" });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.BookingPage.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["booking-pages"] });
      setIsModalOpen(false);
      setSelectedBookingPage(null);
      toast({ title: "Booking page updated" });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.BookingPage.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["booking-pages"] });
      setIsModalOpen(false);
      setSelectedBookingPage(null);
      toast({ title: "Booking page deleted" });
    }
  });

  const handleCreate = () => {
    setSelectedBookingPage(null);
    setIsModalOpen(true);
  };

  const handleEdit = (bookingPage) => {
    setSelectedBookingPage(bookingPage);
    setIsModalOpen(true);
  };

  const handleCopyLink = (url) => {
    navigator.clipboard.writeText(url);
    toast({ title: "Link copied to clipboard" });
  };

  const handlePreview = (bookingPage) => {
    setSelectedBookingPage(bookingPage);
    setIsEmbedModalOpen(true);
  };

  const handleSave = (data) => {
    if (data.id) {
      const { id, created_date, updated_date, created_by, ...updateData } = data;
      updateMutation.mutate({ id, data: updateData });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleDelete = (id) => {
    deleteMutation.mutate(id);
  };

  return (
    <div className="h-screen flex flex-col bg-[#fafafa]">
      <div className="flex items-center justify-between h-14 px-6 border-b border-[#e8e8e8] bg-white">
        <h1 className="text-[15px] font-semibold text-[#20242d]">Booking Pages</h1>
        <Button
          onClick={handleCreate}
          className="h-8 px-3 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
        >
          <Plus className="h-4 w-4 mr-1.5" />
          New Booking Page
        </Button>
      </div>

      <div className="flex-1 overflow-auto p-6">
        {isLoading ? (
          <div className="h-64 flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-[#20242d] border-t-transparent animate-spin" />
          </div>
        ) : bookingPages.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center">
            <p className="text-[#666] text-[14px] mb-4">
              No booking pages yet. Create one to start accepting bookings.
            </p>
            <Button
              onClick={handleCreate}
              className="h-9 px-4 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
            >
              <Plus className="h-4 w-4 mr-1.5" />
              Create Booking Page
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {bookingPages.map((page) => (
              <BookingPageCard
                key={page.id}
                bookingPage={page}
                onEdit={handleEdit}
                onCopyLink={handleCopyLink}
                onPreview={handlePreview}
              />
            ))}
          </div>
        )}
      </div>

      <BookingPageModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedBookingPage(null);
        }}
        bookingPage={selectedBookingPage}
        forms={forms}
        onSave={handleSave}
        onDelete={handleDelete}
      />

      <EmbedModal
        isOpen={isEmbedModalOpen}
        onClose={() => {
          setIsEmbedModalOpen(false);
          setSelectedBookingPage(null);
        }}
        bookingPage={selectedBookingPage}
      />
    </div>
  );
}