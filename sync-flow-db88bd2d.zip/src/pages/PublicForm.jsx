import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { CheckCircle2 } from "lucide-react";

export default function PublicForm() {
  const [formData, setFormData] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [quizResult, setQuizResult] = useState(null);

  const urlParams = new URLSearchParams(window.location.search);
  const formId = urlParams.get("formId");

  const { data: form, isLoading } = useQuery({
    queryKey: ["form", formId],
    queryFn: async () => {
      const forms = await base44.entities.Form.filter({ id: formId });
      return forms[0];
    },
    enabled: !!formId,
  });

  const submitMutation = useMutation({
    mutationFn: async (data) => {
      // Check if redirect is enabled and store URL
      const shouldRedirect = form.redirect_enabled && form.redirect_url;
      
      // Send email notifications if configured
      if (form.notification_emails && form.notification_emails.length > 0) {
        let emailBody = form.notification_body || "New form submission received.";
        let emailSubject = form.notification_subject || "New Form Submission";
        
        // Replace placeholders with actual form data
        form.fields.forEach(field => {
          const value = data[field.id];
          const placeholder = `{{${field.label}}}`;
          if (emailBody.includes(placeholder)) {
            emailBody = emailBody.replace(new RegExp(placeholder, 'g'), value || '');
          }
          if (emailSubject.includes(placeholder)) {
            emailSubject = emailSubject.replace(new RegExp(placeholder, 'g'), value || '');
          }
        });
        
        // Send to all configured email addresses
        for (const email of form.notification_emails) {
          try {
            await base44.integrations.Core.SendEmail({
              to: email,
              subject: emailSubject,
              body: emailBody
            });
          } catch (error) {
            console.error('Failed to send notification email:', error);
          }
        }
      }
      // Calculate quiz score if in quiz mode
      let totalScore = 0;
      let userScore = 0;

      if (form.quiz_mode) {
        form.fields.forEach(field => {
          const userAnswer = data[field.id];
          
          if (field.type === "select" || field.type === "multiselect") {
            const options = field.options || [];
            if (field.type === "select") {
              const selectedOption = options.find(opt => {
                const optValue = typeof opt === 'string' ? opt : opt.value;
                return optValue === userAnswer;
              });
              if (selectedOption) {
                const score = typeof selectedOption === 'string' ? 0 : (selectedOption.score || 0);
                userScore += score;
                totalScore += Math.max(...options.map(o => typeof o === 'string' ? 0 : (o.score || 0)));
              }
            } else if (field.type === "multiselect" && Array.isArray(userAnswer)) {
              userAnswer.forEach(answer => {
                const selectedOption = options.find(opt => {
                  const optValue = typeof opt === 'string' ? opt : opt.value;
                  return optValue === answer;
                });
                if (selectedOption) {
                  const score = typeof selectedOption === 'string' ? 0 : (selectedOption.score || 0);
                  userScore += score;
                }
              });
              totalScore += options.reduce((sum, o) => sum + (typeof o === 'string' ? 0 : (o.score || 0)), 0);
            }
          } else if (field.correct_answer) {
            totalScore += field.score_if_correct || 1;
            if (String(userAnswer).toLowerCase().trim() === String(field.correct_answer).toLowerCase().trim()) {
              userScore += field.score_if_correct || 1;
            }
          }
        });

        setQuizResult({ score: userScore, totalScore });
      }

      // Build record data from form fields
      const recordData = {
        status: "new",
        custom_fields: {}
      };

      form.fields.forEach(field => {
        const value = data[field.id];
        if (value !== undefined && value !== null && value !== "") {
          const mappedField = field.maps_to_field;

          // Map common field aliases to correct DatabaseRecord fields
          if (mappedField === "full_name") {
            recordData.client_name = value;
          } else if (mappedField === "email") {
            recordData.client_email = value;
          } else if (mappedField === "phone") {
            recordData.client_phone = value;
          } else if (mappedField === "client_name" || mappedField === "client_email" || mappedField === "client_phone" || mappedField === "status" || mappedField === "notes" || mappedField === "tags") {
            // Valid top-level fields in DatabaseRecord
            recordData[mappedField] = value;
          } else if (mappedField) {
            // Any other mapped field goes into custom_fields
            recordData.custom_fields[mappedField] = value;
          } else {
            const customFieldName = field.label.toLowerCase().replace(/\s+/g, '_');
            recordData.custom_fields[customFieldName] = value;
          }
        }
      });

      // Add quiz results to custom_fields if in quiz mode
      if (form.quiz_mode) {
        recordData.custom_fields.quiz_score = userScore;
        recordData.custom_fields.quiz_total_score = totalScore;
      }

      if (!recordData.title) {
        recordData.title = recordData.client_name || recordData.client_email || "Form submission";
      }

      // Check if a record already exists for this email
      const clientEmail = recordData.client_email;
      if (clientEmail) {
        const existingRecords = await base44.entities.DatabaseRecord.filter({ client_email: clientEmail });
        
        if (existingRecords.length > 0) {
          // Update existing record
          const existingRecord = existingRecords[0];
          const mergedCustomFields = { ...existingRecord.custom_fields, ...recordData.custom_fields };
          return base44.entities.DatabaseRecord.update(existingRecord.id, {
            ...recordData,
            custom_fields: mergedCustomFields
          });
        }
      }

      // Create new record if none exists
      const result = await base44.entities.DatabaseRecord.create(recordData);
      
      return { result, shouldRedirect: form.redirect_enabled && form.redirect_url, redirectUrl: form.redirect_url };
    },
    onSuccess: (data) => {
      if (data?.shouldRedirect && data?.redirectUrl) {
        window.location.href = data.redirectUrl;
      } else {
        setSubmitted(true);
      }
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    submitMutation.mutate(formData);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#fafafa] flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-[#20242d] border-t-transparent animate-spin" />
      </div>
    );
  }

  if (!form) {
    return (
      <div className="min-h-screen bg-[#fafafa] flex items-center justify-center">
        <div className="text-center">
          <p className="text-[#666] text-[14px]">Form not found</p>
        </div>
      </div>
    );
  }

  if (submitted) {
    if (form.quiz_mode && quizResult) {
      let resultMessage = "";
      
      // Check if score ranges are defined
      if (form.quiz_score_ranges && form.quiz_score_ranges.length > 0) {
        const matchingRange = form.quiz_score_ranges.find(
          range => quizResult.score >= range.min_score && quizResult.score <= range.max_score
        );
        resultMessage = matchingRange ? matchingRange.message : "Thank you for completing the quiz!";
      } else {
        // Fallback to the default message
        resultMessage = form.quiz_result_message || "Your score is {{score}} out of {{totalScore}}!";
        resultMessage = resultMessage
          .replace(/{{score}}/g, quizResult.score)
          .replace(/{{totalScore}}/g, quizResult.totalScore);
      }

      return (
        <div className="min-h-screen bg-[#fafafa] flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-white border border-[#e8e8e8] p-8 text-center">
            <CheckCircle2 className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-[20px] font-semibold text-[#20242d] mb-2">
              Quiz Complete!
            </h2>
            <div className="text-[32px] font-bold text-[#20242d] mb-4">
              {quizResult.score} / {quizResult.totalScore}
            </div>
            <p className="text-[14px] text-[#666] whitespace-pre-line">
              {resultMessage}
            </p>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-[#fafafa] flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white border border-[#e8e8e8] p-8 text-center">
          <CheckCircle2 className="h-16 w-16 text-green-600 mx-auto mb-4" />
          <h2 className="text-[20px] font-semibold text-[#20242d] mb-2">
            Thank you!
          </h2>
          <p className="text-[14px] text-[#666]">
            Your form has been submitted successfully.
          </p>
        </div>
      </div>
    );
  }

  const renderField = (field) => {
    const value = formData[field.id] || "";

    switch (field.type) {
      case "textarea":
        return (
          <Textarea
            value={value}
            onChange={(e) => setFormData({ ...formData, [field.id]: e.target.value })}
            placeholder={field.placeholder}
            required={field.required}
            className="rounded-none border-[#e8e8e8]"
          />
        );

      case "select":
        return (
          <Select
            value={value}
            onValueChange={(val) => setFormData({ ...formData, [field.id]: val })}
            required={field.required}
          >
            <SelectTrigger className="rounded-none border-[#e8e8e8]">
              <SelectValue placeholder={field.placeholder || "Select..."} />
            </SelectTrigger>
            <SelectContent className="rounded-none">
              {(field.options || []).map((opt) => {
                const optValue = typeof opt === 'string' ? opt : opt.value;
                return (
                  <SelectItem key={optValue} value={optValue}>
                    {optValue}
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        );

      case "checkbox":
        return (
          <div className="flex items-center space-x-2">
            <Checkbox
              checked={value}
              onCheckedChange={(checked) =>
                setFormData({ ...formData, [field.id]: checked })
              }
              required={field.required}
            />
            <Label className="text-[13px] text-[#666]">{field.label}</Label>
          </div>
        );

      case "multiselect":
        return (
          <div className="space-y-2">
            {(field.options || []).map((opt) => {
              const optValue = typeof opt === 'string' ? opt : opt.value;
              return (
                <div key={optValue} className="flex items-center space-x-2">
                  <Checkbox
                    checked={(value || []).includes(optValue)}
                    onCheckedChange={(checked) => {
                      const current = value || [];
                      const updated = checked
                        ? [...current, optValue]
                        : current.filter((v) => v !== optValue);
                      setFormData({ ...formData, [field.id]: updated });
                    }}
                  />
                  <Label className="text-[13px] text-[#666]">{optValue}</Label>
                </div>
              );
            })}
          </div>
        );

      case "phone":
        return (
          <Input
            type="tel"
            value={value}
            onChange={(e) => {
              const val = e.target.value.replace(/\D/g, '');
              let formatted = '';
              if (val.length > 0) {
                formatted = '+1 (' + val.substring(0, 3);
                if (val.length >= 4) formatted += ') ' + val.substring(3, 6);
                if (val.length >= 7) formatted += '-' + val.substring(6, 10);
              }
              setFormData({ ...formData, [field.id]: formatted });
            }}
            placeholder={field.placeholder}
            required={field.required}
            className="rounded-none border-[#e8e8e8]"
            maxLength={17}
          />
        );

      default:
        return (
          <Input
            type={field.type}
            value={value}
            onChange={(e) => setFormData({ ...formData, [field.id]: e.target.value })}
            placeholder={field.placeholder}
            required={field.required}
            className="rounded-none border-[#e8e8e8]"
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#fafafa] py-12 px-6">
      <div className="max-w-2xl mx-auto bg-white border border-[#e8e8e8] p-8">
        <h1 className="text-[24px] font-semibold text-[#20242d] mb-2">
          {form.title}
        </h1>
        {form.description && (
          <p className="text-[14px] text-[#666] mb-8">{form.description}</p>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {(form.fields || []).map((field) => (
            <div key={field.id} className="space-y-2">
              {field.type !== "checkbox" && (
                <Label className="text-[13px] font-medium text-[#20242d]">
                  {field.label}
                  {field.required && <span className="text-red-500 ml-1">*</span>}
                </Label>
              )}
              {renderField(field)}
            </div>
          ))}

          <Button
            type="submit"
            disabled={submitMutation.isPending}
            className="w-full h-10 bg-[#20242d] hover:bg-[#2d323d] rounded-none text-[14px]"
          >
            {submitMutation.isPending ? "Submitting..." : "Submit"}
          </Button>
        </form>
      </div>
    </div>
  );
}