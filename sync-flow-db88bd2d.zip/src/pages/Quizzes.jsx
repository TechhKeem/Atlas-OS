import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import QuizCard from "../components/quizzes/QuizCard";
import QuizModal from "../components/quizzes/QuizModal";

export default function QuizzesPage({ embedded = false }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const { toast } = useToast();

  const queryClient = useQueryClient();

  const { data: quizzes = [], isLoading } = useQuery({
    queryKey: ["quizzes"],
    queryFn: () => base44.entities.Quiz.list("-created_date")
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Quiz.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["quizzes"] });
      setIsModalOpen(false);
      setSelectedQuiz(null);
      toast({ title: "Quiz created" });
    },
    onError: (error) => {
      toast({
        title: "Error creating quiz",
        description: error.message || "An unknown error occurred.",
        variant: "destructive",
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Quiz.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["quizzes"] });
      setIsModalOpen(false);
      setSelectedQuiz(null);
      toast({ title: "Quiz updated" });
    },
    onError: (error) => {
      toast({
        title: "Error updating quiz",
        description: error.message || "An unknown error occurred.",
        variant: "destructive",
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Quiz.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["quizzes"] });
      toast({ title: "Quiz deleted" });
    }
  });

  const handleCreate = () => {
    setSelectedQuiz(null);
    setIsModalOpen(true);
  };

  const handleEdit = (quiz) => {
    setSelectedQuiz(quiz);
    setIsModalOpen(true);
  };

  const handleDelete = (id) => {
    deleteMutation.mutate(id);
  };

  const handleSave = (data) => {
    if (data.id) {
      const { id, created_date, updated_date, created_by, ...updateData } = data;
      updateMutation.mutate({ id, data: updateData });
    } else {
      createMutation.mutate(data);
    }
  };

  const containerClass = embedded 
    ? "flex-1 overflow-auto p-6" 
    : "h-screen flex flex-col bg-[#fafafa]";

  return (
    <div className={containerClass}>
      {!embedded && (
        <div className="flex items-center justify-between h-14 px-6 border-b border-[#e8e8e8] bg-white">
          <h1 className="text-[15px] font-semibold text-[#20242d]">Quizzes</h1>
          <Button
            onClick={handleCreate}
            className="h-8 px-3 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
          >
            <Plus className="h-4 w-4 mr-1.5" />
            New Quiz
          </Button>
        </div>
      )}

      <div className={embedded ? "" : "flex-1 overflow-auto p-6"}>
        {embedded && (
          <div className="flex justify-end mb-4">
            <Button
              onClick={handleCreate}
              className="h-8 px-3 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
            >
              <Plus className="h-4 w-4 mr-1.5" />
              New Quiz
            </Button>
          </div>
        )}

        {isLoading ? (
          <div className="h-64 flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-[#20242d] border-t-transparent animate-spin" />
          </div>
        ) : quizzes.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center">
            <p className="text-[#666] text-[14px] mb-4">
              No quizzes yet. Create one to engage and score leads.
            </p>
            <Button
              onClick={handleCreate}
              className="h-9 px-4 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
            >
              <Plus className="h-4 w-4 mr-1.5" />
              Create Quiz
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quizzes.map((quiz) => (
              <QuizCard
                key={quiz.id}
                quiz={quiz}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}
      </div>

      <QuizModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedQuiz(null);
        }}
        quiz={selectedQuiz}
        onSave={handleSave}
      />
    </div>
  );
}