import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import FormsPage from "./Forms";
import QuizzesPage from "./Quizzes";

export default function LeadCapturePage() {
  const [activeTab, setActiveTab] = useState("forms");

  return (
    <div className="h-screen flex flex-col bg-[#fafafa]">
      <div className="flex items-center justify-between h-14 px-6 border-b border-[#e8e8e8] bg-white">
        <h1 className="text-[15px] font-semibold text-[#20242d]">Lead Capture</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <div className="px-6 pt-4 bg-[#fafafa]">
          <TabsList className="bg-white border border-[#e8e8e8] rounded-none">
            <TabsTrigger 
              value="forms" 
              className="rounded-none data-[state=active]:bg-[#20242d] data-[state=active]:text-white"
            >
              Forms
            </TabsTrigger>
            <TabsTrigger 
              value="quizzes"
              className="rounded-none data-[state=active]:bg-[#20242d] data-[state=active]:text-white"
            >
              Quizzes
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="forms" className="flex-1 m-0">
          <FormsPage embedded={true} />
        </TabsContent>
        
        <TabsContent value="quizzes" className="flex-1 m-0">
          <QuizzesPage embedded={true} />
        </TabsContent>
      </Tabs>
    </div>
  );
}