import React, { useState, useMemo, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import {
  format,
  addMinutes,
  eachDayOfInterval,
  addDays,
  isBefore,
  isAfter,
  startOfMonth,
  endOfMonth,
  startOfDay
} from "date-fns";
import { Clock, Calendar, ChevronLeft, ChevronRight, Check, ArrowLeft } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function PublicBookingPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const slug = urlParams.get("slug");

  const [step, setStep] = useState("select");
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [formData, setFormData] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingComplete, setBookingComplete] = useState(false);
  const { toast } = useToast();

  const { data: bookingPage, isLoading: isLoadingPage } = useQuery({
    queryKey: ["public-booking-page", slug],
    queryFn: async () => {
      const pages = await base44.entities.BookingPage.filter({ slug, is_active: true });
      return pages[0] || null;
    },
    enabled: !!slug,
    staleTime: 5 * 60 * 1000,
  });

  const { data: form } = useQuery({
    queryKey: ["public-form", bookingPage?.form_id],
    queryFn: async () => {
      if (!bookingPage?.form_id) return null;
      const forms = await base44.entities.Form.filter({ id: bookingPage.form_id });
      return forms[0] || null;
    },
    enabled: !!bookingPage?.form_id,
    staleTime: 5 * 60 * 1000,
  });

  const { data: reasonForMeetingField } = useQuery({
    queryKey: ["reason-for-meeting-field"],
    queryFn: async () => {
      const fields = await base44.entities.DatabaseField.filter({ 
        name: "reason_for_meeting" 
      });
      return fields[0] || null;
    },
    staleTime: 5 * 60 * 1000,
  });

  const { data: availabilityData, isLoading: isLoadingAvailability } = useQuery({
    queryKey: ["availability", bookingPage?.id, currentMonth],
    queryFn: async () => {
      if (!bookingPage?.id) return { availableSlotsByDay: {} };

      const year = currentMonth.getFullYear();
      const month = currentMonth.getMonth();
      const startOfMonthDate = new Date(year, month, 1);
      const endOfMonthDate = new Date(year, month + 1, 0);

      const response = await base44.functions.invoke('getAvailability', {
        booking_page_id: bookingPage.id,
        startDate: startOfMonthDate.toISOString(),
        endDate: endOfMonthDate.toISOString(),
      });
      return response.data;
    },
    enabled: !!bookingPage,
    staleTime: 2 * 60 * 1000,
  });

  const minSelectableDate = useMemo(() => startOfDay(new Date()), []);
  const maxSelectableDate = useMemo(() => {
    return bookingPage?.max_days_ahead 
      ? addDays(minSelectableDate, bookingPage.max_days_ahead)
      : addDays(minSelectableDate, 60);
  }, [bookingPage?.max_days_ahead, minSelectableDate]);

  const timeSlots = useMemo(() => {
    if (!selectedDate || !availabilityData?.availableSlotsByDay) return [];
    const dateKey = selectedDate.toISOString().split('T')[0];
    return (availabilityData.availableSlotsByDay[dateKey] || []).map(slot => ({
      start: new Date(slot.start),
      end: new Date(slot.end),
      label: slot.label
    }));
  }, [availabilityData, selectedDate]);

  const availableDaysInMonth = useMemo(() => {
    if (!availabilityData?.availableSlotsByDay) return {};
    const days = {};
    for (const dateKey in availabilityData.availableSlotsByDay) {
      if (availabilityData.availableSlotsByDay[dateKey].length > 0) {
        days[dateKey] = true;
      }
    }
    return days;
  }, [availabilityData]);

  const daysInMonth = useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    return eachDayOfInterval({ start: firstDay, end: lastDay });
  }, [currentMonth]);

  const startingDayIndex = daysInMonth[0].getDay();

  const canGoToPreviousMonth = useMemo(() => {
    return isBefore(startOfMonth(minSelectableDate), startOfMonth(currentMonth));
  }, [minSelectableDate, currentMonth]);

  const canGoToNextMonth = useMemo(() => {
    return isAfter(endOfMonth(maxSelectableDate), endOfMonth(currentMonth));
  }, [maxSelectableDate, currentMonth]);

  const createBookingMutation = useMutation({
    mutationFn: async (data) => {
      const endTime = addMinutes(new Date(data.scheduled_time), bookingPage.duration_minutes).toISOString();
      
      const eventResponse = await base44.functions.invoke('createGoogleCalendarEvent', {
        booking_page_id: bookingPage.id,
        title: `${bookingPage.title} - ${data.client_name || data.client_email}`,
        description: `Booking from ${data.client_name || data.client_email}`,
        start_time: data.scheduled_time,
        end_time: endTime,
        attendees: [data.client_email]
      });

      const event = eventResponse.data.event;

      // Check if a record already exists for this email
      const existingRecords = await base44.entities.DatabaseRecord.filter({ 
        client_email: data.client_email 
      });

      let record;
      if (existingRecords.length > 0) {
        // Update existing record
        const existingRecord = existingRecords[0];
        const mergedCustomFields = { 
          ...existingRecord.custom_fields, 
          ...data.form_responses 
        };
        record = await base44.entities.DatabaseRecord.update(existingRecord.id, {
          client_name: data.client_name,
          client_phone: data.client_phone,
          status: "scheduled",
          scheduled_date: data.scheduled_time,
          event_id: event.id,
          booking_page_id: bookingPage.id,
          custom_fields: mergedCustomFields
        });
      } else {
        // Create new record
        record = await base44.entities.DatabaseRecord.create({
          title: data.client_name || data.client_email,
          client_name: data.client_name,
          client_email: data.client_email,
          client_phone: data.client_phone,
          status: "scheduled",
          scheduled_date: data.scheduled_time,
          event_id: event.id,
          booking_page_id: bookingPage.id,
          custom_fields: data.form_responses
        });
      }

      const booking = await base44.entities.Booking.create({
        booking_page_id: bookingPage.id,
        event_id: event.id,
        database_record_id: record.id,
        client_name: data.client_name,
        client_email: data.client_email,
        scheduled_time: data.scheduled_time,
        duration_minutes: bookingPage.duration_minutes,
        status: "confirmed",
        form_responses: data.form_responses
      });

      return booking;
    },
    onSuccess: () => {
      setBookingComplete(true);
      setStep("confirm");
      setIsSubmitting(false);
    },
    onError: (error) => {
      setIsSubmitting(false);
      toast({
        title: "Booking Failed",
        description: error.message || "An unexpected error occurred while scheduling your meeting.",
        variant: "destructive",
      });
    }
  });

  const handleSelectTime = useCallback((slot) => {
    setSelectedTime(slot);
    setStep("form");
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    createBookingMutation.mutate({
      scheduled_time: selectedTime.start.toISOString(),
      client_name: formData.client_name || formData["Full Name"],
      client_email: formData.client_email || formData["Email"],
      client_phone: formData.client_phone || formData["Phone"],
      form_responses: formData
    });
  };

  if (!slug) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fafafa]">
        <p className="text-[#666]">Invalid booking link</p>
      </div>
    );
  }

  if (isLoadingPage) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fafafa]">
        <div className="w-6 h-6 border-2 border-[#20242d] border-t-transparent animate-spin" />
      </div>
    );
  }

  if (!bookingPage) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fafafa]">
        <p className="text-[#666]">Booking page not found</p>
      </div>
    );
  }

  if (step === "confirm" && bookingComplete) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fafafa] p-6">
        <Card className="w-full max-w-md p-8 rounded-none border-[#e8e8e8] text-center">
          <div className="h-16 w-16 mx-auto mb-6 flex items-center justify-center bg-green-100">
            <Check className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-xl font-semibold text-[#20242d] mb-2">
            Booking Confirmed
          </h1>
          <p className="text-[#666] mb-6">
            {bookingPage.confirmation_message || "Your meeting has been scheduled."}
          </p>
          <div className="p-4 bg-[#fafafa] border border-[#e8e8e8] text-left mb-6">
            <p className="text-[13px] font-medium text-[#20242d]">{bookingPage.title}</p>
            <p className="text-[13px] text-[#666] mt-1">
              {format(selectedTime.start, "EEEE, MMMM d, yyyy")}
            </p>
            <p className="text-[13px] text-[#666]">
              {format(selectedTime.start, "h:mm a")} – {format(selectedTime.end, "h:mm a")}
            </p>
          </div>
          <p className="text-[12px] text-[#999]">
            A confirmation email has been sent to {formData.client_email || formData["Email"]}
          </p>
        </Card>
      </div>
    );
  }

  if (step === "form") {
    const formFields = form?.fields || [
      { id: "name", type: "text", label: "Full Name", required: true, maps_to_field: "client_name" },
      { id: "email", type: "email", label: "Email", required: true, maps_to_field: "client_email" }
    ];

    // Add Reason for Meeting field if available
    if (reasonForMeetingField && reasonForMeetingField.options) {
      formFields.push({
        id: "reason_for_meeting",
        type: "select",
        label: "Reason for Meeting",
        required: true,
        maps_to_field: "reason_for_meeting",
        options: reasonForMeetingField.options
      });
    }

    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fafafa] p-6">
        <Card className="w-full max-w-lg p-8 rounded-none border-[#e8e8e8]">
          <button
            onClick={() => setStep("select")}
            className="flex items-center gap-1 text-[13px] text-[#666] hover:text-[#20242d] mb-6"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </button>

          <h1 className="text-xl font-semibold text-[#20242d] mb-2">
            {bookingPage.title}
          </h1>
          <div className="flex items-center gap-4 text-[13px] text-[#666] mb-6">
            <span className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              {bookingPage.duration_minutes} min
            </span>
            {selectedTime && (
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {format(selectedTime.start, "EEE, MMM d")} at {format(selectedTime.start, "h:mm a")}
              </span>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {formFields.map((field) => (
              <div key={field.id} className="space-y-2">
                <Label className="text-[13px] font-medium text-[#20242d]">
                  {field.label}
                  {field.required && <span className="text-red-500 ml-1">*</span>}
                </Label>
                {field.type === "textarea" ? (
                  <Textarea
                    value={formData[field.maps_to_field || field.label] || ""}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        [field.maps_to_field || field.label]: e.target.value
                      })
                    }
                    placeholder={field.placeholder}
                    required={field.required}
                    className="min-h-[80px] rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0 resize-none"
                  />
                ) : field.type === "select" ? (
                  <Select
                    value={formData[field.maps_to_field || field.label] || ""}
                    onValueChange={(value) =>
                      setFormData({
                        ...formData,
                        [field.maps_to_field || field.label]: value
                      })
                    }
                  >
                    <SelectTrigger className="h-10 rounded-none border-[#e8e8e8]">
                      <SelectValue placeholder={field.placeholder || "Select..."} />
                    </SelectTrigger>
                    <SelectContent className="rounded-none">
                      {field.options?.map((option) => {
                        const optValue = typeof option === 'string' ? option : option.value;
                        return (
                          <SelectItem key={optValue} value={optValue}>
                            {optValue}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    type={field.type === "email" ? "email" : field.type === "phone" ? "tel" : "text"}
                    value={formData[field.maps_to_field || field.label] || ""}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        [field.maps_to_field || field.label]: e.target.value
                      })
                    }
                    placeholder={field.placeholder}
                    required={field.required}
                    className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                  />
                )}
              </div>
            ))}

            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full h-11 bg-[#20242d] hover:bg-[#2d323d] text-[14px] rounded-none mt-6"
            >
              {isSubmitting ? "Scheduling..." : "Schedule Meeting"}
            </Button>
          </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#fafafa] p-6">
      <Card className="w-full max-w-3xl p-8 rounded-none border-[#e8e8e8]">
        <div className="mb-8">
          <h1 className="text-xl font-semibold text-[#20242d] mb-2">
            {bookingPage.title}
          </h1>
          {bookingPage.description && (
            <p className="text-[14px] text-[#666] mb-4">{bookingPage.description}</p>
          )}
          <div className="flex items-center gap-2 text-[13px] text-[#666]">
            <Clock className="h-4 w-4" />
            <span>{bookingPage.duration_minutes} minutes</span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <div className="flex items-center justify-between mb-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1))}
                className="h-8 w-8 p-0 rounded-none"
                disabled={!canGoToPreviousMonth}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <h3 className="text-[14px] font-medium text-[#20242d]">
                {format(currentMonth, "MMMM yyyy")}
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1))}
                className="h-8 w-8 p-0 rounded-none"
                disabled={!canGoToNextMonth}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>

            <div className="grid grid-cols-7 gap-1 mb-2">
              {["S", "M", "T", "W", "T", "F", "S"].map((day, i) => (
                <div
                  key={i}
                  className="h-8 flex items-center justify-center text-[11px] font-medium text-[#999]"
                >
                  {day}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-1">
              {Array.from({ length: startingDayIndex }).map((_, i) => (
                <div key={`empty-${i}`} className="h-10 w-full" />
              ))}
              {daysInMonth.map((date) => {
                const isToday = date.toDateString() === new Date().toDateString();
                const isSelected = selectedDate?.toDateString() === date.toDateString();
                const hasAvailability = availableDaysInMonth[date.toISOString().split('T')[0]];
                const isPastDate = isBefore(date, minSelectableDate);
                const isDateTooFarInFuture = isAfter(date, maxSelectableDate);
                const isDisabled = isPastDate || isDateTooFarInFuture || !hasAvailability;

                return (
                  <Button
                    key={date.toISOString()}
                    variant="ghost"
                    onClick={() => !isDisabled && setSelectedDate(date)}
                    disabled={isDisabled}
                    className={`h-10 w-full p-0 rounded-none text-[13px] relative ${isSelected
                        ? "bg-[#20242d] text-white hover:bg-[#20242d]"
                        : isToday
                          ? "border border-[#20242d] text-[#20242d] hover:bg-[#f5f5f5]"
                          : "hover:bg-[#f5f5f5]"}
                        ${hasAvailability && !isDisabled && !isSelected ? "after:content-[''] after:block after:absolute after:bottom-1 after:left-1/2 after:-translate-x-1/2 after:w-1.5 after:h-1.5 after:rounded-full after:bg-green-500" : ""}
                        ${isDisabled ? "text-[#bbb] cursor-not-allowed" : ""}`}
                  >
                    {format(date, "d")}
                  </Button>
                );
              })}
            </div>
          </div>

          <div>
            <h3 className="text-[14px] font-medium text-[#20242d] mb-4">
              {selectedDate
                ? format(selectedDate, "EEEE, MMMM d")
                : "Select a date to see times"}
            </h3>

            {isLoadingAvailability ? (
              <div className="flex items-center justify-center h-40">
                <div className="w-5 h-5 border-2 border-[#20242d] border-t-transparent animate-spin" />
              </div>
            ) : selectedDate && timeSlots.length > 0 ? (
              <div className="grid grid-cols-2 gap-2 max-h-[300px] overflow-y-auto pr-2">
                {timeSlots.map((slot) => (
                  <Button
                    key={slot.start.toISOString()}
                    variant="outline"
                    onClick={() => handleSelectTime(slot)}
                    className="h-9 w-full justify-center text-[13px] rounded-none border-[#e8e8e8] hover:border-[#20242d] hover:bg-[#f5f5f5]"
                  >
                    {slot.label}
                  </Button>
                ))}
              </div>
            ) : (
              <p className="text-[13px] text-[#999] text-center py-4">
                {selectedDate ? "No available times for this date" : "Select a date to see times"}
              </p>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}