import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Copy, ExternalLink } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function ShareFormModal({ isOpen, onClose, form }) {
  const { toast } = useToast();
  
  if (!form) return null;

  const formUrl = `${window.location.origin}/?page=PublicForm&formId=${form.id}`;
  const embedCode = `<iframe src="${formUrl}" width="100%" height="600px" frameborder="0"></iframe>`;

  const copyToClipboard = (text, message) => {
    navigator.clipboard.writeText(text);
    toast({ title: message });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] rounded-none border-[#e8e8e8]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-semibold text-[#20242d]">
            Share Form: {form.title}
          </DialogTitle>
          <DialogDescription className="text-[13px] text-[#666]">
            Share this form via a direct link or embed it on your website.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="form-url" className="text-[13px] font-medium text-[#20242d]">
              Shareable Link
            </Label>
            <div className="flex gap-2">
              <Input 
                id="form-url" 
                value={formUrl} 
                readOnly 
                className="flex-1 rounded-none border-[#e8e8e8] text-[13px]" 
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(formUrl, "Form link copied!")}
                className="h-9 px-3 text-[13px] rounded-none border-[#e8e8e8]"
              >
                <Copy className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(formUrl, '_blank')}
                className="h-9 px-3 text-[13px] rounded-none border-[#e8e8e8]"
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="embed-code" className="text-[13px] font-medium text-[#20242d]">
              Embed Code
            </Label>
            <div className="flex gap-2">
              <textarea 
                id="embed-code" 
                value={embedCode} 
                readOnly 
                className="flex-1 rounded-none border border-[#e8e8e8] text-[13px] p-2 font-mono text-[11px] resize-none h-20"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(embedCode, "Embed code copied!")}
                className="h-9 px-3 text-[13px] rounded-none border-[#e8e8e8]"
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}