import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "react-hot-toast";
import { Copy, ExternalLink } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function EmbedFormModal({ isOpen, onClose, form }) {
  const [embedCode, setEmbedCode] = useState("");
  const [shareUrl, setShareUrl] = useState("");

  useEffect(() => {
    if (form) {
      const url = `${window.location.origin}${createPageUrl('PublicForm')}?formId=${form.id}`;
      setShareUrl(url);
      setEmbedCode(
        `<iframe src="${url}" style="width:100%; height:700px; border:none;"></iframe>`
      );
    }
  }, [form]);

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text).then(() => {
      toast.success("Copied to clipboard!");
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[550px] rounded-none border-[#e8e8e8]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-semibold text-[#20242d]">
            Share & Embed Form
          </DialogTitle>
        </DialogHeader>

        <div className="py-4 space-y-5">
          <div className="space-y-2">
            <Label className="text-[13px] font-medium text-[#20242d]">Public URL</Label>
            <div className="flex gap-2">
              <Input
                value={shareUrl}
                readOnly
                className="h-9 rounded-none border-[#e8e8e8] text-[12px] font-mono bg-[#fafafa] flex-1"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(shareUrl)}
                className="h-9 rounded-none border-[#e8e8e8]"
              >
                <Copy className="h-4 w-4 mr-1.5" /> Copy
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(shareUrl, '_blank')}
                className="h-9 rounded-none border-[#e8e8e8]"
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-[13px] font-medium text-[#20242d]">Embed Code</Label>
            <div className="space-y-2">
              <Textarea
                value={embedCode}
                readOnly
                rows={3}
                className="rounded-none border-[#e8e8e8] text-[11px] font-mono bg-[#fafafa] resize-none"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(embedCode)}
                className="h-8 rounded-none border-[#e8e8e8] w-full"
              >
                <Copy className="h-4 w-4 mr-1.5" /> Copy Embed Code
              </Button>
            </div>
            <p className="text-[11px] text-[#666]">
              Paste this code on your website to embed this form
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}