import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Trash2, GripVertical } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const fieldTypes = [
  { value: "text", label: "Short Text" },
  { value: "textarea", label: "Long Text" },
  { value: "email", label: "Email" },
  { value: "phone", label: "Phone" },
  { value: "select", label: "Dropdown" },
  { value: "multiselect", label: "Multi-Select" },
  { value: "checkbox", label: "Checkbox" },
  { value: "number", label: "Number" }
];

export default function FormModal({ isOpen, onClose, form, onSave }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    fields: [],
    is_active: true,
    quiz_mode: false,
    quiz_score_ranges: [],
    quiz_result_message: "",
    notification_emails: [],
    notification_subject: "",
    notification_body: ""
  });

  // Load existing database fields
  const { data: databaseFields = [] } = useQuery({
    queryKey: ["database-fields"],
    queryFn: () => base44.entities.DatabaseField.list("order"),
    enabled: isOpen
  });

  useEffect(() => {
    if (form) {
      setFormData({
        title: form.title || "",
        description: form.description || "",
        fields: (form.fields || []).map(f => {
          let normalizedOptions = f.options || [];
          if (normalizedOptions.length > 0) {
            if (form.quiz_mode) {
              // Quiz mode: ensure options are objects with value and score
              normalizedOptions = normalizedOptions.map(o => 
                typeof o === 'string' ? { value: o, score: 0 } : o
              );
            } else {
              // Regular form: ensure options are simple strings
              normalizedOptions = normalizedOptions.map(o => 
                typeof o === 'string' ? o : (o.value || '')
              ).filter(o => o !== '');
            }
          }
          return {
            ...f,
            options: normalizedOptions,
            optionsInput: normalizedOptions.map(o => typeof o === 'string' ? o : o.value).join(', ') || ''
          };
        }),
        is_active: form.is_active !== false,
        quiz_mode: form.quiz_mode || false,
        quiz_score_ranges: form.quiz_score_ranges || [],
        quiz_result_message: form.quiz_result_message || "",
        notification_emails: form.notification_emails || [],
        notification_subject: form.notification_subject || "",
        notification_body: form.notification_body || "",
        redirect_enabled: form.redirect_enabled || false,
        redirect_url: form.redirect_url || ""
        });
        } else {
      setFormData({
        title: "",
        description: "",
        fields: [
          { id: crypto.randomUUID(), type: "text", label: "Full Name", required: true, maps_to_field: "title", optionsInput: '' },
          { id: crypto.randomUUID(), type: "email", label: "Email", required: true, maps_to_field: "client_email", optionsInput: '' }
        ],
        is_active: true,
        quiz_mode: false,
        quiz_score_ranges: [],
        quiz_result_message: "",
        notification_emails: [],
        notification_subject: "",
        notification_body: "",
        redirect_enabled: false,
        redirect_url: ""
      });
      }
  }, [form]);

  const addField = () => {
    setFormData({
      ...formData,
      fields: [
        ...formData.fields,
        { id: crypto.randomUUID(), type: "text", label: "", required: false, optionsInput: '' }
      ]
    });
  };

  const updateField = (index, updates) => {
    const newFields = [...formData.fields];
    newFields[index] = { ...newFields[index], ...updates };
    setFormData({ ...formData, fields: newFields });
  };

  const removeField = (index) => {
    setFormData({
      ...formData,
      fields: formData.fields.filter((_, i) => i !== index)
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Sync new fields to database (only for custom fields)
    for (const field of formData.fields) {
      if (field.maps_to_field) {
        continue;
      }

      const customFieldName = field.label.toLowerCase().replace(/\s+/g, '_');
      const existingDatabaseField = databaseFields.find(f => f.name === customFieldName);

      if (!existingDatabaseField && customFieldName) {
        await base44.entities.DatabaseField.create({
          name: customFieldName,
          label: field.label,
          type: field.type === 'textarea' ? 'text' : field.type,
          options: field.options,
          is_visible: true,
          order: databaseFields.length + 1
        });
      }
    }
    
    // Invalidate database fields cache
    queryClient.invalidateQueries({ queryKey: ["database-fields"] });
    
    // Clean up temporary UI fields before saving
    const cleanedFields = formData.fields.map(field => {
      const { optionsInput, ...cleanField } = field;

      // Convert options format based on quiz mode
      if (cleanField.options && Array.isArray(cleanField.options)) {
        if (formData.quiz_mode) {
          // Keep as objects with value and score for quiz mode
          cleanField.options = cleanField.options.map(opt => 
            typeof opt === 'string' ? { value: opt, score: 0 } : opt
          );
        } else {
          // Convert to simple strings for regular forms
          cleanField.options = cleanField.options.map(opt => {
            if (typeof opt === 'string') return opt;
            return String(opt.value || '');
          }).filter(option => option !== '');
        }
      }

      return cleanField;
    });
    
    onSave({
      ...form,
      ...formData,
      fields: cleanedFields
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto rounded-none border-[#e8e8e8]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-semibold text-[#20242d]">
            {form ? "Edit Form" : "New Form"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Form Title
              </Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Contact Form"
                className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                required
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Description
              </Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Optional description for this form"
                className="min-h-[60px] rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0 resize-none"
              />
            </div>

            <div className="flex items-center justify-between p-3 border border-[#e8e8e8] bg-[#fafafa]">
              <div>
                <h4 className="text-[13px] font-medium text-[#20242d]">Quiz Mode</h4>
                <p className="text-[11px] text-[#666]">Enable scoring for lead magnet forms</p>
              </div>
              <Switch
                checked={formData.quiz_mode}
                onCheckedChange={(checked) => {
                  // Convert options format when toggling quiz mode
                  const updatedFields = formData.fields.map(field => {
                    if (!field.options || !Array.isArray(field.options)) return field;

                    if (checked) {
                      // Converting TO quiz mode: string -> object
                      return {
                        ...field,
                        options: field.options.map(opt => 
                          typeof opt === 'string' ? { value: opt, score: 0 } : opt
                        )
                      };
                    } else {
                      // Converting FROM quiz mode: object -> string
                      return {
                        ...field,
                        options: field.options.map(opt => 
                          typeof opt === 'string' ? opt : opt.value
                        )
                      };
                    }
                  });

                  setFormData({ ...formData, quiz_mode: checked, fields: updatedFields });
                }}
              />
            </div>

            {formData.quiz_mode && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-[13px] font-medium text-[#20242d]">
                      Score Ranges & Messages
                    </Label>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setFormData({
                          ...formData,
                          quiz_score_ranges: [
                            ...formData.quiz_score_ranges,
                            { min_score: 0, max_score: 10, message: "" }
                          ]
                        });
                      }}
                      className="h-7 px-2 text-[12px] rounded-none"
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Add Range
                    </Button>
                  </div>
                  <div className="space-y-2">
                    {formData.quiz_score_ranges.map((range, index) => (
                      <div key={index} className="p-3 border border-[#e8e8e8] bg-[#fafafa] space-y-2">
                        <div className="grid grid-cols-2 gap-2">
                          <div className="space-y-1">
                            <Label className="text-[11px] text-[#666]">Min Score</Label>
                            <Input
                              type="number"
                              value={range.min_score}
                              onChange={(e) => {
                                const newRanges = [...formData.quiz_score_ranges];
                                newRanges[index] = { ...newRanges[index], min_score: Number(e.target.value) };
                                setFormData({ ...formData, quiz_score_ranges: newRanges });
                              }}
                              className="h-8 rounded-none border-[#e8e8e8] text-[12px]"
                            />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-[11px] text-[#666]">Max Score</Label>
                            <Input
                              type="number"
                              value={range.max_score}
                              onChange={(e) => {
                                const newRanges = [...formData.quiz_score_ranges];
                                newRanges[index] = { ...newRanges[index], max_score: Number(e.target.value) };
                                setFormData({ ...formData, quiz_score_ranges: newRanges });
                              }}
                              className="h-8 rounded-none border-[#e8e8e8] text-[12px]"
                            />
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Textarea
                            value={range.message}
                            onChange={(e) => {
                              const newRanges = [...formData.quiz_score_ranges];
                              newRanges[index] = { ...newRanges[index], message: e.target.value };
                              setFormData({ ...formData, quiz_score_ranges: newRanges });
                            }}
                            placeholder="Message to display for this score range"
                            className="flex-1 min-h-[50px] rounded-none border-[#e8e8e8] text-[12px] resize-none"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setFormData({
                                ...formData,
                                quiz_score_ranges: formData.quiz_score_ranges.filter((_, i) => i !== index)
                              });
                            }}
                            className="h-8 w-8 p-0 text-[#999] hover:text-red-600 hover:bg-red-50 rounded-none"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    {formData.quiz_score_ranges.length === 0 && (
                      <p className="text-[11px] text-[#999] text-center py-2">
                        No score ranges defined. Add ranges to show different messages based on user scores.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
              <h4 className="text-[13px] font-medium text-[#20242d]">Email Notifications</h4>
              <div className="space-y-2">
                <Label className="text-[11px] text-[#666]">
                  Send notification to (comma-separated emails)
                </Label>
                <Input
                  value={formData.notification_emails.join(", ")}
                  onChange={(e) => {
                    const emails = e.target.value.split(",").map(email => email.trim()).filter(email => email);
                    setFormData({ ...formData, notification_emails: emails });
                  }}
                  placeholder="email@example.com, another@example.com"
                  className="h-9 rounded-none border-[#e8e8e8] text-[12px]"
                />
              </div>
              {formData.notification_emails.length > 0 && (
                <>
                  <div className="space-y-2">
                    <Label className="text-[11px] text-[#666]">Subject</Label>
                    <Input
                      value={formData.notification_subject}
                      onChange={(e) => setFormData({ ...formData, notification_subject: e.target.value })}
                      placeholder="New form submission"
                      className="h-9 rounded-none border-[#e8e8e8] text-[12px]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[11px] text-[#666]">Message Body (use {`{{Field Label}}`} for form values)</Label>
                    <Textarea
                      value={formData.notification_body}
                      onChange={(e) => setFormData({ ...formData, notification_body: e.target.value })}
                      placeholder="New submission from {{Full Name}} ({{Email}})"
                      className="min-h-[80px] rounded-none border-[#e8e8e8] text-[12px] resize-none"
                    />
                  </div>
                </>
              )}
            </div>

            <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-[13px] font-medium text-[#20242d]">Redirect After Submission</h4>
                  <p className="text-[11px] text-[#666]">Redirect users to a custom page after form submission</p>
                </div>
                <Switch
                  checked={formData.redirect_enabled}
                  onCheckedChange={(checked) => setFormData({ ...formData, redirect_enabled: checked })}
                />
              </div>
              {formData.redirect_enabled && (
                <div className="space-y-2">
                  <Label className="text-[11px] text-[#666]">Redirect URL</Label>
                  <Input
                    value={formData.redirect_url}
                    onChange={(e) => setFormData({ ...formData, redirect_url: e.target.value })}
                    placeholder="https://example.com/thank-you"
                    className="h-9 rounded-none border-[#e8e8e8] text-[12px]"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Fields */}
          <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
            <div className="flex items-center justify-between">
              <h4 className="text-[13px] font-medium text-[#20242d]">Fields</h4>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={addField}
                className="h-8 px-3 text-[13px] text-[#20242d] hover:bg-[#f5f5f5] rounded-none"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Field
              </Button>
            </div>

            <div className="space-y-3">
              {formData.fields.map((field, index) => (
                <div
                  key={field.id}
                  className="p-4 border border-[#e8e8e8] bg-white"
                >
                  <div className="flex items-start gap-3">
                    <div className="pt-2 text-[#999] cursor-grab">
                      <GripVertical className="h-4 w-4" />
                    </div>
                    <div className="flex-1 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          value={field.label}
                          onChange={(e) => updateField(index, { label: e.target.value })}
                          placeholder="Field label"
                          className="h-9 rounded-none border-[#e8e8e8] text-[13px]"
                        />
                        <Select
                          value={field.type}
                          onValueChange={(value) => updateField(index, { type: value })}
                        >
                          <SelectTrigger className="h-9 rounded-none border-[#e8e8e8] text-[13px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="rounded-none">
                            {fieldTypes.map((type) => (
                              <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {!formData.quiz_mode && (
                        <Select
                          value={field.maps_to_field || ""}
                          onValueChange={(value) => updateField(index, { maps_to_field: value })}
                        >
                          <SelectTrigger className="h-9 rounded-none border-[#e8e8e8] text-[13px]">
                            <SelectValue placeholder="Map to database field (optional)" />
                          </SelectTrigger>
                          <SelectContent className="rounded-none">
                            <SelectItem value={null}>Don't map</SelectItem>
                            {databaseFields.map((dbField) => (
                              <SelectItem key={dbField.name} value={dbField.name}>
                                {dbField.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}

                      {(field.type === "select" || field.type === "multiselect") && (
                        <div className="space-y-2">
                          <Input
                            value={field.optionsInput || ''}
                            onChange={(e) => updateField(index, { optionsInput: e.target.value })}
                            onBlur={() => {
                              if (formData.quiz_mode) {
                                // Quiz mode: create objects with scores
                                const currentOptionsMap = new Map();
                                (field.options || []).forEach(opt => {
                                  const val = typeof opt === 'string' ? opt : opt.value;
                                  const score = typeof opt === 'string' ? 0 : (opt.score || 0);
                                  currentOptionsMap.set(val, score);
                                });

                                const newOptions = field.optionsInput.split(',').map(o => {
                                  const value = o.trim();
                                  if (!value) return null;

                                  return {
                                    value: value,
                                    score: currentOptionsMap.has(value) ? currentOptionsMap.get(value) : 0
                                  };
                                }).filter(opt => opt !== null);

                                updateField(index, { options: newOptions });
                              } else {
                                // Regular form: create simple string array
                                const newOptions = field.optionsInput
                                  .split(',')
                                  .map(o => o.trim())
                                  .filter(o => o);
                                updateField(index, { options: newOptions });
                              }
                            }}
                            placeholder="Options (comma separated)"
                            className="h-9 rounded-none border-[#e8e8e8] text-[13px]"
                          />
                          {formData.quiz_mode && field.options && field.options.length > 0 && (
                            <div className="space-y-1 pl-2">
                              <Label className="text-[11px] text-[#666]">Scores for each option:</Label>
                              {field.options.map((option, optIndex) => {
                                const opt = typeof option === 'string' ? { value: option, score: 0 } : option;
                                return (
                                  <div key={optIndex} className="flex items-center gap-2">
                                    <Input
                                      value={opt.score}
                                      onChange={(e) => {
                                        const newOptions = field.options.map(o => typeof o === 'string' ? { value: o, score: 0 } : o);
                                        newOptions[optIndex] = { ...newOptions[optIndex], score: Number(e.target.value) || 0 };
                                        updateField(index, { options: newOptions });
                                      }}
                                      type="number"
                                      placeholder="Score"
                                      className="h-7 w-16 rounded-none border-[#e8e8e8] text-[11px]"
                                    />
                                    <span className="text-[11px] text-[#666]">{opt.value}</span>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      )}

                      {formData.quiz_mode && !(field.type === "select" || field.type === "multiselect" || field.type === "checkbox") && (
                        <div className="grid grid-cols-2 gap-2">
                          <div className="space-y-1">
                            <Label className="text-[11px] text-[#666]">Correct Answer</Label>
                            <Input
                              value={field.correct_answer || ""}
                              onChange={(e) => updateField(index, { correct_answer: e.target.value })}
                              placeholder="Answer"
                              className="h-8 rounded-none border-[#e8e8e8] text-[12px]"
                            />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-[11px] text-[#666]">Score if Correct</Label>
                            <Input
                              value={field.score_if_correct || 1}
                              onChange={(e) => updateField(index, { score_if_correct: Number(e.target.value) || 0 })}
                              type="number"
                              placeholder="Points"
                              className="h-8 rounded-none border-[#e8e8e8] text-[12px]"
                            />
                          </div>
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={field.required}
                            onCheckedChange={(checked) => updateField(index, { required: checked })}
                          />
                          <span className="text-[12px] text-[#666]">Required</span>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeField(index)}
                          className="h-8 w-8 p-0 text-[#999] hover:text-red-600 hover:bg-red-50 rounded-none"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter className="pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onClose(false)}
              className="rounded-none border-[#e8e8e8]"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-[#20242d] hover:bg-[#2d323d] rounded-none"
            >
              {form ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}