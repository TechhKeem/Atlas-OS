import React, { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreVertical, Edit, Trash2, ExternalLink, Share2, Award } from "lucide-react";
import ShareQuizModal from "./ShareQuizModal";

export default function QuizCard({ quiz, onEdit, onDelete }) {
  const [showShareModal, setShowShareModal] = useState(false);
  const publicUrl = `${window.location.origin}/PublicQuiz?quizId=${quiz.id}`;

  return (
    <>
      <Card className="border-[#e8e8e8] rounded-none hover:shadow-md transition-shadow">
        <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-[14px] font-semibold text-[#20242d] line-clamp-1">
                {quiz.title}
              </h3>
              <Badge
                variant={quiz.is_active ? "default" : "secondary"}
                className="text-[10px] px-1.5 py-0 h-5 rounded-none"
              >
                {quiz.is_active ? "Active" : "Inactive"}
              </Badge>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-[#666]">
              <Award className="h-3 w-3" />
              <span>{quiz.fields?.length || 0} questions</span>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0 rounded-none">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="rounded-none">
              <DropdownMenuItem onClick={() => onEdit(quiz)} className="text-[13px]">
                <Edit className="h-3.5 w-3.5 mr-2" />
                Edit
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => window.open(publicUrl, "_blank")}
                className="text-[13px]"
              >
                <ExternalLink className="h-3.5 w-3.5 mr-2" />
                Preview
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setShowShareModal(true)}
                className="text-[13px]"
              >
                <Share2 className="h-3.5 w-3.5 mr-2" />
                Share & Embed
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => onDelete(quiz.id)}
                className="text-[13px] text-red-600"
              >
                <Trash2 className="h-3.5 w-3.5 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </CardHeader>
        {quiz.description && (
          <CardContent className="pt-0">
            <p className="text-[12px] text-[#666] line-clamp-2">{quiz.description}</p>
          </CardContent>
        )}
      </Card>

      <ShareQuizModal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        quiz={quiz}
      />
    </>
  );
}