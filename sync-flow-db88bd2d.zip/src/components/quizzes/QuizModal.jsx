import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Trash2, GripVertical } from "lucide-react";

const fieldTypes = [
  { value: "text", label: "Short Text" },
  { value: "textarea", label: "Long Text" },
  { value: "email", label: "Email" },
  { value: "phone", label: "Phone" },
  { value: "select", label: "Dropdown" },
  { value: "multiselect", label: "Multi-Select" },
  { value: "number", label: "Number" }
];

export default function QuizModal({ isOpen, onClose, quiz, onSave }) {
  const { data: bookingPages = [] } = useQuery({
    queryKey: ["booking-pages"],
    queryFn: () => base44.entities.BookingPage.list("-created_date"),
    enabled: isOpen
  });

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    fields: [],
    is_active: true,
    score_ranges: [],
    result_message: "",
    redirect_enabled: false,
    redirect_url: "",
    booking_page_id: "",
    booking_button_text: "Book an Appointment"
  });

  useEffect(() => {
    if (quiz) {
      setFormData({
        title: quiz.title || "",
        description: quiz.description || "",
        fields: (quiz.fields || []).map(f => ({
          ...f,
          optionsInput: f.options?.map(o => o.value).join(', ') || ''
        })),
        is_active: quiz.is_active !== false,
        score_ranges: quiz.score_ranges || [],
        result_message: quiz.result_message || "",
        redirect_enabled: quiz.redirect_enabled || false,
        redirect_url: quiz.redirect_url || "",
        booking_page_id: quiz.booking_page_id || "",
        booking_button_text: quiz.booking_button_text || "Book an Appointment"
      });
    } else {
      setFormData({
        title: "",
        description: "",
        fields: [
          { id: crypto.randomUUID(), type: "text", label: "Full Name", required: true, optionsInput: '' },
          { id: crypto.randomUUID(), type: "email", label: "Email", required: true, optionsInput: '' }
        ],
        is_active: true,
        score_ranges: [],
        result_message: "You scored {{score}} out of {{totalScore}}!",
        redirect_enabled: false,
        redirect_url: "",
        booking_page_id: "",
        booking_button_text: "Book an Appointment"
      });
    }
  }, [quiz]);

  const addField = () => {
    setFormData({
      ...formData,
      fields: [
        ...formData.fields,
        { id: crypto.randomUUID(), type: "text", label: "", required: false, optionsInput: '' }
      ]
    });
  };

  const updateField = (index, updates) => {
    const newFields = [...formData.fields];
    newFields[index] = { ...newFields[index], ...updates };
    setFormData({ ...formData, fields: newFields });
  };

  const removeField = (index) => {
    setFormData({
      ...formData,
      fields: formData.fields.filter((_, i) => i !== index)
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Clean up fields before saving
    const cleanedFields = formData.fields.map(field => {
      const { optionsInput, ...cleanField } = field;

      // Ensure options are always objects with value and score
      if (cleanField.options && Array.isArray(cleanField.options)) {
        cleanField.options = cleanField.options.map(opt => 
          typeof opt === 'object' ? opt : { value: opt, score: 0 }
        );
      }

      return cleanField;
    });
    
    onSave({
      ...quiz,
      ...formData,
      fields: cleanedFields
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto rounded-none border-[#e8e8e8]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-semibold text-[#20242d]">
            {quiz ? "Edit Quiz" : "New Quiz"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Quiz Title
              </Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Product Knowledge Quiz"
                className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                required
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Description
              </Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Optional description for this quiz"
                className="min-h-[60px] rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0 resize-none"
              />
            </div>

            <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-[13px] font-medium text-[#20242d]">
                    Score Ranges & Messages
                  </Label>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setFormData({
                        ...formData,
                        score_ranges: [
                          ...formData.score_ranges,
                          { min_score: 0, max_score: 10, message: "" }
                        ]
                      });
                    }}
                    className="h-7 px-2 text-[12px] rounded-none"
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    Add Range
                  </Button>
                </div>
                <div className="space-y-2">
                  {formData.score_ranges.map((range, index) => (
                    <div key={index} className="p-3 border border-[#e8e8e8] bg-[#fafafa] space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <Label className="text-[11px] text-[#666]">Min Score</Label>
                          <Input
                            type="number"
                            value={range.min_score}
                            onChange={(e) => {
                              const newRanges = [...formData.score_ranges];
                              newRanges[index] = { ...newRanges[index], min_score: Number(e.target.value) };
                              setFormData({ ...formData, score_ranges: newRanges });
                            }}
                            className="h-8 rounded-none border-[#e8e8e8] text-[12px]"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-[11px] text-[#666]">Max Score</Label>
                          <Input
                            type="number"
                            value={range.max_score}
                            onChange={(e) => {
                              const newRanges = [...formData.score_ranges];
                              newRanges[index] = { ...newRanges[index], max_score: Number(e.target.value) };
                              setFormData({ ...formData, score_ranges: newRanges });
                            }}
                            className="h-8 rounded-none border-[#e8e8e8] text-[12px]"
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Textarea
                          value={range.message}
                          onChange={(e) => {
                            const newRanges = [...formData.score_ranges];
                            newRanges[index] = { ...newRanges[index], message: e.target.value };
                            setFormData({ ...formData, score_ranges: newRanges });
                          }}
                          placeholder="Message to display for this score range"
                          className="flex-1 min-h-[50px] rounded-none border-[#e8e8e8] text-[12px] resize-none"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setFormData({
                              ...formData,
                              score_ranges: formData.score_ranges.filter((_, i) => i !== index)
                            });
                          }}
                          className="h-8 w-8 p-0 text-[#999] hover:text-red-600 hover:bg-red-50 rounded-none"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  {formData.score_ranges.length === 0 && (
                    <p className="text-[11px] text-[#999] text-center py-2">
                      No score ranges defined. Add ranges to show different messages based on scores.
                    </p>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-[13px] font-medium text-[#20242d]">Redirect After Submission</h4>
                  <p className="text-[11px] text-[#666]">Redirect users to a custom page after quiz completion</p>
                </div>
                <Switch
                  checked={formData.redirect_enabled}
                  onCheckedChange={(checked) => setFormData({ ...formData, redirect_enabled: checked })}
                />
              </div>
              {formData.redirect_enabled && (
                <div className="space-y-2">
                  <Label className="text-[11px] text-[#666]">Redirect URL</Label>
                  <Input
                    value={formData.redirect_url}
                    onChange={(e) => setFormData({ ...formData, redirect_url: e.target.value })}
                    placeholder="https://example.com/thank-you"
                    className="h-9 rounded-none border-[#e8e8e8] text-[12px]"
                  />
                </div>
              )}
            </div>

            <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
              <div>
                <h4 className="text-[13px] font-medium text-[#20242d] mb-1">Booking Page Link</h4>
                <p className="text-[11px] text-[#666]">Link to a booking page from the quiz results</p>
              </div>
              <div className="space-y-2">
                <Label className="text-[11px] text-[#666]">Select Booking Page (optional)</Label>
                <Select
                  value={formData.booking_page_id || ""}
                  onValueChange={(value) => setFormData({ ...formData, booking_page_id: value })}
                >
                  <SelectTrigger className="h-9 rounded-none border-[#e8e8e8] text-[12px]">
                    <SelectValue placeholder="No booking page selected" />
                  </SelectTrigger>
                  <SelectContent className="rounded-none">
                    <SelectItem value={null}>None</SelectItem>
                    {bookingPages.map((page) => (
                      <SelectItem key={page.id} value={page.id}>
                        {page.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {formData.booking_page_id && (
                <div className="space-y-2">
                  <Label className="text-[11px] text-[#666]">Button Text</Label>
                  <Input
                    value={formData.booking_button_text}
                    onChange={(e) => setFormData({ ...formData, booking_button_text: e.target.value })}
                    placeholder="Book an Appointment"
                    className="h-9 rounded-none border-[#e8e8e8] text-[12px]"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Questions */}
          <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
            <div className="flex items-center justify-between">
              <h4 className="text-[13px] font-medium text-[#20242d]">Questions</h4>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={addField}
                className="h-8 px-3 text-[13px] text-[#20242d] hover:bg-[#f5f5f5] rounded-none"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Question
              </Button>
            </div>

            <div className="space-y-3">
              {formData.fields.map((field, index) => (
                <div
                  key={field.id}
                  className="p-4 border border-[#e8e8e8] bg-white"
                >
                  <div className="flex items-start gap-3">
                    <div className="pt-2 text-[#999] cursor-grab">
                      <GripVertical className="h-4 w-4" />
                    </div>
                    <div className="flex-1 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          value={field.label}
                          onChange={(e) => updateField(index, { label: e.target.value })}
                          placeholder="Question text"
                          className="h-9 rounded-none border-[#e8e8e8] text-[13px]"
                        />
                        <Select
                          value={field.type}
                          onValueChange={(value) => updateField(index, { type: value })}
                        >
                          <SelectTrigger className="h-9 rounded-none border-[#e8e8e8] text-[13px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="rounded-none">
                            {fieldTypes.map((type) => (
                              <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {(field.type === "select" || field.type === "multiselect") && (
                        <div className="space-y-2">
                          <Input
                            value={field.optionsInput || ''}
                            onChange={(e) => updateField(index, { optionsInput: e.target.value })}
                            onBlur={() => {
                              const currentOptionsMap = new Map();
                              (field.options || []).forEach(opt => {
                                currentOptionsMap.set(opt.value, opt.score || 0);
                              });

                              const newOptions = field.optionsInput.split(',').map(o => {
                                const value = o.trim();
                                if (!value) return null;

                                return {
                                  value: value,
                                  score: currentOptionsMap.has(value) ? currentOptionsMap.get(value) : 0
                                };
                              }).filter(opt => opt !== null);

                              updateField(index, { options: newOptions });
                            }}
                            placeholder="Options (comma separated)"
                            className="h-9 rounded-none border-[#e8e8e8] text-[13px]"
                          />
                          {field.options && field.options.length > 0 && (
                            <div className="space-y-1 pl-2">
                              <Label className="text-[11px] text-[#666]">Scores for each option:</Label>
                              {field.options.map((option, optIndex) => (
                                <div key={optIndex} className="flex items-center gap-2">
                                  <Input
                                    value={option.score}
                                    onChange={(e) => {
                                      const newOptions = [...field.options];
                                      newOptions[optIndex] = { ...newOptions[optIndex], score: Number(e.target.value) || 0 };
                                      updateField(index, { options: newOptions });
                                    }}
                                    type="number"
                                    placeholder="Score"
                                    className="h-7 w-16 rounded-none border-[#e8e8e8] text-[11px]"
                                  />
                                  <span className="text-[11px] text-[#666]">{option.value}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}

                      {!(field.type === "select" || field.type === "multiselect") && (
                        <div className="grid grid-cols-2 gap-2">
                          <div className="space-y-1">
                            <Label className="text-[11px] text-[#666]">Correct Answer</Label>
                            <Input
                              value={field.correct_answer || ""}
                              onChange={(e) => updateField(index, { correct_answer: e.target.value })}
                              placeholder="Answer"
                              className="h-8 rounded-none border-[#e8e8e8] text-[12px]"
                            />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-[11px] text-[#666]">Score if Correct</Label>
                            <Input
                              value={field.score_if_correct || 1}
                              onChange={(e) => updateField(index, { score_if_correct: Number(e.target.value) || 0 })}
                              type="number"
                              placeholder="Points"
                              className="h-8 rounded-none border-[#e8e8e8] text-[12px]"
                            />
                          </div>
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={field.required}
                            onCheckedChange={(checked) => updateField(index, { required: checked })}
                          />
                          <span className="text-[12px] text-[#666]">Required</span>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeField(index)}
                          className="h-8 w-8 p-0 text-[#999] hover:text-red-600 hover:bg-red-50 rounded-none"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter className="pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onClose(false)}
              className="rounded-none border-[#e8e8e8]"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-[#20242d] hover:bg-[#2d323d] rounded-none"
            >
              {quiz ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}