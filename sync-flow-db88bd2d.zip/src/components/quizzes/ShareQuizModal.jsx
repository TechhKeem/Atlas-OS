import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, ExternalLink, Check } from "lucide-react";

export default function ShareQuizModal({ isOpen, onClose, quiz }) {
  const [copied, setCopied] = useState({ url: false, embed: false });
  const [shareUrl, setShareUrl] = useState("");
  const [embedCode, setEmbedCode] = useState("");

  useEffect(() => {
    if (quiz) {
      const url = `${window.location.origin}/PublicQuiz?quizId=${quiz.id}`;
      setShareUrl(url);
      setEmbedCode(`<iframe src="${url}" width="100%" height="600" frameborder="0"></iframe>`);
    }
  }, [quiz]);

  const handleCopy = (text, type) => {
    navigator.clipboard.writeText(text);
    setCopied({ ...copied, [type]: true });
    setTimeout(() => setCopied({ ...copied, [type]: false }), 2000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] rounded-none border-[#e8e8e8]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-semibold text-[#20242d]">
            Share Quiz
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="link" className="w-full">
          <TabsList className="grid w-full grid-cols-2 rounded-none bg-[#fafafa]">
            <TabsTrigger value="link" className="rounded-none">Link</TabsTrigger>
            <TabsTrigger value="embed" className="rounded-none">Embed</TabsTrigger>
          </TabsList>

          <TabsContent value="link" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Public Quiz URL
              </Label>
              <div className="flex gap-2">
                <Input
                  value={shareUrl}
                  readOnly
                  className="h-10 rounded-none border-[#e8e8e8] text-[13px] bg-[#fafafa]"
                />
                <Button
                  onClick={() => handleCopy(shareUrl, "url")}
                  variant="outline"
                  className="h-10 px-3 rounded-none border-[#e8e8e8]"
                >
                  {copied.url ? (
                    <Check className="h-4 w-4 text-green-600" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
                <Button
                  onClick={() => window.open(shareUrl, "_blank")}
                  variant="outline"
                  className="h-10 px-3 rounded-none border-[#e8e8e8]"
                >
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-[11px] text-[#666]">
                Share this link to allow users to take your quiz
              </p>
            </div>
          </TabsContent>

          <TabsContent value="embed" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Embed Code
              </Label>
              <div className="flex gap-2">
                <Input
                  value={embedCode}
                  readOnly
                  className="h-10 rounded-none border-[#e8e8e8] text-[13px] bg-[#fafafa] font-mono"
                />
                <Button
                  onClick={() => handleCopy(embedCode, "embed")}
                  variant="outline"
                  className="h-10 px-3 rounded-none border-[#e8e8e8]"
                >
                  {copied.embed ? (
                    <Check className="h-4 w-4 text-green-600" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
              <p className="text-[11px] text-[#666]">
                Copy this code to embed the quiz on your website
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}