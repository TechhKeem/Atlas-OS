import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

const defaultAvailability = {
  monday: { enabled: true, start: "09:00", end: "17:00" },
  tuesday: { enabled: true, start: "09:00", end: "17:00" },
  wednesday: { enabled: true, start: "09:00", end: "17:00" },
  thursday: { enabled: true, start: "09:00", end: "17:00" },
  friday: { enabled: true, start: "09:00", end: "17:00" },
  saturday: { enabled: false, start: "09:00", end: "17:00" },
  sunday: { enabled: false, start: "09:00", end: "17:00" }
};

export default function BookingPageModal({
  isOpen,
  onClose,
  bookingPage,
  forms,
  onSave,
  onDelete
}) {
  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    description: "",
    duration_minutes: 30,
    buffer_before: 0,
    buffer_after: 0,
    max_days_ahead: 60,
    is_active: true,
    form_id: "",
    availability_rules: defaultAvailability,
    confirmation_message: "Your meeting has been scheduled. We look forward to speaking with you.",
    send_reminders: true,
    allow_reschedule: true,
    target_calendar_id: "",
    conflict_calendar_ids: []
  });

  useEffect(() => {
    if (bookingPage) {
      setFormData({
        title: bookingPage.title || "",
        slug: bookingPage.slug || "",
        description: bookingPage.description || "",
        duration_minutes: bookingPage.duration_minutes || 30,
        buffer_before: bookingPage.buffer_before || 0,
        buffer_after: bookingPage.buffer_after || 0,
        max_days_ahead: bookingPage.max_days_ahead || 60,
        is_active: bookingPage.is_active !== false,
        form_id: bookingPage.form_id || "",
        availability_rules: bookingPage.availability_rules || defaultAvailability,
        confirmation_message: bookingPage.confirmation_message || "Your meeting has been scheduled.",
        send_reminders: bookingPage.send_reminders !== false,
        allow_reschedule: bookingPage.allow_reschedule !== false,
        target_calendar_id: bookingPage.target_calendar_id || "",
        conflict_calendar_ids: bookingPage.conflict_calendar_ids || []
      });
    } else {
      setFormData({
        title: "",
        slug: "",
        description: "",
        duration_minutes: 30,
        buffer_before: 0,
        buffer_after: 0,
        max_days_ahead: 60,
        is_active: true,
        form_id: "",
        availability_rules: defaultAvailability,
        confirmation_message: "Your meeting has been scheduled. We look forward to speaking with you.",
        send_reminders: true,
        allow_reschedule: true,
        target_calendar_id: "",
        conflict_calendar_ids: []
      });
    }
  }, [bookingPage]);

  const handleTitleChange = (title) => {
    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
    setFormData({ ...formData, title, slug });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      ...bookingPage,
      ...formData
    });
  };

  const handleDelete = () => {
    if (bookingPage?.id && onDelete) {
      onDelete(bookingPage.id);
    }
  };

  const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];

  const { data: connectedCalendars = [] } = useQuery({
    queryKey: ["connectedCalendars"],
    queryFn: () => base44.entities.ConnectedCalendar.list(),
    enabled: isOpen
  });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto rounded-none border-[#e8e8e8]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-semibold text-[#20242d]">
            {bookingPage ? "Edit Booking Page" : "New Booking Page"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          {/* Basic Info */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Title
              </Label>
              <Input
                value={formData.title}
                onChange={(e) => handleTitleChange(e.target.value)}
                placeholder="30 Minute Meeting"
                className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                required
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                URL Slug
              </Label>
              <div className="flex items-center">
                <span className="h-10 px-3 flex items-center bg-[#fafafa] border border-r-0 border-[#e8e8e8] text-[13px] text-[#666]">
                  /book/
                </span>
                <Input
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  placeholder="30-minute-meeting"
                  className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Description
              </Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="What is this meeting about?"
                className="min-h-[80px] rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0 resize-none"
              />
            </div>
          </div>

          {/* Duration Settings */}
          <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
            <h4 className="text-[13px] font-medium text-[#20242d]">Duration & Buffers</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-[12px] text-[#666]">Duration (min)</Label>
                <Select
                  value={String(formData.duration_minutes)}
                  onValueChange={(v) => setFormData({ ...formData, duration_minutes: parseInt(v) })}
                >
                  <SelectTrigger className="h-10 rounded-none border-[#e8e8e8]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-none">
                    <SelectItem value="15">15 min</SelectItem>
                    <SelectItem value="30">30 min</SelectItem>
                    <SelectItem value="45">45 min</SelectItem>
                    <SelectItem value="60">60 min</SelectItem>
                    <SelectItem value="90">90 min</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-[12px] text-[#666]">Buffer Before</Label>
                <Select
                  value={String(formData.buffer_before)}
                  onValueChange={(v) => setFormData({ ...formData, buffer_before: parseInt(v) })}
                >
                  <SelectTrigger className="h-10 rounded-none border-[#e8e8e8]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-none">
                    <SelectItem value="0">None</SelectItem>
                    <SelectItem value="5">5 min</SelectItem>
                    <SelectItem value="10">10 min</SelectItem>
                    <SelectItem value="15">15 min</SelectItem>
                    <SelectItem value="30">30 min</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-[12px] text-[#666]">Buffer After</Label>
                <Select
                  value={String(formData.buffer_after)}
                  onValueChange={(v) => setFormData({ ...formData, buffer_after: parseInt(v) })}
                >
                  <SelectTrigger className="h-10 rounded-none border-[#e8e8e8]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-none">
                    <SelectItem value="0">None</SelectItem>
                    <SelectItem value="5">5 min</SelectItem>
                    <SelectItem value="10">10 min</SelectItem>
                    <SelectItem value="15">15 min</SelectItem>
                    <SelectItem value="30">30 min</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Availability */}
          <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
            <h4 className="text-[13px] font-medium text-[#20242d]">Availability</h4>
            <div className="space-y-3">
              {days.map((day) => (
                <div key={day} className="flex items-center gap-4">
                  <div className="w-24">
                    <Switch
                      checked={formData.availability_rules[day]?.enabled}
                      onCheckedChange={(checked) =>
                        setFormData({
                          ...formData,
                          availability_rules: {
                            ...formData.availability_rules,
                            [day]: { ...formData.availability_rules[day], enabled: checked }
                          }
                        })
                      }
                    />
                    <span className="ml-2 text-[13px] text-[#20242d] capitalize">{day}</span>
                  </div>
                  {formData.availability_rules[day]?.enabled && (
                    <div className="flex items-center gap-2">
                      <Input
                        type="time"
                        value={formData.availability_rules[day]?.start || "09:00"}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            availability_rules: {
                              ...formData.availability_rules,
                              [day]: { ...formData.availability_rules[day], start: e.target.value }
                            }
                          })
                        }
                        className="h-9 w-28 rounded-none border-[#e8e8e8] text-[13px]"
                      />
                      <span className="text-[#666]">–</span>
                      <Input
                        type="time"
                        value={formData.availability_rules[day]?.end || "17:00"}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            availability_rules: {
                              ...formData.availability_rules,
                              [day]: { ...formData.availability_rules[day], end: e.target.value }
                            }
                          })
                        }
                        className="h-9 w-28 rounded-none border-[#e8e8e8] text-[13px]"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Form attachment */}
          {forms.length > 0 && (
            <div className="space-y-2 pt-4 border-t border-[#e8e8e8]">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Intake Form
              </Label>
              <Select
                value={formData.form_id || "none"}
                onValueChange={(v) => setFormData({ ...formData, form_id: v === "none" ? "" : v })}
              >
                <SelectTrigger className="h-10 rounded-none border-[#e8e8e8]">
                  <SelectValue placeholder="Select a form" />
                </SelectTrigger>
                <SelectContent className="rounded-none">
                  <SelectItem value="none">No form</SelectItem>
                  {forms.map((form) => (
                    <SelectItem key={form.id} value={form.id}>
                      {form.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Calendar Settings */}
          {connectedCalendars.length > 0 && (
            <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
              <h4 className="text-[13px] font-medium text-[#20242d]">Calendar Settings</h4>
              
              <div className="space-y-2">
                <Label className="text-[13px] font-medium text-[#20242d]">
                  Target Calendar
                </Label>
                <Select
                  value={formData.target_calendar_id || ""}
                  onValueChange={(v) => setFormData({ ...formData, target_calendar_id: v })}
                >
                  <SelectTrigger className="h-10 rounded-none border-[#e8e8e8]">
                    <SelectValue placeholder="Select calendar to create events in" />
                  </SelectTrigger>
                  <SelectContent className="rounded-none">
                    {[...new Map(connectedCalendars.map(item => [item.calendar_id, item])).values()].map((cal) => (
                      <SelectItem key={cal.id} value={cal.calendar_id}>
                        {cal.calendar_name || cal.calendar_id}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-[13px] font-medium text-[#20242d]">
                  Check Conflicts In
                </Label>
                <div className="space-y-2 p-3 border border-[#e8e8e8] bg-[#fafafa]">
                  {[...new Map(connectedCalendars.map(item => [item.calendar_id, item])).values()].map((cal) => (
                    <div key={cal.id} className="flex items-center justify-between">
                      <Label htmlFor={`conflict-${cal.id}`} className="text-[13px] text-[#20242d] cursor-pointer">
                        {cal.calendar_name || cal.calendar_id}
                      </Label>
                      <Switch
                        id={`conflict-${cal.id}`}
                        checked={formData.conflict_calendar_ids.includes(cal.calendar_id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setFormData({
                              ...formData,
                              conflict_calendar_ids: [...formData.conflict_calendar_ids, cal.calendar_id]
                            });
                          } else {
                            setFormData({
                              ...formData,
                              conflict_calendar_ids: formData.conflict_calendar_ids.filter(id => id !== cal.calendar_id)
                            });
                          }
                        }}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Options */}
          <div className="space-y-4 pt-4 border-t border-[#e8e8e8]">
            <h4 className="text-[13px] font-medium text-[#20242d]">Options</h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-[13px] text-[#20242d]">Active</Label>
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-[13px] text-[#20242d]">Send Reminders</Label>
                <Switch
                  checked={formData.send_reminders}
                  onCheckedChange={(checked) => setFormData({ ...formData, send_reminders: checked })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-[13px] text-[#20242d]">Allow Rescheduling</Label>
                <Switch
                  checked={formData.allow_reschedule}
                  onCheckedChange={(checked) => setFormData({ ...formData, allow_reschedule: checked })}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-[12px] text-[#666]">Booking Window</Label>
                <Select
                  value={String(formData.max_days_ahead)}
                  onValueChange={(v) => setFormData({ ...formData, max_days_ahead: parseInt(v) })}
                >
                  <SelectTrigger className="h-10 rounded-none border-[#e8e8e8]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-none">
                    <SelectItem value="10">10 Days</SelectItem>
                    <SelectItem value="30">30 Days</SelectItem>
                    <SelectItem value="60">60 Days</SelectItem>
                    <SelectItem value="90">90 Days</SelectItem>
                    <SelectItem value="180">180 Days</SelectItem>
                    <SelectItem value="365">365 Days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <DialogFooter className="flex justify-between pt-4">
            {bookingPage?.id && (
              <Button
                type="button"
                variant="ghost"
                onClick={handleDelete}
                className="text-red-600 hover:text-red-700 hover:bg-red-50 rounded-none"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
            )}
            <div className="flex gap-2 ml-auto">
              <Button
                type="button"
                variant="outline"
                onClick={() => onClose(false)}
                className="rounded-none border-[#e8e8e8]"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-[#20242d] hover:bg-[#2d323d] rounded-none"
              >
                {bookingPage ? "Update" : "Create"}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}