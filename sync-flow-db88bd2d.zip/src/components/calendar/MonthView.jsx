import React, { useState } from "react";
import {
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  format,
  isSameMonth,
  isSameDay,
  isToday,
  differenceInMinutes,
  addMinutes,
  setHours,
  setMinutes,
  startOfDay
} from "date-fns";

export default function MonthView({ currentDate, events, onEventClick, onDateClick, onEventDrop }) {
  const [draggedEvent, setDraggedEvent] = useState(null);
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 0 });
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 0 });
  
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });
  const weeks = [];
  for (let i = 0; i < days.length; i += 7) {
    weeks.push(days.slice(i, i + 7));
  }

  const getEventsForDay = (day) => {
    return events.filter((event) => isSameDay(new Date(event.start_time), day));
  };

  const handleDragStart = (e, event) => {
    e.stopPropagation();
    setDraggedEvent(event);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e, day) => {
    e.preventDefault();
    e.stopPropagation();
    if (!draggedEvent || !onEventDrop) return;

    const originalStart = new Date(draggedEvent.start_time);
    const originalEnd = new Date(draggedEvent.end_time);
    const duration = differenceInMinutes(originalEnd, originalStart);
    
    const newStartTime = setMinutes(setHours(startOfDay(day), originalStart.getHours()), originalStart.getMinutes());
    const newEndTime = addMinutes(newStartTime, duration);

    onEventDrop(draggedEvent.id, newStartTime.toISOString(), newEndTime.toISOString());
    setDraggedEvent(null);
  };

  const handleDragEnd = () => {
    setDraggedEvent(null);
  };

  return (
    <div className="flex flex-col h-full bg-white overflow-hidden">
      {/* Day headers */}
      <div className="grid grid-cols-7 border-b border-[#e8e8e8] flex-shrink-0">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day, idx) => (
          <div
            key={day}
            className="h-8 md:h-10 flex items-center justify-center text-[11px] md:text-[12px] font-medium text-[#666] uppercase tracking-wide"
          >
            <span className="md:hidden">{day[0]}</span>
            <span className="hidden md:inline">{day}</span>
          </div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="flex-1 grid grid-rows-5 overflow-auto">
        {weeks.map((week, weekIndex) => (
          <div key={weekIndex} className="grid grid-cols-7 border-b border-[#e8e8e8] last:border-b-0">
            {week.map((day) => {
              const dayEvents = getEventsForDay(day);
              const isCurrentMonth = isSameMonth(day, currentDate);
              const isCurrentDay = isToday(day);

              return (
                <div
                  key={day.toISOString()}
                  className={`min-h-[80px] md:min-h-[120px] p-1 md:p-2 border-r border-[#e8e8e8] last:border-r-0 cursor-pointer transition-colors hover:bg-[#fafafa] ${
                    !isCurrentMonth ? "bg-[#fafafa]" : ""
                  }`}
                  onClick={() => onDateClick(day)}
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDrop(e, day)}
                >
                  <div className="flex items-center justify-center mb-1">
                    <span
                      className={`h-6 w-6 md:h-7 md:w-7 flex items-center justify-center text-[11px] md:text-[13px] font-medium ${
                        isCurrentDay
                          ? "bg-[#20242d] text-white"
                          : isCurrentMonth
                          ? "text-[#20242d]"
                          : "text-[#999]"
                      }`}
                    >
                      {format(day, "d")}
                    </span>
                  </div>
                  <div className="space-y-0.5 md:space-y-1">
                    {dayEvents.slice(0, 2).map((event) => (
                      <div
                        key={event.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, event)}
                        onDragEnd={handleDragEnd}
                        className="px-1 md:px-2 py-0.5 md:py-1 bg-[#20242d] text-white text-[9px] md:text-[11px] truncate cursor-move hover:bg-[#2d323d] transition-colors"
                        onClick={(e) => {
                          e.stopPropagation();
                          onEventClick(event);
                        }}
                      >
                        {event.title}
                      </div>
                    ))}
                    {dayEvents.length > 2 && (
                      <div className="px-1 md:px-2 text-[9px] md:text-[11px] text-[#666]">
                        +{dayEvents.length - 2}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}