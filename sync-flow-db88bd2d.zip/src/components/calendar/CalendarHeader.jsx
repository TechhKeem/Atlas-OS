import React from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { format, startOfWeek, endOfWeek } from "date-fns";

export default function CalendarHeader({ 
  currentDate, 
  view, 
  onViewChange, 
  onPrevious, 
  onNext, 
  onToday,
  onCreateEvent 
}) {
  const getDateRangeText = () => {
    if (view === "day") {
      return format(currentDate, "EEEE, MMMM d, yyyy");
    } else if (view === "week") {
      const start = startOfWeek(currentDate, { weekStartsOn: 0 });
      const end = endOfWeek(currentDate, { weekStartsOn: 0 });
      if (format(start, "MMM") === format(end, "MMM")) {
        return `${format(start, "MMMM d")} – ${format(end, "d, yyyy")}`;
      }
      return `${format(start, "MMM d")} – ${format(end, "MMM d, yyyy")}`;
    } else {
      return format(currentDate, "MMMM yyyy");
    }
  };

  return (
    <div className="flex items-center justify-between h-14 px-3 md:px-6 border-b border-[#e8e8e8] bg-white flex-shrink-0">
      <div className="flex items-center gap-2 md:gap-4">
        <h1 className="text-[13px] md:text-[15px] font-semibold text-[#20242d]">
          {getDateRangeText()}
        </h1>
        <div className="flex items-center gap-0.5 md:gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={onPrevious}
            className="h-8 w-8 p-0 text-[#20242d] hover:bg-[#f5f5f5]"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onNext}
            className="h-8 w-8 p-0 text-[#20242d] hover:bg-[#f5f5f5]"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToday}
            className="h-8 px-2 md:px-3 text-[12px] md:text-[13px] text-[#20242d] hover:bg-[#f5f5f5]"
          >
            Today
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-2 md:gap-3">
        <div className="hidden md:flex items-center bg-[#f5f5f5] p-0.5">
          {["day", "week", "month"].map((v) => (
            <Button
              key={v}
              variant="ghost"
              size="sm"
              onClick={() => onViewChange(v)}
              className={`h-7 px-3 text-[13px] capitalize rounded-none ${
                view === v
                  ? "bg-white text-[#20242d] shadow-sm"
                  : "text-[#666] hover:text-[#20242d] hover:bg-transparent"
              }`}
            >
              {v}
            </Button>
          ))}
        </div>
        <Select value={view} onValueChange={onViewChange}>
          <SelectTrigger className="md:hidden w-16 h-8 rounded-none border-[#e8e8e8] text-[11px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="rounded-none">
            <SelectItem value="day">Day</SelectItem>
            <SelectItem value="week">Week</SelectItem>
            <SelectItem value="month">Month</SelectItem>
          </SelectContent>
        </Select>
        <Button
          onClick={onCreateEvent}
          className="h-8 px-2 md:px-3 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
        >
          <Plus className="h-4 w-4 md:mr-1.5" />
          <span className="hidden md:inline">New Event</span>
        </Button>
      </div>
    </div>
  );
}