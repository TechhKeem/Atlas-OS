import React, { useState } from "react";
import {
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  format,
  isSameDay,
  isToday,
  addMinutes,
  differenceInMinutes,
  setHours,
  setMinutes
} from "date-fns";

const HOUR_HEIGHT = 60;
const START_HOUR = 6;
const END_HOUR = 22;

export default function WeekView({ currentDate, events, onEventClick, onTimeSlotClick, onEventDrop }) {
  const [draggedEvent, setDraggedEvent] = useState(null);
  const weekStart = startOfWeek(currentDate, { weekStartsOn: 0 });
  const weekEnd = endOfWeek(currentDate, { weekStartsOn: 0 });
  const days = eachDayOfInterval({ start: weekStart, end: weekEnd });
  const hours = Array.from({ length: END_HOUR - START_HOUR }, (_, i) => START_HOUR + i);

  const isAllDayEvent = (event) => {
    const start = new Date(event.start_time);
    const end = new Date(event.end_time);
    const durationInHours = differenceInMinutes(end, start) / 60;
    return durationInHours >= 12;
  };

  const getEventsForDay = (day) => {
    return events.filter((event) => isSameDay(new Date(event.start_time), day) && !isAllDayEvent(event));
  };

  const getAllDayEventsForDay = (day) => {
    return events.filter((event) => isSameDay(new Date(event.start_time), day) && isAllDayEvent(event));
  };

  const getEventStyle = (event) => {
    const start = new Date(event.start_time);
    const end = new Date(event.end_time);
    const startMinutes = start.getHours() * 60 + start.getMinutes() - START_HOUR * 60;
    const duration = differenceInMinutes(end, start);
    
    return {
      top: `${(startMinutes / 60) * HOUR_HEIGHT}px`,
      height: `${Math.max((duration / 60) * HOUR_HEIGHT, 24)}px`
    };
  };

  const handleTimeSlotClick = (day, hour) => {
    const clickedTime = setMinutes(setHours(day, hour), 0);
    onTimeSlotClick(clickedTime);
  };

  const handleDragStart = (e, event) => {
    setDraggedEvent(event);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e, day, hour) => {
    e.preventDefault();
    if (!draggedEvent || !onEventDrop) return;

    const newStartTime = setMinutes(setHours(day, hour), 0);
    const originalStart = new Date(draggedEvent.start_time);
    const originalEnd = new Date(draggedEvent.end_time);
    const duration = differenceInMinutes(originalEnd, originalStart);
    const newEndTime = addMinutes(newStartTime, duration);

    onEventDrop(draggedEvent.id, newStartTime.toISOString(), newEndTime.toISOString());
    setDraggedEvent(null);
  };

  const handleDragEnd = () => {
    setDraggedEvent(null);
  };

  return (
    <div className="flex flex-col h-full bg-white overflow-hidden">
      {/* Day headers */}
      <div className="flex border-b border-[#e8e8e8] flex-shrink-0">
        <div className="w-12 md:w-16 flex-shrink-0" />
        {days.map((day) => {
          const isCurrentDay = isToday(day);
          return (
            <div
              key={day.toISOString()}
              className="flex-1 py-2 md:py-3 text-center border-l border-[#e8e8e8]"
            >
              <div className="text-[10px] md:text-[11px] font-medium text-[#666] uppercase tracking-wide">
                {format(day, "EEE")}
              </div>
              <div
                className={`mt-1 h-6 w-6 md:h-8 md:w-8 mx-auto flex items-center justify-center text-[13px] md:text-[15px] font-semibold ${
                  isCurrentDay ? "bg-[#20242d] text-white" : "text-[#20242d]"
                }`}
              >
                {format(day, "d")}
              </div>
            </div>
          );
        })}
      </div>

      {/* Time grid */}
      <div className="flex-1 overflow-auto">
        <div className="flex relative min-w-[640px]">
          {/* Time labels */}
          <div className="w-12 md:w-16 flex-shrink-0">
            {hours.map((hour) => (
              <div
                key={hour}
                className="relative"
                style={{ height: HOUR_HEIGHT }}
              >
                <span className="absolute -top-2 right-2 md:right-3 text-[10px] md:text-[11px] text-[#999]">
                  {format(setHours(new Date(), hour), "h a")}
                </span>
              </div>
            ))}
          </div>

          {/* Day columns */}
          {days.map((day) => {
            const dayEvents = getEventsForDay(day);
            const dayAllDayEvents = getAllDayEventsForDay(day);
            return (
              <div
                key={day.toISOString()}
                className="flex-1 relative border-l border-[#e8e8e8]"
              >
                {/* All-day events */}
                {dayAllDayEvents.length > 0 && (
                  <div className="absolute top-0 left-0 right-0 p-1 bg-[#f5f5f5] border-b border-[#e8e8e8] flex flex-wrap gap-1 items-center justify-center z-10">
                    {dayAllDayEvents.map(event => (
                      <div
                        key={event.id}
                        className="text-[9px] md:text-[10px] px-1.5 py-0.5 bg-[#20242d]/50 text-white truncate max-w-full cursor-pointer hover:bg-[#20242d]/60 transition-colors"
                        onClick={() => onEventClick(event)}
                        title={event.title}
                      >
                        {event.title}
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Hour slots */}
                {hours.map((hour) => (
                  <div
                    key={hour}
                    className="border-b border-[#e8e8e8] cursor-pointer hover:bg-[#fafafa] transition-colors"
                    style={{ height: HOUR_HEIGHT }}
                    onClick={() => handleTimeSlotClick(day, hour)}
                    onDragOver={handleDragOver}
                    onDrop={(e) => handleDrop(e, day, hour)}
                  />
                ))}

                {/* Events */}
                <div className="absolute inset-0 pointer-events-none">
                  {dayEvents.map((event) => {
                    const isPastOrDeclined = new Date(event.end_time) < new Date() || event.status === 'cancelled';
                    return (
                      <div
                        key={event.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, event)}
                        onDragEnd={handleDragEnd}
                        className={`absolute left-0.5 right-0.5 md:left-1 md:right-1 px-1 md:px-2 py-1 bg-[#20242d] text-white overflow-hidden cursor-move pointer-events-auto hover:bg-[#2d323d] transition-colors ${isPastOrDeclined ? 'opacity-60' : ''}`}
                        style={getEventStyle(event)}
                        onClick={() => onEventClick(event)}
                      >
                        <div className="text-[10px] md:text-[11px] font-medium truncate">
                          {event.title}
                        </div>
                        <div className="text-[9px] md:text-[10px] opacity-80">
                          {format(new Date(event.start_time), "h:mm a")}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}