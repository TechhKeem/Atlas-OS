import React from "react";
import { Button } from "@/components/ui/button";
import { Plus, Filter, ArrowUpDown, Settings, Save, Trash2, Settings2, MoreVertical, Download, Upload } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function DatabaseHeader({
  views,
  activeView,
  onViewChange,
  onCreateRecord,
  onOpenFilter,
  onOpenFields,
  onSaveView,
  onDeleteView,
  fields,
  sortField,
  sortDirection,
  onSortChange,
  hasActiveFilters,
  groupBy,
  groupByType,
  onGroupChange,
  onExport,
  onImport
}) {
  const defaultFields = [
    { name: "title", label: "Name" },
    { name: "client_email", label: "Email" },
    { name: "status", label: "Status" },
    { name: "scheduled_date", label: "Scheduled" },
    { name: "created_date", label: "Created" }
  ];

  const allFields = fields.length > 0 ? fields : defaultFields;
  return (
    <div className="flex items-center justify-between h-14 px-6 border-b border-[#e8e8e8] bg-white">
      <div className="flex items-center gap-3">
        <h1 className="text-[16px] font-semibold text-[#20242d]">Database</h1>
        
        <Select value={activeView?.id} onValueChange={(id) => {
          const view = views.find(v => v.id === id);
          if (view) onViewChange(view);
        }}>
          <SelectTrigger className="h-8 w-48 rounded-none border-[#e8e8e8] text-[13px]">
            <SelectValue placeholder="Select view" />
          </SelectTrigger>
          <SelectContent className="rounded-none">
            {views.map((view) => (
              <SelectItem key={view.id} value={view.id}>
                {view.name} {view.is_default && "(Default)"}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 rounded-none text-[#666] hover:text-[#20242d]"
            >
              <Settings2 className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="rounded-none w-48">
            <DropdownMenuItem onClick={onSaveView} className="text-[13px]">
              <Save className="h-4 w-4 mr-2" />
              Save Current View
            </DropdownMenuItem>
            {activeView && !activeView.is_default && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => onDeleteView(activeView.id)} 
                  className="text-[13px] text-red-600 focus:text-red-700"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete View
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="flex items-center gap-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className={`h-8 px-3 text-[13px] rounded-none ${
                hasActiveFilters 
                  ? "text-[#20242d] bg-[#f5f5f5]"
                  : "text-[#666] hover:text-[#20242d] hover:bg-[#f5f5f5]"
              }`}
            >
              <MoreVertical className="h-4 w-4 mr-1.5" />
              View Options
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 rounded-none">
            <DropdownMenuItem onClick={onOpenFilter} className="text-[13px]">
              <Filter className="h-4 w-4 mr-2" />
              Filter {hasActiveFilters && "✓"}
            </DropdownMenuItem>
            
            <DropdownMenuSub>
              <DropdownMenuSubTrigger className="text-[13px]">
                <ArrowUpDown className="h-4 w-4 mr-2" />
                Sort
              </DropdownMenuSubTrigger>
              <DropdownMenuSubContent className="rounded-none">
                {allFields.map((field) => (
                  <React.Fragment key={field.name}>
                    <DropdownMenuItem 
                      className="text-[13px]"
                      onClick={() => onSortChange(field.name, 'asc')}
                    >
                      {field.label} {field.name.includes('date') ? '(Oldest first)' : '(A → Z)'}
                      {sortField === field.name && sortDirection === 'asc' && ' ✓'}
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      className="text-[13px]"
                      onClick={() => onSortChange(field.name, 'desc')}
                    >
                      {field.label} {field.name.includes('date') ? '(Newest first)' : '(Z → A)'}
                      {sortField === field.name && sortDirection === 'desc' && ' ✓'}
                    </DropdownMenuItem>
                  </React.Fragment>
                ))}
              </DropdownMenuSubContent>
            </DropdownMenuSub>

            <DropdownMenuSub>
              <DropdownMenuSubTrigger className="text-[13px]">
                <Settings className="h-4 w-4 mr-2" />
                Group By
              </DropdownMenuSubTrigger>
              <DropdownMenuSubContent className="rounded-none">
                <DropdownMenuItem onClick={() => onGroupChange(null, null)} className="text-[13px]">
                  No Grouping {!groupBy && "✓"}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                {allFields.map((field) => (
                  <DropdownMenuItem
                    key={field.name}
                    onClick={() => onGroupChange(field.name, field.type === "date" ? "month" : null)}
                    className="text-[13px]"
                  >
                    {field.label} {groupBy === field.name && "✓"}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuSubContent>
            </DropdownMenuSub>

            {groupBy && allFields.find(f => f.name === groupBy)?.type === "date" && (
              <DropdownMenuSub>
                <DropdownMenuSubTrigger className="text-[13px]">
                  Date Grouping
                </DropdownMenuSubTrigger>
                <DropdownMenuSubContent className="rounded-none">
                  <DropdownMenuItem onClick={() => onGroupChange(groupBy, "day")} className="text-[13px]">
                    By Day {groupByType === "day" && "✓"}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onGroupChange(groupBy, "week")} className="text-[13px]">
                    By Week {groupByType === "week" && "✓"}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onGroupChange(groupBy, "month")} className="text-[13px]">
                    By Month {groupByType === "month" && "✓"}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onGroupChange(groupBy, "year")} className="text-[13px]">
                    By Year {groupByType === "year" && "✓"}
                  </DropdownMenuItem>
                </DropdownMenuSubContent>
              </DropdownMenuSub>
            )}

            <DropdownMenuSeparator />
            
            <DropdownMenuItem onClick={onOpenFields} className="text-[13px]">
              <Settings className="h-4 w-4 mr-2" />
              Manage Fields
            </DropdownMenuItem>

            <DropdownMenuSeparator />

            <DropdownMenuItem onClick={onExport} className="text-[13px]">
              <Download className="h-4 w-4 mr-2" />
              Export to CSV
            </DropdownMenuItem>
            
            <DropdownMenuItem onClick={onImport} className="text-[13px]">
              <Upload className="h-4 w-4 mr-2" />
              Import from CSV
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button
          onClick={onCreateRecord}
          className="h-8 px-3 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
        >
          <Plus className="h-4 w-4 mr-1.5" />
          New Record
        </Button>
      </div>
    </div>
  );
}