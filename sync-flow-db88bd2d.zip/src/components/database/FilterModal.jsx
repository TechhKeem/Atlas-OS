import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { X } from "lucide-react";

export default function FilterModal({ isOpen, onClose, fields, filters, filterOperator, onFiltersChange }) {
  const [localFilters, setLocalFilters] = useState(filters || []);
  const [localOperator, setLocalOperator] = useState(filterOperator || "and");

  const defaultFields = [
    { name: "title", label: "Name", type: "text" },
    { name: "client_email", label: "Email", type: "email" },
    { name: "status", label: "Status", type: "select" },
    { name: "scheduled_date", label: "Scheduled", type: "date" },
    { name: "created_date", label: "Created", type: "date" }
  ];

  const allFields = fields.length > 0 ? fields : defaultFields;

  const addFilter = () => {
    setLocalFilters([...localFilters, { field: "", operator: "equals", value: "" }]);
  };

  const removeFilter = (index) => {
    setLocalFilters(localFilters.filter((_, i) => i !== index));
  };

  const updateFilter = (index, key, value) => {
    const updated = [...localFilters];
    updated[index][key] = value;
    setLocalFilters(updated);
  };

  const handleApply = () => {
    onFiltersChange(localFilters, localOperator);
    onClose();
  };

  const handleClear = () => {
    setLocalFilters([]);
    setLocalOperator("and");
    onFiltersChange([], "and");
    onClose();
  };

  React.useEffect(() => {
    setLocalFilters(filters || []);
    setLocalOperator(filterOperator || "and");
  }, [filters, filterOperator, isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="rounded-none border-[#e8e8e8] max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-[15px] font-semibold text-[#20242d]">
            Filter Records
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3 py-4">
          {localFilters.length > 1 && (
            <div className="flex items-center gap-2 p-3 border border-[#e8e8e8] bg-[#fafafa]">
              <Label className="text-[12px] text-[#666]">Match:</Label>
              <Select value={localOperator} onValueChange={setLocalOperator}>
                <SelectTrigger className="h-8 w-40 rounded-none border-[#e8e8e8] text-[12px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="rounded-none">
                  <SelectItem value="and">All conditions (AND)</SelectItem>
                  <SelectItem value="or">Any condition (OR)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {localFilters.map((filter, index) => (
            <div key={index} className="flex items-end gap-2">
              <div className="flex-1 space-y-2">
                <Label className="text-[12px] text-[#666]">Field</Label>
                <Select
                  value={filter.field}
                  onValueChange={(value) => updateFilter(index, "field", value)}
                >
                  <SelectTrigger className="h-9 rounded-none border-[#e8e8e8] text-[13px]">
                    <SelectValue placeholder="Select field" />
                  </SelectTrigger>
                  <SelectContent className="rounded-none">
                    {allFields.map((field) => (
                      <SelectItem key={field.name} value={field.name}>
                        {field.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex-1 space-y-2">
                <Label className="text-[12px] text-[#666]">Operator</Label>
                <Select
                  value={filter.operator}
                  onValueChange={(value) => updateFilter(index, "operator", value)}
                >
                  <SelectTrigger className="h-9 rounded-none border-[#e8e8e8] text-[13px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-none">
                    <SelectItem value="equals">Equals</SelectItem>
                    <SelectItem value="contains">Contains</SelectItem>
                    <SelectItem value="not_equals">Not equals</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex-1 space-y-2">
                <Label className="text-[12px] text-[#666]">Value</Label>
                <Input
                  value={filter.value}
                  onChange={(e) => updateFilter(index, "value", e.target.value)}
                  placeholder="Enter value"
                  className="h-9 rounded-none border-[#e8e8e8] text-[13px]"
                />
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeFilter(index)}
                className="h-9 w-9 p-0 rounded-none"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}

          <Button
            variant="outline"
            size="sm"
            onClick={addFilter}
            className="h-9 rounded-none border-[#e8e8e8] text-[13px]"
          >
            Add Filter
          </Button>
        </div>

        <div className="flex justify-between pt-4 border-t border-[#e8e8e8]">
          <Button
            variant="ghost"
            onClick={handleClear}
            className="h-9 rounded-none text-[13px]"
          >
            Clear All
          </Button>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={onClose}
              className="h-9 rounded-none text-[13px]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleApply}
              className="h-9 bg-[#20242d] hover:bg-[#2d323d] rounded-none text-[13px]"
            >
              Apply Filters
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}