import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export default function SaveViewModal({ isOpen, onClose, currentView, onSave }) {
  const [viewName, setViewName] = useState("");
  const [isDefault, setIsDefault] = useState(false);

  useEffect(() => {
    if (currentView) {
      setViewName(currentView.name || "");
      setIsDefault(currentView.is_default || false);
    } else {
      setViewName("");
      setIsDefault(false);
    }
  }, [currentView, isOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(viewName, isDefault);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[400px] rounded-none border-[#e8e8e8]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-semibold text-[#20242d]">
            {currentView ? "Update View" : "Save View"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label className="text-[13px] font-medium text-[#20242d]">
              View Name
            </Label>
            <Input
              value={viewName}
              onChange={(e) => setViewName(e.target.value)}
              placeholder="My Custom View"
              className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
              required
            />
          </div>

          <div className="flex items-center justify-between p-3 border border-[#e8e8e8] bg-[#fafafa]">
            <div>
              <h4 className="text-[13px] font-medium text-[#20242d]">Set as Default View</h4>
              <p className="text-[11px] text-[#666]">This view will load automatically</p>
            </div>
            <Switch
              checked={isDefault}
              onCheckedChange={setIsDefault}
            />
          </div>

          <DialogFooter className="pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="rounded-none border-[#e8e8e8]"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-[#20242d] hover:bg-[#2d323d] rounded-none"
            >
              {currentView ? "Update" : "Save"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}