import React, { useState } from "react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronDown, ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

const statusColors = {
  new: "bg-blue-50 text-blue-700 border-blue-200",
  contacted: "bg-yellow-50 text-yellow-700 border-yellow-200",
  scheduled: "bg-purple-50 text-purple-700 border-purple-200",
  completed: "bg-green-50 text-green-700 border-green-200",
  cancelled: "bg-gray-50 text-gray-600 border-gray-200"
};

function ChildRecordsRow({ parentId, fields, displayFields, onRecordClick, renderCell }) {
  const { data: childRecords = [], isLoading } = useQuery({
    queryKey: ["child-records", parentId],
    queryFn: () => base44.entities.DatabaseRecord.filter({ parent_id: parentId }),
  });

  if (isLoading) {
    return (
      <tr>
        <td colSpan={displayFields.length + 2} className="h-12 px-6 bg-[#fafafa]">
          <div className="text-[12px] text-[#999]">Loading...</div>
        </td>
      </tr>
    );
  }

  if (childRecords.length === 0) {
    return (
      <tr>
        <td colSpan={displayFields.length + 2} className="h-12 px-6 bg-[#fafafa]">
          <div className="text-[12px] text-[#999]">No child records</div>
        </td>
      </tr>
    );
  }

  return (
    <>
      {childRecords.map((child) => (
        <tr
          key={child.id}
          className="border-b border-[#e8e8e8] bg-[#fafafa] hover:bg-[#f0f0f0] cursor-pointer transition-colors"
          onClick={() => onRecordClick(child)}
        >
          <td className="w-10 px-3"></td>
          <td className="w-10 px-3 pl-8">
            <div className="h-4 w-4 border-l-2 border-b-2 border-[#d0d0d0]"></div>
          </td>
          {displayFields.map((field) => (
            <td key={field.name} className="h-12 px-4 text-[13px]">
              {renderCell(child, field)}
            </td>
          ))}
        </tr>
      ))}
    </>
  );
}

export default function DatabaseTable({ records, fields, onRecordClick, visibleFields, selectedIds = new Set(), onSelectionChange }) {
  const [expandedRows, setExpandedRows] = useState(new Set());
  
  const toggleRow = (recordId) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(recordId)) {
      newExpanded.delete(recordId);
    } else {
      newExpanded.add(recordId);
    }
    setExpandedRows(newExpanded);
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      const newSelected = new Set(records.map(r => r.id));
      onSelectionChange?.(newSelected);
    } else {
      onSelectionChange?.(new Set());
    }
  };

  const handleSelectOne = (id, checked) => {
    const newSelected = new Set(selectedIds);
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    onSelectionChange?.(newSelected);
  };
  const defaultFields = [
    { name: "title", label: "Full Name", type: "text" },
    { name: "client_email", label: "Email", type: "email" },
    { name: "status", label: "Status", type: "select" },
    { name: "scheduled_date", label: "Scheduled", type: "date" },
    { name: "created_date", label: "Created", type: "date" }
  ];

  const allFields = fields.length > 0 ? fields : defaultFields;
  const displayFields = visibleFields && visibleFields.length > 0
    ? allFields.filter(f => visibleFields.includes(f.name))
    : allFields;

  const renderCell = (record, field) => {
    // Map field names to actual record properties
    const fieldMapping = {
      'full_name': 'title',
      'phone': 'client_phone',
      'email': 'client_email',
      'appointment_date': 'scheduled_date',
      'status': 'status',
      'reason_for_meeting': 'reason_for_meeting'
    };
    
    const actualFieldName = fieldMapping[field.name] || field.name;
    const value = record[actualFieldName] || record.custom_fields?.[field.name] || record.custom_fields?.[actualFieldName];

    if (!value) return <span className="text-[#999]">—</span>;

    switch (field.type) {
      case "date":
        return (
          <span className="text-[#20242d]">
            {format(new Date(value), "MMM d, yyyy")}
          </span>
        );
      case "select":
        return (
          <Badge
            variant="outline"
            className={`text-[11px] font-medium rounded-none ${
              field.name === "status"
                ? statusColors[value] || statusColors.new
                : "bg-gray-50 text-gray-700 border-gray-200"
            }`}
          >
            {value}
          </Badge>
        );
        case "phone":
        const digits = String(value).replace(/\D/g, '');
        let formatted = '';
        if (digits.length > 0) {
          formatted = '+1 (' + digits.substring(0, 3);
          if (digits.length >= 4) formatted += ') ' + digits.substring(3, 6);
          if (digits.length >= 7) formatted += '-' + digits.substring(6, 10);
        }
        return <span className="text-[#20242d]">{formatted || value}</span>;
        case "multiselect":
        return (
          <div className="flex gap-1 flex-wrap">
            {(Array.isArray(value) ? value : []).map((tag) => (
              <Badge
                key={tag}
                variant="outline"
                className="text-[11px] rounded-none border-[#e8e8e8]"
              >
                {tag}
              </Badge>
            ))}
          </div>
        );
      default:
        return <span className="text-[#20242d]">{String(value)}</span>;
    }
  };

  return (
    <div className="flex-1 overflow-auto">
      <table className="w-full min-w-[640px]">
        <thead className="sticky top-0 bg-[#fafafa] z-10">
          <tr className="border-b border-[#e8e8e8]">
            <th className="w-10 h-10 px-3"></th>
            <th className="w-10 h-10 px-3">
              <Checkbox 
                className="rounded-none border-[#d0d0d0]"
                checked={records.length > 0 && selectedIds.size === records.length}
                onCheckedChange={handleSelectAll}
              />
            </th>
            {displayFields.map((field) => (
              <th
                key={field.name}
                className="h-10 px-4 text-left text-[12px] font-medium text-[#666] uppercase tracking-wide whitespace-nowrap"
              >
                {field.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {records.map((record) => {
            const isExpanded = expandedRows.has(record.id);
            return (
              <React.Fragment key={record.id}>
                <tr
                  className="border-b border-[#e8e8e8] hover:bg-[#fafafa] transition-colors"
                >
                  <td className="w-10 px-3">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleRow(record.id);
                      }}
                      className="text-[#666] hover:text-[#20242d]"
                    >
                      {isExpanded ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                    </button>
                  </td>
                  <td className="w-10 px-3">
                    <Checkbox
                      className="rounded-none border-[#d0d0d0]"
                      checked={selectedIds.has(record.id)}
                      onCheckedChange={(checked) => handleSelectOne(record.id, checked)}
                      onClick={(e) => e.stopPropagation()}
                    />
                  </td>
                  {displayFields.map((field) => (
                    <td 
                      key={field.name} 
                      className="h-12 px-4 text-[13px] cursor-pointer"
                      onClick={() => onRecordClick(record)}
                    >
                      {renderCell(record, field)}
                    </td>
                  ))}
                </tr>
                {isExpanded && (
                  <ChildRecordsRow
                    parentId={record.id}
                    fields={fields}
                    displayFields={displayFields}
                    onRecordClick={onRecordClick}
                    renderCell={renderCell}
                  />
                )}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>

      {records.length === 0 && (
        <div className="h-64 flex items-center justify-center text-[#999] text-[14px]">
          No records yet
        </div>
      )}
    </div>
  );
}