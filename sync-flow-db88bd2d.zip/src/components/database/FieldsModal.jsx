import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, GripVertical, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

export default function FieldsModal({ isOpen, onClose, fields, visibleFields, onVisibleFieldsChange }) {
  const queryClient = useQueryClient();
  const defaultFields = [
    { name: "title", label: "Name", type: "text" },
    { name: "client_email", label: "Email", type: "email" },
    { name: "status", label: "Status", type: "select" },
    { name: "scheduled_date", label: "Scheduled", type: "date" },
    { name: "created_date", label: "Created", type: "date" }
  ];

  const allFields = fields.length > 0 ? fields : defaultFields;
  const [orderedFields, setOrderedFields] = useState(allFields);
  const [localVisible, setLocalVisible] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newField, setNewField] = useState({
    name: "",
    label: "",
    type: "text",
    options: ""
  });

  useEffect(() => {
    setOrderedFields(allFields);
    // Initialize localVisible based on is_visible property
    const visibleFieldNames = allFields
      .filter(f => f.is_visible !== false)
      .map(f => f.name);
    setLocalVisible(visibleFieldNames);
  }, [fields]);

  const createFieldMutation = useMutation({
    mutationFn: async (fieldData) => {
      return base44.entities.DatabaseField.create({
        ...fieldData,
        order: fields.length,
        is_visible: true
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-fields"] });
      setNewField({ name: "", label: "", type: "text", options: "" });
      setShowCreateForm(false);
    }
  });

  const updateFieldOrderMutation = useMutation({
    mutationFn: async (fieldsToUpdate) => {
      const promises = fieldsToUpdate.map((field) =>
        base44.entities.DatabaseField.update(field.id, { order: field.order })
      );
      return Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-fields"] });
    }
  });

  const deleteFieldMutation = useMutation({
    mutationFn: async (fieldId) => {
      return base44.entities.DatabaseField.delete(fieldId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-fields"] });
    }
  });

  const toggleFieldMutation = useMutation({
    mutationFn: async ({ fieldId, isVisible }) => {
      return base44.entities.DatabaseField.update(fieldId, { is_visible: isVisible });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["database-fields"] });
    }
  });

  const toggleField = (field) => {
    const isCurrentlyVisible = localVisible.includes(field.name);
    const newVisible = isCurrentlyVisible
      ? localVisible.filter(f => f !== field.name)
      : [...localVisible, field.name];
    
    setLocalVisible(newVisible);
    
    if (field.id) {
      toggleFieldMutation.mutate({ fieldId: field.id, isVisible: !isCurrentlyVisible });
    }
  };

  const handleApply = () => {
    const newVisibleOrderedFields = orderedFields
      .filter(field => localVisible.includes(field.name))
      .map(field => field.name);
    onVisibleFieldsChange(newVisibleOrderedFields);
    onClose();
  };

  const handleShowAll = () => {
    setLocalVisible(orderedFields.map(f => f.name));
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(orderedFields);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setOrderedFields(items);

    // Update order in backend if fields have IDs
    if (items[0]?.id) {
      const fieldsToUpdate = items.map((field, index) => ({
        id: field.id,
        order: index
      }));
      updateFieldOrderMutation.mutate(fieldsToUpdate);
    }
  };

  const handleCreateField = () => {
    if (!newField.label || !newField.type) return;

    const fieldName = newField.label.toLowerCase().replace(/\s+/g, '_');
    const fieldData = {
      name: fieldName,
      label: newField.label,
      type: newField.type
    };

    // Add options array for select/multiselect
    if (newField.type === "select" || newField.type === "multiselect") {
      fieldData.options = newField.options
        ? newField.options.split(',').map(opt => opt.trim()).filter(Boolean)
        : [];
    }

    createFieldMutation.mutate(fieldData);
  };

  const handleDeleteField = (field) => {
    if (!field.id) {
      alert(`Cannot delete "${field.label}" - this field is not in the database.`);
      return;
    }
    
    if (window.confirm(`Delete "${field.label}" field? This will remove it from all records. This cannot be undone.`)) {
      deleteFieldMutation.mutate(field.id);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="rounded-none border-[#e8e8e8] max-w-md">
        <DialogHeader>
          <DialogTitle className="text-[15px] font-semibold text-[#20242d]">
            Manage Fields
          </DialogTitle>
        </DialogHeader>

        {showCreateForm ? (
          <div className="py-4 space-y-4 border-b border-[#e8e8e8]">
            <div className="space-y-2">
              <Label className="text-[12px] text-[#666]">Field Label</Label>
              <Input
                value={newField.label}
                onChange={(e) => setNewField({ ...newField, label: e.target.value })}
                placeholder="e.g. Phone Number"
                className="h-9 rounded-none border-[#e8e8e8] text-[13px]"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[12px] text-[#666]">Field Type</Label>
              <Select
                value={newField.type}
                onValueChange={(value) => setNewField({ ...newField, type: value })}
              >
                <SelectTrigger className="h-9 rounded-none border-[#e8e8e8] text-[13px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="rounded-none">
                  <SelectItem value="text">Text</SelectItem>
                  <SelectItem value="number">Number</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="phone">Phone</SelectItem>
                  <SelectItem value="date">Date</SelectItem>
                  <SelectItem value="url">URL</SelectItem>
                  <SelectItem value="select">Select</SelectItem>
                  <SelectItem value="multiselect">Multi-select</SelectItem>
                  <SelectItem value="checkbox">Checkbox</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(newField.type === "select" || newField.type === "multiselect") && (
              <div className="space-y-2">
                <Label className="text-[12px] text-[#666]">Options (comma-separated)</Label>
                <Input
                  value={newField.options}
                  onChange={(e) => setNewField({ ...newField, options: e.target.value })}
                  placeholder="e.g. Option 1, Option 2, Option 3"
                  className="h-9 rounded-none border-[#e8e8e8] text-[13px]"
                />
              </div>
            )}

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setShowCreateForm(false);
                  setNewField({ name: "", label: "", type: "text", options: "" });
                }}
                className="h-8 rounded-none text-[13px]"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateField}
                disabled={!newField.label || createFieldMutation.isPending}
                className="h-8 bg-[#20242d] hover:bg-[#2d323d] rounded-none text-[13px]"
              >
                {createFieldMutation.isPending ? "Creating..." : "Create Field"}
              </Button>
            </div>
          </div>
        ) : (
          <div className="py-4 border-b border-[#e8e8e8]">
            <Button
              onClick={() => setShowCreateForm(true)}
              variant="outline"
              size="sm"
              className="h-9 w-full rounded-none border-[#e8e8e8] text-[13px]"
            >
              <Plus className="h-4 w-4 mr-1.5" />
              Create Field
            </Button>
          </div>
        )}

        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="fields">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className="space-y-2 py-4 max-h-[300px] overflow-y-auto"
              >
                {orderedFields.map((field, index) => (
                  <Draggable key={field.name} draggableId={field.name} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        style={{
                          ...provided.draggableProps.style,
                          left: snapshot.isDragging ? provided.draggableProps.style?.left : undefined,
                          top: snapshot.isDragging ? provided.draggableProps.style?.top : undefined,
                        }}
                        className={`flex items-center justify-between gap-2 p-2 bg-white border border-[#e8e8e8] ${
                          snapshot.isDragging ? "shadow-lg" : ""
                        }`}
                      >
                        <div className="flex items-center gap-2 flex-1">
                          <div {...provided.dragHandleProps} className="cursor-grab text-[#999]">
                            <GripVertical className="h-4 w-4" />
                          </div>
                          <Label className="text-[13px] text-[#20242d] cursor-pointer">
                            {field.label}
                          </Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteField(field)}
                            className="h-7 w-7 p-0 text-[#999] hover:text-red-600 hover:bg-red-50"
                            disabled={!field.id}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                          <Switch
                            checked={localVisible.includes(field.name)}
                            onCheckedChange={() => toggleField(field)}
                            disabled={!field.id}
                          />
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>

        <div className="flex justify-between pt-4 border-t border-[#e8e8e8]">
          <Button
            variant="ghost"
            onClick={handleShowAll}
            className="h-9 rounded-none text-[13px]"
          >
            Show All
          </Button>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={onClose}
              className="h-9 rounded-none text-[13px]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleApply}
              className="h-9 bg-[#20242d] hover:bg-[#2d323d] rounded-none text-[13px]"
            >
              Apply
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}