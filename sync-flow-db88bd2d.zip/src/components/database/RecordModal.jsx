import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Trash2, X, Plus, Calendar, ChevronDown, ChevronRight } from "lucide-react";
import { format } from "date-fns";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function RecordModal({
  isOpen,
  onClose,
  record,
  fields,
  onSave,
  onDelete,
  parentId = null
}) {
  const [formData, setFormData] = useState({
    title: "",
    client_email: "",
    client_phone: "",
    status: "new",
    notes: "",
    tags: [],
    custom_fields: {},
    meeting_log: [],
    parent_id: parentId || ""
  });
  const [newMeetingEntry, setNewMeetingEntry] = useState({
    date: new Date().toISOString().split('T')[0],
    summary: "",
    details: ""
  });
  const [showAddMeeting, setShowAddMeeting] = useState(false);
  const [newTag, setNewTag] = useState("");
  const [allTags, setAllTags] = useState([]);
  const [showChildren, setShowChildren] = useState(true);
  const [childModalRecord, setChildModalRecord] = useState(null);
  const [isChildModalOpen, setIsChildModalOpen] = useState(false);

  const { data: databaseFields = [] } = useQuery({
    queryKey: ["database-fields"],
    queryFn: () => base44.entities.DatabaseField.list(),
    enabled: isOpen,
  });

  const { data: allRecords = [] } = useQuery({
    queryKey: ["all-records-for-tags"],
    queryFn: () => base44.entities.DatabaseRecord.list(),
    enabled: isOpen,
  });

  const { data: childRecords = [], refetch: refetchChildren } = useQuery({
    queryKey: ["child-records", record?.id],
    queryFn: () => base44.entities.DatabaseRecord.filter({ parent_id: record.id }),
    enabled: isOpen && !!record?.id,
  });

  useEffect(() => {
    if (allRecords.length > 0) {
      const tagsSet = new Set();
      allRecords.forEach(rec => {
        if (rec.tags && Array.isArray(rec.tags)) {
          rec.tags.forEach(tag => tagsSet.add(tag));
        }
      });
      setAllTags(Array.from(tagsSet).sort());
    }
  }, [allRecords]);

  useEffect(() => {
    if (record) {
      setFormData({
        title: record.title || "",
        client_email: record.client_email || "",
        client_phone: record.client_phone || "",
        status: record.status || "new",
        notes: record.notes || "",
        tags: record.tags || [],
        custom_fields: record.custom_fields || {},
        meeting_log: record.meeting_log || [],
        parent_id: record.parent_id || ""
      });
    } else {
      setFormData({
        title: "",
        client_email: "",
        client_phone: "",
        status: "new",
        notes: "",
        tags: [],
        custom_fields: {},
        meeting_log: [],
        parent_id: parentId || ""
      });
    }
    setShowAddMeeting(false);
    setNewMeetingEntry({
      date: new Date().toISOString().split('T')[0],
      summary: "",
      details: ""
    });
    setIsChildModalOpen(false);
    setChildModalRecord(null);
  }, [record, parentId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      ...record,
      ...formData
    });
  };

  const handleDelete = () => {
    if (record?.id && onDelete) {
      onDelete(record.id);
    }
  };

  const handleAddMeetingEntry = async () => {
    const user = await base44.auth.me();
    const entry = {
      ...newMeetingEntry,
      date: new Date(newMeetingEntry.date).toISOString(),
      logged_by: user.email
    };
    setFormData({
      ...formData,
      meeting_log: [entry, ...(formData.meeting_log || [])]
    });
    setNewMeetingEntry({
      date: new Date().toISOString().split('T')[0],
      summary: "",
      details: ""
    });
    setShowAddMeeting(false);
  };

  const handleDeleteMeetingEntry = (index) => {
    setFormData({
      ...formData,
      meeting_log: formData.meeting_log.filter((_, i) => i !== index)
    });
  };

  const handleAddChild = () => {
    setChildModalRecord(null);
    setIsChildModalOpen(true);
  };

  const handleChildClick = (child) => {
    setChildModalRecord(child);
    setIsChildModalOpen(true);
  };

  const handleChildSave = (childData) => {
    onSave(childData);
    setIsChildModalOpen(false);
    setChildModalRecord(null);
    setTimeout(() => refetchChildren(), 500);
  };

  const handleChildDelete = (id) => {
    onDelete(id);
    setIsChildModalOpen(false);
    setChildModalRecord(null);
    setTimeout(() => refetchChildren(), 500);
  };

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/20 z-40 transition-opacity"
          onClick={() => onClose(false)}
        />
      )}
      
      {/* Slide-in Panel */}
      <div className={`fixed top-0 right-0 h-full w-full md:w-[600px] bg-white border-l border-[#e8e8e8] z-50 transform transition-transform duration-300 ease-in-out ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#e8e8e8]">
            <h2 className="text-[16px] font-semibold text-[#20242d]">
              {record ? "Edit Record" : "New Record"}
            </h2>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => onClose(false)}
              className="h-8 w-8 rounded-none text-[#666] hover:text-[#20242d]"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Content */}
          <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-6 space-y-5">
          {/* Dynamic Fields from DatabaseField entity */}
          {databaseFields.filter(f => f.is_visible !== false).sort((a, b) => (a.order || 0) - (b.order || 0)).map((field) => {
            const fieldMapping = {
              'full_name': 'title',
              'phone': 'client_phone',
              'email': 'client_email',
              'appointment_date': 'scheduled_date'
            };
            
            const recordKey = fieldMapping[field.name] || field.name;
            const value = ['title', 'client_email', 'client_phone', 'status', 'notes', 'scheduled_date', 'tags'].includes(recordKey)
              ? formData[recordKey]
              : formData.custom_fields?.[field.name];

            const handleFieldChange = (newValue) => {
              if (['title', 'client_email', 'client_phone', 'status', 'notes', 'scheduled_date', 'tags'].includes(recordKey)) {
                setFormData({ ...formData, [recordKey]: newValue });
              } else {
                setFormData({
                  ...formData,
                  custom_fields: { ...formData.custom_fields, [field.name]: newValue }
                });
              }
            };

            return (
              <div key={field.name} className="space-y-2">
                <Label className="text-[13px] font-medium text-[#20242d]">
                  {field.label}
                </Label>
                
                {field.type === "select" && field.options ? (
                  <Select value={value || ""} onValueChange={handleFieldChange}>
                    <SelectTrigger className="h-10 rounded-none border-[#e8e8e8]">
                      <SelectValue placeholder={`Select ${field.label}`} />
                    </SelectTrigger>
                    <SelectContent className="rounded-none">
                      {field.options.map((opt) => (
                        <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : field.type === "multiselect" && field.options ? (
                  <>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {(value || []).map((item, idx) => (
                        <div key={idx} className="flex items-center gap-1 px-2 py-1 bg-[#f5f5f5] border border-[#e8e8e8] text-[12px]">
                          <span>{item}</span>
                          <button
                            type="button"
                            onClick={() => handleFieldChange(value.filter((_, i) => i !== idx))}
                            className="text-[#999] hover:text-[#666]"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                    <Select
                      value=""
                      onValueChange={(val) => {
                        if (val && !value?.includes(val)) {
                          handleFieldChange([...(value || []), val]);
                        }
                      }}
                    >
                      <SelectTrigger className="h-10 rounded-none border-[#e8e8e8]">
                        <SelectValue placeholder={`Add ${field.label}`} />
                      </SelectTrigger>
                      <SelectContent className="rounded-none">
                        {field.options.map((opt) => (
                          <SelectItem key={opt} value={opt} disabled={value?.includes(opt)}>
                            {opt}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </>
                ) : field.type === "textarea" ? (
                  <Textarea
                    value={value || ""}
                    onChange={(e) => handleFieldChange(e.target.value)}
                    placeholder={`Enter ${field.label}`}
                    className="min-h-[100px] rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0 resize-none"
                    required={field.is_required}
                  />
                ) : field.type === "phone" ? (
                  <Input
                    type="tel"
                    value={value || ""}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '');
                      let formatted = '';
                      if (val.length > 0) {
                        formatted = '+1 (' + val.substring(0, 3);
                        if (val.length >= 4) formatted += ') ' + val.substring(3, 6);
                        if (val.length >= 7) formatted += '-' + val.substring(6, 10);
                      }
                      handleFieldChange(formatted);
                    }}
                    placeholder="+1 (555) 000-0000"
                    className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                    maxLength={17}
                    required={field.is_required}
                  />
                ) : field.type === "date" ? (
                  <Input
                    type="date"
                    value={value ? new Date(value).toISOString().split('T')[0] : ""}
                    onChange={(e) => handleFieldChange(e.target.value)}
                    className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                    required={field.is_required}
                  />
                ) : field.type === "number" ? (
                  <Input
                    type="number"
                    value={value || ""}
                    onChange={(e) => handleFieldChange(parseFloat(e.target.value) || 0)}
                    placeholder={`Enter ${field.label}`}
                    className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                    required={field.is_required}
                  />
                ) : field.type === "checkbox" ? (
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={value || false}
                      onChange={(e) => handleFieldChange(e.target.checked)}
                      className="h-4 w-4 rounded border-[#e8e8e8]"
                    />
                  </div>
                ) : (
                  <Input
                    type={field.type === "email" ? "email" : field.type === "url" ? "url" : "text"}
                    value={value || ""}
                    onChange={(e) => handleFieldChange(e.target.value)}
                    placeholder={`Enter ${field.label}`}
                    className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                    required={field.is_required}
                  />
                )}
              </div>
            );
          })}

          <div className="space-y-2 pt-4 border-t border-[#e8e8e8]">
            <div className="flex items-center justify-between">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Meeting Log
              </Label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setShowAddMeeting(!showAddMeeting)}
                className="h-7 px-2 text-[12px] rounded-none"
              >
                <Plus className="h-3 w-3 mr-1" />
                Add Entry
              </Button>
            </div>

            {showAddMeeting && (
              <div className="p-3 border border-[#e8e8e8] bg-[#fafafa] space-y-2">
                <div className="space-y-1">
                  <Label className="text-[11px] text-[#666]">Date</Label>
                  <Input
                    type="date"
                    value={newMeetingEntry.date}
                    onChange={(e) => setNewMeetingEntry({ ...newMeetingEntry, date: e.target.value })}
                    className="h-8 rounded-none border-[#e8e8e8] text-[12px]"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-[11px] text-[#666]">Summary</Label>
                  <Input
                    value={newMeetingEntry.summary}
                    onChange={(e) => setNewMeetingEntry({ ...newMeetingEntry, summary: e.target.value })}
                    placeholder="Brief meeting summary"
                    className="h-8 rounded-none border-[#e8e8e8] text-[12px]"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-[11px] text-[#666]">Details</Label>
                  <Textarea
                    value={newMeetingEntry.details}
                    onChange={(e) => setNewMeetingEntry({ ...newMeetingEntry, details: e.target.value })}
                    placeholder="Meeting details and notes"
                    className="min-h-[60px] rounded-none border-[#e8e8e8] text-[12px] resize-none"
                  />
                </div>
                <div className="flex gap-2 justify-end">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowAddMeeting(false)}
                    className="h-7 px-3 text-[11px] rounded-none"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    onClick={handleAddMeetingEntry}
                    disabled={!newMeetingEntry.summary}
                    className="h-7 px-3 text-[11px] bg-[#20242d] hover:bg-[#2d323d] rounded-none"
                  >
                    Add
                  </Button>
                </div>
              </div>
            )}

            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {(formData.meeting_log || []).map((entry, index) => (
                <div key={index} className="p-3 border border-[#e8e8e8] bg-white">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2 text-[11px] text-[#666]">
                      <Calendar className="h-3 w-3" />
                      <span>{format(new Date(entry.date), "MMM d, yyyy")}</span>
                      {entry.logged_by && <span>• {entry.logged_by}</span>}
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteMeetingEntry(index)}
                      className="h-6 w-6 p-0 text-[#999] hover:text-red-600 hover:bg-red-50 rounded-none"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                  <h4 className="text-[13px] font-medium text-[#20242d] mb-1">
                    {entry.summary}
                  </h4>
                  {entry.details && (
                    <p className="text-[12px] text-[#666] whitespace-pre-wrap">
                      {entry.details}
                    </p>
                  )}
                </div>
              ))}
              {(!formData.meeting_log || formData.meeting_log.length === 0) && (
                <p className="text-[11px] text-[#999] text-center py-4">
                  No meeting entries yet
                </p>
              )}
            </div>
            </div>

            {/* Child Records Section */}
            {record?.id && (
            <div className="space-y-2 pt-4 border-t border-[#e8e8e8]">
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setShowChildren(!showChildren)}
                  className="flex items-center gap-2 text-[13px] font-medium text-[#20242d] hover:text-[#2d323d]"
                >
                  {showChildren ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                  Child Records ({childRecords.length})
                </button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={handleAddChild}
                  className="h-7 px-2 text-[12px] rounded-none"
                >
                  <Plus className="h-3 w-3 mr-1" />
                  Add Child
                </Button>
              </div>

              {showChildren && (
                <div className="space-y-1 max-h-[200px] overflow-y-auto">
                  {childRecords.length === 0 ? (
                    <p className="text-[11px] text-[#999] text-center py-4">
                      No child records yet
                    </p>
                  ) : (
                    childRecords.map((child) => (
                      <div
                        key={child.id}
                        onClick={() => handleChildClick(child)}
                        className="p-2 border border-[#e8e8e8] bg-[#fafafa] hover:bg-white cursor-pointer transition-colors"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h5 className="text-[13px] font-medium text-[#20242d]">
                              {child.title}
                            </h5>
                            {(child.client_email || child.status) && (
                              <div className="flex gap-2 mt-1">
                                {child.status && (
                                  <span className="text-[10px] px-1.5 py-0.5 bg-white border border-[#e8e8e8] text-[#666]">
                                    {child.status}
                                  </span>
                                )}
                                {child.client_email && (
                                  <span className="text-[10px] text-[#999]">
                                    {child.client_email}
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
            )}

            {/* Footer */}
            <div className="flex justify-between items-center px-6 py-4 border-t border-[#e8e8e8] bg-[#fafafa]">
              {record?.id && (
                <Button
                  type="button"
                  variant="ghost"
                  onClick={handleDelete}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50 rounded-none"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              )}
              <div className="flex gap-2 ml-auto">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => onClose(false)}
                  className="rounded-none border-[#e8e8e8]"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-[#20242d] hover:bg-[#2d323d] rounded-none"
                >
                  {record ? "Update" : "Create"}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>

      {/* Child Record Modal */}
      {isChildModalOpen && (
        <RecordModal
          isOpen={isChildModalOpen}
          onClose={() => {
            setIsChildModalOpen(false);
            setChildModalRecord(null);
          }}
          record={childModalRecord}
          fields={fields}
          onSave={handleChildSave}
          onDelete={handleChildDelete}
          parentId={record?.id}
        />
      )}
      </>
      );
      }