import { useState, useEffect } from 'react'
import { db } from '@/lib/db'
import { cn } from '@/lib/utils'

// Icons
const PlusIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12 5v14M5 12h14"/>
  </svg>
)

const CopyIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/>
    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
  </svg>
)

const CheckIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M20 6 9 17l-5-5"/>
  </svg>
)

const TrashIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M3 6h18M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
  </svg>
)

const ExternalIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
  </svg>
)

const EditIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
  </svg>
)

const FileIcon = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/>
    <path d="M14 2v4a2 2 0 0 0 2 2h4"/>
  </svg>
)

const ClipboardIcon = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <rect width="8" height="4" x="8" y="2" rx="1" ry="1"/>
    <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>
  </svg>
)

export default function LeadCapture() {
  const [activeTab, setActiveTab] = useState('forms')
  const [forms, setForms] = useState([])
  const [quizzes, setQuizzes] = useState([])
  const [copiedId, setCopiedId] = useState(null)
  const [editingItem, setEditingItem] = useState(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = () => {
    setForms(db.getForms())
    setQuizzes(db.getQuizzes())
  }

  const handleCreateForm = () => {
    db.createForm({
      name: 'New Lead Form',
      description: 'Capture leads from your website'
    })
    loadData()
  }

  const handleCreateQuiz = () => {
    db.createQuiz({
      name: 'New Quiz',
      description: 'Assess your prospects'
    })
    loadData()
  }

  const handleDelete = (id, type) => {
    if (confirm(`Delete this ${type}?`)) {
      if (type === 'form') {
        db.deleteForm(id)
      } else {
        db.deleteQuiz(id)
      }
      loadData()
    }
  }

  const copyLink = (slug, type) => {
    const url = `${window.location.origin}/${type}/${slug}`
    navigator.clipboard.writeText(url)
    setCopiedId(slug)
    setTimeout(() => setCopiedId(null), 2000)
  }

  const items = activeTab === 'forms' ? forms : quizzes

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-charcoal">Lead Capture</h1>
          <p className="text-sm text-platinum mt-1">Create forms and quizzes to capture leads</p>
        </div>
        <button
          onClick={activeTab === 'forms' ? handleCreateForm : handleCreateQuiz}
          className="flex items-center gap-2 px-4 py-2 bg-charcoal text-white text-sm hover:bg-charcoal/90 rounded"
        >
          <PlusIcon />
          Create {activeTab === 'forms' ? 'Form' : 'Quiz'}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 border-b border-platinum">
        <button
          onClick={() => setActiveTab('forms')}
          className={cn(
            "flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 -mb-px",
            activeTab === 'forms'
              ? "border-charcoal text-charcoal"
              : "border-transparent text-platinum hover:text-charcoal"
          )}
        >
          <FileIcon />
          Forms ({forms.length})
        </button>
        <button
          onClick={() => setActiveTab('quizzes')}
          className={cn(
            "flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 -mb-px",
            activeTab === 'quizzes'
              ? "border-charcoal text-charcoal"
              : "border-transparent text-platinum hover:text-charcoal"
          )}
        >
          <ClipboardIcon />
          Quizzes ({quizzes.length})
        </button>
      </div>

      {/* Items List */}
      {items.length === 0 ? (
        <div className="bg-white border border-platinum p-12 text-center rounded">
          <div className="w-16 h-16 bg-softwhite rounded-full flex items-center justify-center mx-auto mb-4 text-platinum">
            {activeTab === 'forms' ? <FileIcon /> : <ClipboardIcon />}
          </div>
          <h3 className="text-base font-medium text-charcoal mb-2">
            No {activeTab} yet
          </h3>
          <p className="text-sm text-platinum mb-4">
            Create your first {activeTab === 'forms' ? 'form' : 'quiz'} to start capturing leads
          </p>
          <button
            onClick={activeTab === 'forms' ? handleCreateForm : handleCreateQuiz}
            className="inline-flex items-center gap-2 px-4 py-2 bg-charcoal text-white text-sm rounded"
          >
            <PlusIcon />
            Create {activeTab === 'forms' ? 'Form' : 'Quiz'}
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {items.map((item) => (
            <div key={item.id} className="bg-white border border-platinum rounded overflow-hidden">
              <div className="p-4 flex items-center justify-between">
                <div className="flex-1">
                  <h3 className="text-base font-medium text-charcoal">{item.name}</h3>
                  <p className="text-sm text-platinum mt-1">{item.description}</p>
                </div>

                <div className="flex items-center gap-2">
                  <span className={cn(
                    "text-xs px-2 py-1 rounded",
                    item.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
                  )}>
                    {item.status}
                  </span>

                  <button
                    onClick={() => copyLink(item.slug, activeTab === 'forms' ? 'form' : 'quiz')}
                    className="p-2 text-platinum hover:text-charcoal hover:bg-softwhite rounded"
                    title="Copy link"
                  >
                    {copiedId === item.slug ? <CheckIcon /> : <CopyIcon />}
                  </button>

                  <a
                    href={`/${activeTab === 'forms' ? 'form' : 'quiz'}/${item.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-platinum hover:text-charcoal hover:bg-softwhite rounded"
                    title="Preview"
                  >
                    <ExternalIcon />
                  </a>

                  <button
                    onClick={() => setEditingItem(item)}
                    className="p-2 text-platinum hover:text-charcoal hover:bg-softwhite rounded"
                    title="Edit"
                  >
                    <EditIcon />
                  </button>

                  <button
                    onClick={() => handleDelete(item.id, activeTab === 'forms' ? 'form' : 'quiz')}
                    className="p-2 text-platinum hover:text-red-500 hover:bg-red-50 rounded"
                    title="Delete"
                  >
                    <TrashIcon />
                  </button>
                </div>
              </div>

              <div className="px-4 py-3 bg-softwhite border-t border-platinum">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-platinum">Link:</span>
                  <code className="text-xs text-charcoal bg-white px-2 py-1 border border-platinum rounded flex-1 truncate">
                    {window.location.origin}/{activeTab === 'forms' ? 'form' : 'quiz'}/{item.slug}
                  </code>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit Modal */}
      {editingItem && (
        <EditModal
          item={editingItem}
          type={activeTab}
          onSave={(updates) => {
            if (activeTab === 'forms') {
              db.updateForm(editingItem.id, updates)
            } else {
              db.updateQuiz(editingItem.id, updates)
            }
            loadData()
            setEditingItem(null)
          }}
          onClose={() => setEditingItem(null)}
        />
      )}
    </div>
  )
}

// Edit Modal Component
function EditModal({ item, type, onSave, onClose }) {
  const [name, setName] = useState(item.name)
  const [description, setDescription] = useState(item.description)

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white w-full max-w-md rounded-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-platinum flex items-center justify-between">
          <h2 className="text-lg font-semibold text-charcoal">
            Edit {type === 'forms' ? 'Form' : 'Quiz'}
          </h2>
          <button onClick={onClose} className="text-platinum hover:text-charcoal">
            ✕
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div>
            <label className="block text-xs text-platinum uppercase mb-1.5">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 border border-platinum rounded text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-platinum uppercase mb-1.5">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-platinum rounded text-sm resize-none"
            />
          </div>
        </div>

        <div className="px-6 py-4 border-t border-platinum flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm text-charcoal hover:bg-softwhite rounded"
          >
            Cancel
          </button>
          <button
            onClick={() => onSave({ name, description })}
            className="px-4 py-2 text-sm bg-charcoal text-white rounded hover:bg-charcoal/90"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  )
}
