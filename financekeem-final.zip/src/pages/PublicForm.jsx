import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { db } from '@/lib/db'
import { formatPhone } from '@/lib/utils'

const CheckIcon = () => (
  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
    <path d="m9 11 3 3L22 4"/>
  </svg>
)

export default function PublicForm() {
  const { slug } = useParams()
  const [form, setForm] = useState(null)
  const [loading, setLoading] = useState(true)
  const [formData, setFormData] = useState({})
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const formData = db.getFormBySlug(slug)
    if (formData) {
      setForm(formData)
      // Initialize empty form data
      const initial = {}
      formData.fields?.forEach(f => { initial[f.id] = '' })
      setFormData(initial)
    }
    setLoading(false)
  }, [slug])

  const handleChange = (fieldId, value, type) => {
    let processedValue = value
    if (type === 'tel') {
      processedValue = formatPhone(value)
    }
    setFormData(prev => ({ ...prev, [fieldId]: processedValue }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setSubmitting(true)
    
    // Submit form (creates/updates lead)
    db.submitForm(form.id, formData)
    
    setTimeout(() => {
      setSubmitted(true)
      setSubmitting(false)
    }, 500)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-softwhite flex items-center justify-center">
        <div className="text-charcoal">Loading...</div>
      </div>
    )
  }

  if (!form) {
    return (
      <div className="min-h-screen bg-softwhite flex items-center justify-center p-6">
        <div className="text-center">
          <h1 className="text-xl font-semibold text-charcoal mb-2">Form Not Found</h1>
          <p className="text-sm text-platinum">This form does not exist or has been removed.</p>
        </div>
      </div>
    )
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-softwhite flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white border border-platinum rounded-lg p-8 text-center">
          <div className="text-sage mb-4 flex justify-center">
            <CheckIcon />
          </div>
          <h2 className="text-xl font-semibold text-charcoal mb-2">Thank You!</h2>
          <p className="text-sm text-platinum">Your submission has been received.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-softwhite py-12 px-6">
      <div className="max-w-lg mx-auto">
        <div className="bg-white border border-platinum rounded-lg overflow-hidden">
          {/* Header */}
          <div className="p-6 border-b border-platinum">
            <h1 className="text-xl font-semibold text-charcoal">{form.name}</h1>
            {form.description && (
              <p className="text-sm text-platinum mt-2">{form.description}</p>
            )}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {form.fields?.map((field) => (
              <div key={field.id}>
                <label className="block text-xs text-platinum uppercase mb-1.5">
                  {field.label}
                  {field.required && <span className="text-red-500 ml-1">*</span>}
                </label>
                {field.type === 'textarea' ? (
                  <textarea
                    value={formData[field.id] || ''}
                    onChange={(e) => handleChange(field.id, e.target.value, field.type)}
                    required={field.required}
                    rows={4}
                    className="w-full px-4 py-2.5 border border-platinum rounded text-sm resize-none"
                  />
                ) : (
                  <input
                    type={field.type || 'text'}
                    value={formData[field.id] || ''}
                    onChange={(e) => handleChange(field.id, e.target.value, field.type)}
                    required={field.required}
                    className="w-full px-4 py-2.5 border border-platinum rounded text-sm"
                  />
                )}
              </div>
            ))}

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 bg-charcoal text-white text-sm font-medium rounded hover:bg-charcoal/90 disabled:opacity-50 mt-6"
            >
              {submitting ? 'Submitting...' : 'Submit'}
            </button>
          </form>
        </div>

        <p className="text-xs text-platinum text-center mt-4">
          Powered by FinanceKeem
        </p>
      </div>
    </div>
  )
}
