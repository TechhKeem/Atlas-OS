import { useState } from 'react'

const CopyIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/>
    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
  </svg>
)

const CheckIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M20 6 9 17l-5-5"/>
  </svg>
)

export default function Settings() {
  const [copiedField, setCopiedField] = useState(null)

  const copyToClipboard = (text, field) => {
    navigator.clipboard.writeText(text)
    setCopiedField(field)
    setTimeout(() => setCopiedField(null), 2000)
  }

  const baseUrl = window.location.origin

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-charcoal">Settings</h1>
        <p className="text-sm text-platinum mt-1">Configure your FinanceKeem application</p>
      </div>

      <div className="space-y-6 max-w-2xl">
        {/* Public Links */}
        <div className="bg-white border border-platinum rounded-lg">
          <div className="px-6 py-4 border-b border-platinum">
            <h2 className="text-base font-semibold text-charcoal">Public Links</h2>
            <p className="text-sm text-platinum mt-1">Share these links with your prospects</p>
          </div>
          <div className="p-6 space-y-4">
            <div>
              <label className="block text-xs text-platinum uppercase mb-2">
                Protection Assessment Quiz
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={`${baseUrl}/quiz/protection-assessment`}
                  readOnly
                  className="flex-1 px-3 py-2 border border-platinum rounded text-sm bg-softwhite"
                />
                <button
                  onClick={() => copyToClipboard(`${baseUrl}/quiz/protection-assessment`, 'quiz')}
                  className="px-4 py-2 bg-charcoal text-white text-sm rounded hover:bg-charcoal/90 flex items-center gap-2"
                >
                  {copiedField === 'quiz' ? <CheckIcon /> : <CopyIcon />}
                  {copiedField === 'quiz' ? 'Copied!' : 'Copy'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Account Info */}
        <div className="bg-white border border-platinum rounded-lg">
          <div className="px-6 py-4 border-b border-platinum">
            <h2 className="text-base font-semibold text-charcoal">Account</h2>
          </div>
          <div className="p-6 space-y-4">
            <div>
              <label className="block text-xs text-platinum uppercase mb-2">Business Name</label>
              <input
                type="text"
                defaultValue="FinanceKeem"
                className="w-full px-3 py-2 border border-platinum rounded text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-platinum uppercase mb-2">Email</label>
              <input
                type="email"
                defaultValue="contact@financekeem.com"
                className="w-full px-3 py-2 border border-platinum rounded text-sm"
              />
            </div>
          </div>
        </div>

        {/* Data Management */}
        <div className="bg-white border border-platinum rounded-lg">
          <div className="px-6 py-4 border-b border-platinum">
            <h2 className="text-base font-semibold text-charcoal">Data Management</h2>
            <p className="text-sm text-platinum mt-1">Manage your stored data</p>
          </div>
          <div className="p-6">
            <p className="text-sm text-platinum mb-4">
              Your data is stored locally in your browser. Clearing browser data will remove all leads, forms, and bookings.
            </p>
            <button
              onClick={() => {
                if (confirm('This will delete ALL your data. Are you sure?')) {
                  localStorage.removeItem('financekeem_data')
                  window.location.reload()
                }
              }}
              className="px-4 py-2 text-sm text-red-600 border border-red-200 rounded hover:bg-red-50"
            >
              Clear All Data
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
