import { useState, useEffect } from 'react'
import { db } from '@/lib/db'
import { cn } from '@/lib/utils'

// Icons
const PlusIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12 5v14M5 12h14"/>
  </svg>
)

const CopyIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/>
    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
  </svg>
)

const CheckIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M20 6 9 17l-5-5"/>
  </svg>
)

const TrashIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M3 6h18M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
  </svg>
)

const ExternalIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
  </svg>
)

const EditIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
  </svg>
)

const ClockIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/>
  </svg>
)

const CalendarIcon = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <rect width="18" height="18" x="3" y="4" rx="2" ry="2"/>
    <line x1="16" x2="16" y1="2" y2="6"/>
    <line x1="8" x2="8" y1="2" y2="6"/>
    <line x1="3" x2="21" y1="10" y2="10"/>
  </svg>
)

const DAYS = [
  { value: 'monday', label: 'Mon' },
  { value: 'tuesday', label: 'Tue' },
  { value: 'wednesday', label: 'Wed' },
  { value: 'thursday', label: 'Thu' },
  { value: 'friday', label: 'Fri' },
  { value: 'saturday', label: 'Sat' },
  { value: 'sunday', label: 'Sun' },
]

export default function BookingPages() {
  const [pages, setPages] = useState([])
  const [copiedId, setCopiedId] = useState(null)
  const [editingItem, setEditingItem] = useState(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = () => {
    setPages(db.getBookingPages())
  }

  const handleCreate = () => {
    db.createBookingPage({
      name: 'Protection Clarity Conversation',
      description: '30-minute call to review your assessment and discuss next steps',
      duration: 30
    })
    loadData()
  }

  const handleDelete = (id) => {
    if (confirm('Delete this booking page?')) {
      db.deleteBookingPage(id)
      loadData()
    }
  }

  const copyLink = (slug) => {
    const url = `${window.location.origin}/book/${slug}`
    navigator.clipboard.writeText(url)
    setCopiedId(slug)
    setTimeout(() => setCopiedId(null), 2000)
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-charcoal">Booking Pages</h1>
          <p className="text-sm text-platinum mt-1">Create booking pages for client scheduling</p>
        </div>
        <button
          onClick={handleCreate}
          className="flex items-center gap-2 px-4 py-2 bg-charcoal text-white text-sm hover:bg-charcoal/90 rounded"
        >
          <PlusIcon />
          Create Booking Page
        </button>
      </div>

      {/* Pages List */}
      {pages.length === 0 ? (
        <div className="bg-white border border-platinum p-12 text-center rounded">
          <div className="w-16 h-16 bg-softwhite rounded-full flex items-center justify-center mx-auto mb-4 text-platinum">
            <CalendarIcon />
          </div>
          <h3 className="text-base font-medium text-charcoal mb-2">
            No booking pages yet
          </h3>
          <p className="text-sm text-platinum mb-4">
            Create your first booking page to let clients schedule calls with you
          </p>
          <button
            onClick={handleCreate}
            className="inline-flex items-center gap-2 px-4 py-2 bg-charcoal text-white text-sm rounded"
          >
            <PlusIcon />
            Create Booking Page
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {pages.map((page) => (
            <div key={page.id} className="bg-white border border-platinum rounded overflow-hidden">
              <div className="p-4 flex items-center justify-between">
                <div className="flex-1">
                  <h3 className="text-base font-medium text-charcoal">{page.name}</h3>
                  <p className="text-sm text-platinum mt-1">{page.description}</p>
                  <div className="flex items-center gap-4 mt-2">
                    <span className="flex items-center gap-1 text-xs text-platinum">
                      <ClockIcon /> {page.duration} minutes
                    </span>
                    <span className="text-xs text-platinum">
                      {page.availability?.days?.length || 0} days/week
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={cn(
                    "text-xs px-2 py-1 rounded",
                    page.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
                  )}>
                    {page.status}
                  </span>

                  <button
                    onClick={() => copyLink(page.slug)}
                    className="p-2 text-platinum hover:text-charcoal hover:bg-softwhite rounded"
                    title="Copy link"
                  >
                    {copiedId === page.slug ? <CheckIcon /> : <CopyIcon />}
                  </button>

                  <a
                    href={`/book/${page.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-platinum hover:text-charcoal hover:bg-softwhite rounded"
                    title="Preview"
                  >
                    <ExternalIcon />
                  </a>

                  <button
                    onClick={() => setEditingItem(page)}
                    className="p-2 text-platinum hover:text-charcoal hover:bg-softwhite rounded"
                    title="Edit"
                  >
                    <EditIcon />
                  </button>

                  <button
                    onClick={() => handleDelete(page.id)}
                    className="p-2 text-platinum hover:text-red-500 hover:bg-red-50 rounded"
                    title="Delete"
                  >
                    <TrashIcon />
                  </button>
                </div>
              </div>

              <div className="px-4 py-3 bg-softwhite border-t border-platinum">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-platinum">Link:</span>
                  <code className="text-xs text-charcoal bg-white px-2 py-1 border border-platinum rounded flex-1 truncate">
                    {window.location.origin}/book/{page.slug}
                  </code>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit Modal */}
      {editingItem && (
        <EditBookingModal
          item={editingItem}
          onSave={(updates) => {
            db.updateBookingPage(editingItem.id, updates)
            loadData()
            setEditingItem(null)
          }}
          onClose={() => setEditingItem(null)}
        />
      )}
    </div>
  )
}

// Edit Booking Modal
function EditBookingModal({ item, onSave, onClose }) {
  const [name, setName] = useState(item.name)
  const [description, setDescription] = useState(item.description)
  const [duration, setDuration] = useState(item.duration)
  const [availability, setAvailability] = useState(item.availability || {
    days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
    startTime: '09:00',
    endTime: '17:00'
  })

  const toggleDay = (day) => {
    const days = availability.days || []
    if (days.includes(day)) {
      setAvailability({ ...availability, days: days.filter(d => d !== day) })
    } else {
      setAvailability({ ...availability, days: [...days, day] })
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white w-full max-w-md rounded-lg overflow-hidden max-h-[90vh] overflow-y-auto">
        <div className="px-6 py-4 border-b border-platinum flex items-center justify-between">
          <h2 className="text-lg font-semibold text-charcoal">Edit Booking Page</h2>
          <button onClick={onClose} className="text-platinum hover:text-charcoal">✕</button>
        </div>

        <div className="p-6 space-y-4">
          <div>
            <label className="block text-xs text-platinum uppercase mb-1.5">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 border border-platinum rounded text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-platinum uppercase mb-1.5">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              className="w-full px-3 py-2 border border-platinum rounded text-sm resize-none"
            />
          </div>
          <div>
            <label className="block text-xs text-platinum uppercase mb-1.5">Duration</label>
            <select
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="w-full px-3 py-2 border border-platinum rounded text-sm"
            >
              <option value={15}>15 minutes</option>
              <option value={30}>30 minutes</option>
              <option value={45}>45 minutes</option>
              <option value={60}>60 minutes</option>
            </select>
          </div>
          <div>
            <label className="block text-xs text-platinum uppercase mb-2">Available Days</label>
            <div className="flex flex-wrap gap-2">
              {DAYS.map(day => (
                <button
                  key={day.value}
                  type="button"
                  onClick={() => toggleDay(day.value)}
                  className={cn(
                    "px-3 py-1.5 text-xs border rounded transition-colors",
                    availability.days?.includes(day.value)
                      ? "bg-charcoal text-white border-charcoal"
                      : "bg-white text-charcoal border-platinum hover:border-charcoal"
                  )}
                >
                  {day.label}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-platinum uppercase mb-1.5">Start Time</label>
              <input
                type="time"
                value={availability.startTime}
                onChange={(e) => setAvailability({ ...availability, startTime: e.target.value })}
                className="w-full px-3 py-2 border border-platinum rounded text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-platinum uppercase mb-1.5">End Time</label>
              <input
                type="time"
                value={availability.endTime}
                onChange={(e) => setAvailability({ ...availability, endTime: e.target.value })}
                className="w-full px-3 py-2 border border-platinum rounded text-sm"
              />
            </div>
          </div>
        </div>

        <div className="px-6 py-4 border-t border-platinum flex justify-end gap-3">
          <button onClick={onClose} className="px-4 py-2 text-sm text-charcoal hover:bg-softwhite rounded">
            Cancel
          </button>
          <button
            onClick={() => onSave({ name, description, duration, availability })}
            className="px-4 py-2 text-sm bg-charcoal text-white rounded hover:bg-charcoal/90"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  )
}
