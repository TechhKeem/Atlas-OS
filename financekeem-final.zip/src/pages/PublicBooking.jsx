import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { db } from '@/lib/db'
import { cn, formatPhone } from '@/lib/utils'
import { format, addDays, startOfWeek, isSameDay } from 'date-fns'

// Icons
const ChevronLeftIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="m15 18-6-6 6-6"/>
  </svg>
)

const ChevronRightIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="m9 18 6-6-6-6"/>
  </svg>
)

const ClockIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/>
  </svg>
)

const CheckCircleIcon = () => (
  <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
    <path d="m9 11 3 3L22 4"/>
  </svg>
)

// Generate time slots
function generateTimeSlots(startTime, endTime, duration) {
  const slots = []
  const [startHour, startMin] = startTime.split(':').map(Number)
  const [endHour, endMin] = endTime.split(':').map(Number)
  
  let currentHour = startHour
  let currentMin = startMin

  while (currentHour < endHour || (currentHour === endHour && currentMin < endMin)) {
    const timeStr = `${currentHour.toString().padStart(2, '0')}:${currentMin.toString().padStart(2, '0')}`
    const hour12 = currentHour > 12 ? currentHour - 12 : currentHour === 0 ? 12 : currentHour
    const ampm = currentHour >= 12 ? 'PM' : 'AM'
    slots.push({
      value: timeStr,
      label: `${hour12}:${currentMin.toString().padStart(2, '0')} ${ampm}`
    })

    currentMin += duration
    if (currentMin >= 60) {
      currentHour += Math.floor(currentMin / 60)
      currentMin = currentMin % 60
    }
  }

  return slots
}

export default function PublicBooking() {
  const { slug } = useParams()
  const [bookingPage, setBookingPage] = useState(null)
  const [loading, setLoading] = useState(true)
  const [step, setStep] = useState(1) // 1 = date/time, 2 = contact, 3 = confirmation
  const [selectedDate, setSelectedDate] = useState(null)
  const [selectedTime, setSelectedTime] = useState(null)
  const [weekStart, setWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 0 }))
  const [contactInfo, setContactInfo] = useState({ name: '', email: '', phone: '' })
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    // Try to get booking page by slug, or use default
    let page = db.getBookingPageBySlug(slug)
    if (!page) {
      // Create a default booking page for demo
      page = {
        id: 'default',
        name: 'Protection Clarity Conversation',
        description: '30-minute call to review your assessment and discuss next steps for protection planning.',
        duration: 30,
        availability: {
          days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
          startTime: '09:00',
          endTime: '17:00'
        }
      }
    }
    setBookingPage(page)
    setLoading(false)
  }, [slug])

  const handleContactChange = (field, value) => {
    let processedValue = value
    if (field === 'phone') {
      processedValue = formatPhone(value)
    }
    setContactInfo(prev => ({ ...prev, [field]: processedValue }))
  }

  const handleSubmit = () => {
    setSubmitting(true)

    // Create booking
    db.createBooking({
      bookingPageId: bookingPage.id,
      name: contactInfo.name,
      email: contactInfo.email,
      phone: contactInfo.phone,
      date: format(selectedDate, 'yyyy-MM-dd'),
      time: selectedTime,
      duration: bookingPage.duration
    })

    setTimeout(() => {
      setSubmitting(false)
      setStep(3)
    }, 500)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-softwhite flex items-center justify-center">
        <div className="text-charcoal">Loading...</div>
      </div>
    )
  }

  // Confirmation Screen
  if (step === 3) {
    return (
      <div className="min-h-screen bg-softwhite flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white border border-platinum rounded-lg p-8 text-center">
          <div className="text-sage mb-4 flex justify-center">
            <CheckCircleIcon />
          </div>
          <h2 className="text-xl font-semibold text-charcoal mb-2">Booking Confirmed!</h2>
          <p className="text-sm text-platinum mb-6">
            Thank you, {contactInfo.name}! Your appointment has been scheduled.
          </p>
          <div className="bg-softwhite border border-platinum rounded p-4 text-left mb-6">
            <p className="text-sm font-medium text-charcoal">{bookingPage.name}</p>
            <p className="text-sm text-platinum mt-2">
              {format(selectedDate, 'EEEE, MMMM d, yyyy')}
            </p>
            <p className="text-sm text-platinum">
              {generateTimeSlots(bookingPage.availability.startTime, bookingPage.availability.endTime, bookingPage.duration)
                .find(s => s.value === selectedTime)?.label} ({bookingPage.duration} min)
            </p>
          </div>
          <p className="text-xs text-platinum">A confirmation email has been sent to {contactInfo.email}</p>
        </div>
      </div>
    )
  }

  // Generate week days
  const weekDays = []
  for (let i = 0; i < 7; i++) {
    weekDays.push(addDays(weekStart, i))
  }

  const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
  const availableDays = bookingPage.availability?.days || []
  const timeSlots = generateTimeSlots(
    bookingPage.availability?.startTime || '09:00',
    bookingPage.availability?.endTime || '17:00',
    bookingPage.duration || 30
  )

  const isDateAvailable = (date) => {
    const dayName = dayNames[date.getDay()]
    return availableDays.includes(dayName) && date >= new Date().setHours(0, 0, 0, 0)
  }

  // Contact Info Screen
  if (step === 2) {
    return (
      <div className="min-h-screen bg-softwhite py-12 px-6">
        <div className="max-w-md mx-auto">
          <div className="bg-white border border-platinum rounded-lg overflow-hidden">
            <div className="p-6 border-b border-platinum">
              <h1 className="text-lg font-semibold text-charcoal">{bookingPage.name}</h1>
              <div className="flex items-center gap-4 mt-2 text-sm text-platinum">
                <span className="flex items-center gap-1">
                  <ClockIcon /> {bookingPage.duration} min
                </span>
              </div>
            </div>

            <div className="p-6">
              <div className="bg-softwhite border border-platinum rounded p-3 mb-6">
                <p className="text-sm font-medium text-charcoal">
                  {format(selectedDate, 'EEEE, MMMM d, yyyy')}
                </p>
                <p className="text-sm text-platinum">
                  {timeSlots.find(s => s.value === selectedTime)?.label}
                </p>
              </div>

              <h2 className="text-base font-semibold text-charcoal mb-4">Enter Your Details</h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-platinum uppercase mb-1.5">Name *</label>
                  <input
                    type="text"
                    value={contactInfo.name}
                    onChange={(e) => handleContactChange('name', e.target.value)}
                    className="w-full px-4 py-3 border border-platinum rounded text-sm"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-xs text-platinum uppercase mb-1.5">Email *</label>
                  <input
                    type="email"
                    value={contactInfo.email}
                    onChange={(e) => handleContactChange('email', e.target.value)}
                    className="w-full px-4 py-3 border border-platinum rounded text-sm"
                    placeholder="you@example.com"
                  />
                </div>
                <div>
                  <label className="block text-xs text-platinum uppercase mb-1.5">Phone</label>
                  <input
                    type="tel"
                    value={contactInfo.phone}
                    onChange={(e) => handleContactChange('phone', e.target.value)}
                    className="w-full px-4 py-3 border border-platinum rounded text-sm"
                    placeholder="(555) 555-5555"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between mt-6">
                <button
                  onClick={() => setStep(1)}
                  className="flex items-center gap-2 text-platinum hover:text-charcoal"
                >
                  <ChevronLeftIcon /> Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={!contactInfo.name || !contactInfo.email || submitting}
                  className="px-6 py-3 bg-charcoal text-white font-medium rounded hover:bg-charcoal/90 disabled:opacity-50"
                >
                  {submitting ? 'Booking...' : 'Confirm Booking'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Date/Time Selection Screen
  return (
    <div className="min-h-screen bg-softwhite py-12 px-6">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white border border-platinum rounded-lg overflow-hidden">
          <div className="p-6 border-b border-platinum">
            <h1 className="text-lg font-semibold text-charcoal">{bookingPage.name}</h1>
            {bookingPage.description && (
              <p className="text-sm text-platinum mt-2">{bookingPage.description}</p>
            )}
            <div className="flex items-center gap-4 mt-3 text-sm text-platinum">
              <span className="flex items-center gap-1">
                <ClockIcon /> {bookingPage.duration} min
              </span>
            </div>
          </div>

          <div className="p-6">
            <h2 className="text-base font-semibold text-charcoal mb-4">Select a Date & Time</h2>

            {/* Week Navigation */}
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={() => setWeekStart(addDays(weekStart, -7))}
                className="p-2 hover:bg-softwhite rounded"
              >
                <ChevronLeftIcon />
              </button>
              <span className="text-sm font-medium text-charcoal">
                {format(weekStart, 'MMMM yyyy')}
              </span>
              <button
                onClick={() => setWeekStart(addDays(weekStart, 7))}
                className="p-2 hover:bg-softwhite rounded"
              >
                <ChevronRightIcon />
              </button>
            </div>

            {/* Week Days */}
            <div className="grid grid-cols-7 gap-2 mb-6">
              {weekDays.map((day) => {
                const available = isDateAvailable(day)
                const selected = selectedDate && isSameDay(day, selectedDate)
                return (
                  <button
                    key={day.toISOString()}
                    onClick={() => available && setSelectedDate(day)}
                    disabled={!available}
                    className={cn(
                      "py-3 rounded text-center transition-colors",
                      available ? "hover:bg-softwhite cursor-pointer" : "opacity-40 cursor-not-allowed",
                      selected ? "bg-charcoal text-white" : "bg-softwhite text-charcoal"
                    )}
                  >
                    <div className="text-xs uppercase">{format(day, 'EEE')}</div>
                    <div className="text-lg font-medium">{format(day, 'd')}</div>
                  </button>
                )
              })}
            </div>

            {/* Time Slots */}
            {selectedDate && (
              <div>
                <h3 className="text-sm font-medium text-charcoal mb-3">
                  Available times for {format(selectedDate, 'EEEE, MMMM d')}
                </h3>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {timeSlots.map((slot) => (
                    <button
                      key={slot.value}
                      onClick={() => setSelectedTime(slot.value)}
                      className={cn(
                        "py-2 px-3 border rounded text-sm transition-colors",
                        selectedTime === slot.value
                          ? "border-charcoal bg-charcoal text-white"
                          : "border-platinum hover:border-charcoal"
                      )}
                    >
                      {slot.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Continue Button */}
            {selectedDate && selectedTime && (
              <div className="mt-6 flex justify-end">
                <button
                  onClick={() => setStep(2)}
                  className="px-6 py-3 bg-charcoal text-white font-medium rounded hover:bg-charcoal/90 flex items-center gap-2"
                >
                  Continue <ChevronRightIcon />
                </button>
              </div>
            )}
          </div>
        </div>

        <p className="text-xs text-platinum text-center mt-4">
          Powered by FinanceKeem
        </p>
      </div>
    </div>
  )
}
