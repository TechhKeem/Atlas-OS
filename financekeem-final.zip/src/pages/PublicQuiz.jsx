import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { db } from '@/lib/db'
import { cn, formatPhone } from '@/lib/utils'

// Protection Assessment Questions
const QUIZ_QUESTIONS = [
  // PROTECTION (4 questions)
  {
    id: 'p1', pillar: 'protection',
    question: 'Which best describes your current life insurance coverage?',
    options: [
      { value: 'a', label: 'I have coverage intentionally designed around my responsibilities', score: 3 },
      { value: 'b', label: 'I have coverage, but it was set up a while ago or based on a rough estimate', score: 2 },
      { value: 'c', label: 'I have some coverage through work or older policies', score: 1 },
      { value: 'd', label: "I don't currently have life insurance", score: 0 },
    ]
  },
  {
    id: 'p2', pillar: 'protection',
    question: 'If something happened to you, how confident are you that your coverage would support your dependents long-term?',
    options: [
      { value: 'a', label: 'Very confident — it was sized with dependents and obligations in mind', score: 3 },
      { value: 'b', label: "Somewhat confident, but I haven't revisited it recently", score: 2 },
      { value: 'c', label: "Not very confident — I'm not sure how it was calculated", score: 1 },
      { value: 'd', label: "I'm unsure or it wouldn't be sufficient", score: 0 },
    ]
  },
  {
    id: 'p3', pillar: 'protection',
    question: 'Which best reflects how your responsibilities were considered when coverage was set up?',
    options: [
      { value: 'a', label: 'Dependents, housing, and major obligations were clearly accounted for', score: 3 },
      { value: 'b', label: 'Some responsibilities were considered, but not all', score: 2 },
      { value: 'c', label: 'Coverage was chosen without fully mapping responsibilities', score: 1 },
      { value: 'd', label: 'Responsibilities were not factored in', score: 0 },
    ]
  },
  {
    id: 'p4', pillar: 'protection',
    question: 'How intentional are your beneficiary designations on life insurance and key accounts?',
    options: [
      { value: 'a', label: 'Fully intentional and recently reviewed', score: 3 },
      { value: 'b', label: 'Intentional at the time, but not reviewed since', score: 2 },
      { value: 'c', label: "Set up, but I'm unsure if they still reflect my wishes", score: 1 },
      { value: 'd', label: "I'm not sure who is listed", score: 0 },
    ]
  },
  // ALIGNMENT (4 questions)
  {
    id: 'a1', pillar: 'alignment',
    question: 'Which best describes your estate planning documents?',
    options: [
      { value: 'a', label: 'I have completed documents that reflect my current situation', score: 3 },
      { value: 'b', label: 'I have documents, but they may be outdated', score: 2 },
      { value: 'c', label: "I started the process but didn't complete it", score: 1 },
      { value: 'd', label: "I don't have estate planning documents", score: 0 },
    ]
  },
  {
    id: 'a2', pillar: 'alignment',
    question: 'If decisions had to be made on your behalf, how clear is it who would make them?',
    options: [
      { value: 'a', label: 'Very clear — roles are defined and documented', score: 3 },
      { value: 'b', label: 'Somewhat clear, but not fully documented', score: 2 },
      { value: 'c', label: 'Informally discussed, but not documented', score: 1 },
      { value: 'd', label: 'Not clear', score: 0 },
    ]
  },
  {
    id: 'a3', pillar: 'alignment',
    question: 'If you have dependents, how confident are you that guardianship and control decisions reflect your intent?',
    options: [
      { value: 'a', label: 'Very confident — decisions are documented', score: 3 },
      { value: 'b', label: "Somewhat confident, but haven't reviewed recently", score: 2 },
      { value: 'c', label: 'Unsure or not fully addressed', score: 1 },
      { value: 'd', label: 'Not applicable or not considered', score: 0 },
    ]
  },
  {
    id: 'a4', pillar: 'alignment',
    question: 'Are the priorities, rules and delegations consistent across all of your estate documents?',
    options: [
      { value: 'a', label: 'Fully aligned and coordinated', score: 3 },
      { value: 'b', label: 'Mostly aligned, but not reviewed as a system', score: 2 },
      { value: 'c', label: 'Likely misaligned or handled separately', score: 1 },
      { value: 'd', label: "I'm not sure", score: 0 },
    ]
  },
  // OVERSIGHT (4 questions)
  {
    id: 'o1', pillar: 'oversight',
    question: 'When was the last time your protection plan was fully reviewed?',
    options: [
      { value: 'a', label: 'Within the last year', score: 3 },
      { value: 'b', label: 'Within the last 2-3 years', score: 2 },
      { value: 'c', label: 'More than 3 years ago', score: 1 },
      { value: 'd', label: "I don't recall a full review", score: 0 },
    ]
  },
  {
    id: 'o2', pillar: 'oversight',
    question: 'Have major life changes occurred since your plan was last reviewed?',
    options: [
      { value: 'a', label: 'No, changes have been addressed', score: 3 },
      { value: 'b', label: 'Yes, but some updates are pending', score: 2 },
      { value: 'c', label: "Yes, and updates haven't been made", score: 1 },
      { value: 'd', label: "I'm not sure", score: 0 },
    ]
  },
  {
    id: 'o3', pillar: 'oversight',
    question: 'Who is responsible for making sure your plan stays current?',
    options: [
      { value: 'a', label: 'I work with someone who proactively helps manage updates', score: 3 },
      { value: 'b', label: 'I try to stay on top of it myself', score: 2 },
      { value: 'c', label: 'I update things only when something major happens', score: 1 },
      { value: 'd', label: 'No one is clearly responsible', score: 0 },
    ]
  },
  {
    id: 'o4', pillar: 'oversight',
    question: 'Which best describes how your plan is maintained over time?',
    options: [
      { value: 'a', label: 'There is a regular review process', score: 3 },
      { value: 'b', label: 'Reviews happen occasionally', score: 2 },
      { value: 'c', label: 'Reviews are reactive or crisis-driven', score: 1 },
      { value: 'd', label: 'There is no review process', score: 0 },
    ]
  },
]

// Calculate protection state from answers
function calculateResult(answers) {
  const pillarScores = { protection: 0, alignment: 0, oversight: 0 }
  const pillarMax = { protection: 12, alignment: 12, oversight: 12 }

  QUIZ_QUESTIONS.forEach(q => {
    const answer = answers[q.id]
    if (answer) {
      const option = q.options.find(o => o.value === answer)
      if (option) {
        pillarScores[q.pillar] += option.score
      }
    }
  })

  // Convert to strength levels
  const getStrength = (score, max) => {
    const pct = score / max
    if (pct >= 0.75) return 'strong'
    if (pct >= 0.5) return 'moderate'
    return 'weak'
  }

  const strengths = {
    protection: getStrength(pillarScores.protection, pillarMax.protection),
    alignment: getStrength(pillarScores.alignment, pillarMax.alignment),
    oversight: getStrength(pillarScores.oversight, pillarMax.oversight),
  }

  // Determine state
  const weakCount = Object.values(strengths).filter(s => s === 'weak').length

  if (strengths.protection === 'strong' && strengths.alignment === 'strong' && strengths.oversight !== 'weak') {
    return { state: 'Well Aligned', strengths, scores: pillarScores }
  }
  if (strengths.protection === 'moderate' && strengths.alignment === 'moderate') {
    return { state: 'In Place, Needs Review', strengths, scores: pillarScores }
  }
  if (weakCount === 1) {
    return { state: 'Partially Built', strengths, scores: pillarScores }
  }
  return { state: 'Not Yet Protected', strengths, scores: pillarScores }
}

// Icons
const ChevronLeftIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="m15 18-6-6 6-6"/>
  </svg>
)

const ChevronRightIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="m9 18 6-6-6-6"/>
  </svg>
)

const CheckCircleIcon = () => (
  <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
    <path d="m9 11 3 3L22 4"/>
  </svg>
)

export default function PublicQuiz() {
  const { slug } = useParams()
  const [currentStep, setCurrentStep] = useState(0) // 0 = intro, 1-12 = questions, 13 = contact, 14 = result
  const [answers, setAnswers] = useState({})
  const [contactInfo, setContactInfo] = useState({ name: '', email: '', phone: '' })
  const [result, setResult] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  const totalQuestions = QUIZ_QUESTIONS.length
  const isIntro = currentStep === 0
  const isContact = currentStep === totalQuestions + 1
  const isResult = currentStep === totalQuestions + 2
  const currentQuestion = !isIntro && !isContact && !isResult ? QUIZ_QUESTIONS[currentStep - 1] : null

  const handleAnswer = (value) => {
    setAnswers(prev => ({ ...prev, [currentQuestion.id]: value }))
  }

  const handleNext = () => {
    if (currentStep <= totalQuestions) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleContactChange = (field, value) => {
    let processedValue = value
    if (field === 'phone') {
      processedValue = formatPhone(value)
    }
    setContactInfo(prev => ({ ...prev, [field]: processedValue }))
  }

  const handleSubmit = () => {
    setSubmitting(true)
    const calcResult = calculateResult(answers)
    setResult(calcResult)

    // Save to database
    db.submitQuiz('protection-assessment', {
      name: contactInfo.name,
      email: contactInfo.email,
      phone: contactInfo.phone,
      answers,
      result: calcResult.state
    })

    setTimeout(() => {
      setSubmitting(false)
      setCurrentStep(totalQuestions + 2)
    }, 500)
  }

  const canProceed = currentQuestion ? answers[currentQuestion.id] : true
  const progress = Math.min((currentStep / (totalQuestions + 1)) * 100, 100)

  // Intro Screen
  if (isIntro) {
    return (
      <div className="min-h-screen bg-softwhite flex items-center justify-center p-6">
        <div className="max-w-xl w-full bg-white border border-platinum rounded-lg overflow-hidden">
          <div className="p-8 text-center">
            <h1 className="text-2xl font-semibold text-charcoal mb-4">
              Protection & Alignment Assessment
            </h1>
            <p className="text-platinum mb-6">
              This 12-question assessment will help you understand whether your financial protection 
              is coordinated and being maintained, or if there are gaps that need attention.
            </p>
            <p className="text-sm text-platinum mb-8">
              Takes about 3-5 minutes to complete.
            </p>
            <button
              onClick={handleNext}
              className="px-8 py-3 bg-charcoal text-white font-medium rounded hover:bg-charcoal/90"
            >
              Start Assessment
            </button>
          </div>
          <div className="px-8 py-4 bg-softwhite border-t border-platinum text-center">
            <p className="text-xs text-platinum">Powered by FinanceKeem</p>
          </div>
        </div>
      </div>
    )
  }

  // Result Screen
  if (isResult && result) {
    const stateColors = {
      'Well Aligned': 'bg-green-100 text-green-800 border-green-200',
      'In Place, Needs Review': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'Partially Built': 'bg-orange-100 text-orange-800 border-orange-200',
      'Not Yet Protected': 'bg-red-100 text-red-800 border-red-200',
    }

    const stateDescriptions = {
      'Well Aligned': 'Your protection system is mostly coordinated. Continue with regular oversight to maintain alignment as life changes.',
      'In Place, Needs Review': 'You have protection in place, but there are alignment and responsibility gaps that should be addressed.',
      'Partially Built': 'Core pieces exist, but your system is fragmented or outdated. A coordinated review would help.',
      'Not Yet Protected': 'There are significant gaps in your protection structure. Consider scheduling a clarity conversation to understand your options.',
    }

    return (
      <div className="min-h-screen bg-softwhite py-12 px-6">
        <div className="max-w-xl mx-auto">
          <div className="bg-white border border-platinum rounded-lg overflow-hidden">
            <div className="p-8 text-center">
              <div className="text-sage mb-4 flex justify-center">
                <CheckCircleIcon />
              </div>
              <h2 className="text-xl font-semibold text-charcoal mb-2">Assessment Complete</h2>
              <p className="text-sm text-platinum mb-6">Thank you, {contactInfo.name}!</p>

              <div className={cn("inline-block px-6 py-3 rounded-lg border mb-6", stateColors[result.state])}>
                <p className="text-lg font-semibold">{result.state}</p>
              </div>

              <p className="text-platinum mb-8">{stateDescriptions[result.state]}</p>

              {/* Pillar Breakdown */}
              <div className="text-left space-y-4 mb-8">
                <h3 className="text-sm font-semibold text-charcoal uppercase">Your Pillars</h3>
                {['protection', 'alignment', 'oversight'].map(pillar => {
                  const strength = result.strengths[pillar]
                  const strengthColors = {
                    strong: 'bg-green-500',
                    moderate: 'bg-yellow-500',
                    weak: 'bg-red-500'
                  }
                  return (
                    <div key={pillar} className="flex items-center justify-between">
                      <span className="text-sm text-charcoal capitalize">{pillar}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-platinum/30 rounded-full overflow-hidden">
                          <div 
                            className={cn("h-full rounded-full", strengthColors[strength])}
                            style={{ width: strength === 'strong' ? '100%' : strength === 'moderate' ? '66%' : '33%' }}
                          />
                        </div>
                        <span className="text-xs text-platinum capitalize w-16">{strength}</span>
                      </div>
                    </div>
                  )
                })}
              </div>

              <div className="border-t border-platinum pt-6">
                <p className="text-sm text-platinum mb-4">
                  The next step is understanding what should be reviewed, aligned, or put in place.
                </p>
                <a
                  href="/book/clarity-call"
                  className="inline-block px-6 py-3 bg-sage text-white font-medium rounded hover:bg-sage/90"
                >
                  Schedule a Protection Clarity Conversation
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Contact Info Screen
  if (isContact) {
    return (
      <div className="min-h-screen bg-softwhite py-12 px-6">
        <div className="max-w-xl mx-auto">
          <div className="bg-white border border-platinum rounded-lg overflow-hidden">
            {/* Progress */}
            <div className="h-1 bg-platinum/30">
              <div className="h-full bg-sage transition-all" style={{ width: '100%' }} />
            </div>

            <div className="p-8">
              <h2 className="text-xl font-semibold text-charcoal mb-2">Almost Done!</h2>
              <p className="text-platinum mb-6">Enter your information to see your results.</p>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-platinum uppercase mb-1.5">Full Name *</label>
                  <input
                    type="text"
                    value={contactInfo.name}
                    onChange={(e) => handleContactChange('name', e.target.value)}
                    className="w-full px-4 py-3 border border-platinum rounded text-sm"
                    placeholder="Your name"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs text-platinum uppercase mb-1.5">Email *</label>
                  <input
                    type="email"
                    value={contactInfo.email}
                    onChange={(e) => handleContactChange('email', e.target.value)}
                    className="w-full px-4 py-3 border border-platinum rounded text-sm"
                    placeholder="you@example.com"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs text-platinum uppercase mb-1.5">Phone</label>
                  <input
                    type="tel"
                    value={contactInfo.phone}
                    onChange={(e) => handleContactChange('phone', e.target.value)}
                    className="w-full px-4 py-3 border border-platinum rounded text-sm"
                    placeholder="(555) 555-5555"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between mt-8">
                <button
                  onClick={handleBack}
                  className="flex items-center gap-2 text-platinum hover:text-charcoal"
                >
                  <ChevronLeftIcon /> Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={!contactInfo.name || !contactInfo.email || submitting}
                  className="px-6 py-3 bg-charcoal text-white font-medium rounded hover:bg-charcoal/90 disabled:opacity-50"
                >
                  {submitting ? 'Processing...' : 'See My Results'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Question Screen
  return (
    <div className="min-h-screen bg-softwhite py-12 px-6">
      <div className="max-w-xl mx-auto">
        <div className="bg-white border border-platinum rounded-lg overflow-hidden">
          {/* Progress */}
          <div className="h-1 bg-platinum/30">
            <div className="h-full bg-sage transition-all" style={{ width: `${progress}%` }} />
          </div>

          <div className="p-8">
            {/* Question number */}
            <p className="text-xs text-platinum uppercase mb-4">
              Question {currentStep} of {totalQuestions}
            </p>

            {/* Question */}
            <h2 className="text-lg font-semibold text-charcoal mb-6">
              {currentQuestion.question}
            </h2>

            {/* Options */}
            <div className="space-y-3 mb-8">
              {currentQuestion.options.map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleAnswer(option.value)}
                  className={cn(
                    "w-full text-left px-4 py-4 border rounded transition-all",
                    answers[currentQuestion.id] === option.value
                      ? "border-charcoal bg-charcoal/5"
                      : "border-platinum hover:border-charcoal/50"
                  )}
                >
                  <span className="text-sm text-charcoal">{option.label}</span>
                </button>
              ))}
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between">
              <button
                onClick={handleBack}
                className="flex items-center gap-2 text-platinum hover:text-charcoal"
              >
                <ChevronLeftIcon /> Back
              </button>
              <button
                onClick={handleNext}
                disabled={!canProceed}
                className="flex items-center gap-2 px-6 py-3 bg-charcoal text-white font-medium rounded hover:bg-charcoal/90 disabled:opacity-50"
              >
                {currentStep === totalQuestions ? 'Continue' : 'Next'} <ChevronRightIcon />
              </button>
            </div>
          </div>
        </div>

        <p className="text-xs text-platinum text-center mt-4">
          Powered by FinanceKeem
        </p>
      </div>
    </div>
  )
}
