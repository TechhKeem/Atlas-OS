import { useState, useEffect } from 'react'
import { db } from '@/lib/db'
import { cn } from '@/lib/utils'
import { 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  addDays, 
  format, 
  isSameMonth, 
  isSameDay,
  addMonths,
  subMonths
} from 'date-fns'

// Icons
const ChevronLeftIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="m15 18-6-6 6-6"/>
  </svg>
)

const ChevronRightIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="m9 18 6-6-6-6"/>
  </svg>
)

export default function Calendar() {
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [bookings, setBookings] = useState([])

  useEffect(() => {
    setBookings(db.getBookings())
  }, [])

  const monthStart = startOfMonth(currentMonth)
  const monthEnd = endOfMonth(currentMonth)
  const calendarStart = startOfWeek(monthStart)
  const calendarEnd = endOfWeek(monthEnd)

  const days = []
  let day = calendarStart
  while (day <= calendarEnd) {
    days.push(day)
    day = addDays(day, 1)
  }

  const getBookingsForDay = (date) => {
    const dateStr = format(date, 'yyyy-MM-dd')
    return bookings.filter(b => b.date === dateStr)
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-charcoal">Calendar</h1>
        <p className="text-sm text-platinum mt-1">View and manage your scheduled appointments</p>
      </div>

      <div className="bg-white border border-platinum rounded-lg overflow-hidden">
        {/* Calendar Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-platinum">
          <button
            onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
            className="p-2 hover:bg-softwhite rounded"
          >
            <ChevronLeftIcon />
          </button>
          <h2 className="text-lg font-semibold text-charcoal">
            {format(currentMonth, 'MMMM yyyy')}
          </h2>
          <button
            onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
            className="p-2 hover:bg-softwhite rounded"
          >
            <ChevronRightIcon />
          </button>
        </div>

        {/* Day Headers */}
        <div className="grid grid-cols-7 border-b border-platinum">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(dayName => (
            <div key={dayName} className="py-3 text-center text-xs font-medium text-platinum uppercase">
              {dayName}
            </div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7">
          {days.map((day, idx) => {
            const dayBookings = getBookingsForDay(day)
            const isToday = isSameDay(day, new Date())
            const isCurrentMonth = isSameMonth(day, currentMonth)

            return (
              <div
                key={idx}
                className={cn(
                  "min-h-24 p-2 border-b border-r border-platinum/50",
                  !isCurrentMonth && "bg-softwhite/50"
                )}
              >
                <div className={cn(
                  "text-sm font-medium mb-1",
                  isToday ? "text-white bg-sage w-6 h-6 rounded-full flex items-center justify-center" : 
                  isCurrentMonth ? "text-charcoal" : "text-platinum"
                )}>
                  {format(day, 'd')}
                </div>
                {dayBookings.map(booking => (
                  <div
                    key={booking.id}
                    className="text-xs bg-sage/10 text-sage px-1.5 py-0.5 rounded mb-1 truncate"
                    title={`${booking.name} - ${booking.time}`}
                  >
                    {booking.time} {booking.name}
                  </div>
                ))}
              </div>
            )
          })}
        </div>
      </div>

      {/* Upcoming Bookings */}
      <div className="mt-6">
        <h3 className="text-base font-semibold text-charcoal mb-3">Upcoming Appointments</h3>
        {bookings.length === 0 ? (
          <p className="text-sm text-platinum">No appointments scheduled.</p>
        ) : (
          <div className="space-y-2">
            {bookings
              .filter(b => new Date(b.date) >= new Date())
              .sort((a, b) => new Date(a.date) - new Date(b.date))
              .slice(0, 5)
              .map(booking => (
                <div key={booking.id} className="bg-white border border-platinum p-3 rounded flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-charcoal">{booking.name}</p>
                    <p className="text-xs text-platinum">{booking.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-charcoal">{format(new Date(booking.date), 'MMM d, yyyy')}</p>
                    <p className="text-xs text-platinum">{booking.time}</p>
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  )
}
