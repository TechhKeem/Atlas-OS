import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { Calendar, Bell, Palette, Link2, Save } from "lucide-react";
import CalendarConnection from "../components/settings/CalendarConnection";

export default function SettingsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [generalSettings, setGeneralSettings] = useState({
    company_name: "",
    timezone: "America/New_York"
  });

  const [notificationSettings, setNotificationSettings] = useState({
    email_confirmations: true,
    email_reminders: true,
    reminder_hours_before: 24
  });

  const [brandingSettings, setBrandingSettings] = useState({
    primary_color: "#20242d",
    logo_url: ""
  });

  const { data: settings = [] } = useQuery({
    queryKey: ["settings"],
    queryFn: () => base44.entities.Settings.list()
  });

  useEffect(() => {
    const general = settings.find((s) => s.setting_key === "general");
    const notifications = settings.find((s) => s.setting_key === "notifications");
    const branding = settings.find((s) => s.setting_key === "branding");

    if (general?.setting_value) setGeneralSettings(general.setting_value);
    if (notifications?.setting_value) setNotificationSettings(notifications.setting_value);
    if (branding?.setting_value) setBrandingSettings(branding.setting_value);
  }, [settings]);

  const saveMutation = useMutation({
    mutationFn: async (updates) => {
      for (const [key, value] of Object.entries(updates)) {
        const existing = settings.find((s) => s.setting_key === key);
        if (existing) {
          await base44.entities.Settings.update(existing.id, {
            setting_value: value
          });
        } else {
          await base44.entities.Settings.create({
            setting_key: key,
            setting_value: value,
            category: key
          });
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["settings"] });
      toast({ title: "Settings saved" });
    }
  });

  const handleSave = () => {
    saveMutation.mutate({
      general: generalSettings,
      notifications: notificationSettings,
      branding: brandingSettings
    });
  };

  return (
    <div className="min-h-screen bg-[#fafafa]">
      <div className="flex items-center justify-between h-14 px-6 border-b border-[#e8e8e8] bg-white">
        <h1 className="text-[15px] font-semibold text-[#20242d]">Settings</h1>
        <Button
          onClick={handleSave}
          disabled={saveMutation.isPending}
          className="h-8 px-3 bg-[#20242d] text-white hover:bg-[#2d323d] text-[13px] rounded-none"
        >
          <Save className="h-4 w-4 mr-1.5" />
          Save Changes
        </Button>
      </div>

      <div className="max-w-3xl mx-auto p-6 space-y-6">
        {/* General Settings */}
        <Card className="rounded-none border-[#e8e8e8]">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-[15px] font-semibold text-[#20242d]">
              <Calendar className="h-4 w-4" />
              General
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Company Name
              </Label>
              <Input
                value={generalSettings.company_name}
                onChange={(e) =>
                  setGeneralSettings({ ...generalSettings, company_name: e.target.value })
                }
                placeholder="Your Company"
                className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Timezone
              </Label>
              <Input
                value={generalSettings.timezone}
                onChange={(e) =>
                  setGeneralSettings({ ...generalSettings, timezone: e.target.value })
                }
                placeholder="America/New_York"
                className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
              />
            </div>
          </CardContent>
        </Card>

        {/* Calendar Connection */}
        <Card className="rounded-none border-[#e8e8e8]">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-[15px] font-semibold text-[#20242d]">
              <Link2 className="h-4 w-4" />
              Connected Calendars
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CalendarConnection />
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="rounded-none border-[#e8e8e8]">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-[15px] font-semibold text-[#20242d]">
              <Bell className="h-4 w-4" />
              Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[13px] font-medium text-[#20242d]">
                  Email Confirmations
                </p>
                <p className="text-[12px] text-[#666]">
                  Send confirmation emails when bookings are made
                </p>
              </div>
              <Switch
                checked={notificationSettings.email_confirmations}
                onCheckedChange={(checked) =>
                  setNotificationSettings({ ...notificationSettings, email_confirmations: checked })
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[13px] font-medium text-[#20242d]">
                  Email Reminders
                </p>
                <p className="text-[12px] text-[#666]">
                  Send reminder emails before scheduled meetings
                </p>
              </div>
              <Switch
                checked={notificationSettings.email_reminders}
                onCheckedChange={(checked) =>
                  setNotificationSettings({ ...notificationSettings, email_reminders: checked })
                }
              />
            </div>
            {notificationSettings.email_reminders && (
              <div className="space-y-2 pl-0">
                <Label className="text-[13px] font-medium text-[#20242d]">
                  Reminder Time (hours before)
                </Label>
                <Input
                  type="number"
                  min="1"
                  max="72"
                  value={notificationSettings.reminder_hours_before}
                  onChange={(e) =>
                    setNotificationSettings({
                      ...notificationSettings,
                      reminder_hours_before: parseInt(e.target.value) || 24
                    })
                  }
                  className="h-10 w-32 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Branding */}
        <Card className="rounded-none border-[#e8e8e8]">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-[15px] font-semibold text-[#20242d]">
              <Palette className="h-4 w-4" />
              Branding
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Primary Color
              </Label>
              <div className="flex items-center gap-3">
                <Input
                  type="color"
                  value={brandingSettings.primary_color}
                  onChange={(e) =>
                    setBrandingSettings({ ...brandingSettings, primary_color: e.target.value })
                  }
                  className="h-10 w-14 p-1 rounded-none border-[#e8e8e8] cursor-pointer"
                />
                <Input
                  value={brandingSettings.primary_color}
                  onChange={(e) =>
                    setBrandingSettings({ ...brandingSettings, primary_color: e.target.value })
                  }
                  className="h-10 w-28 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0 font-mono text-[13px]"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                Logo URL
              </Label>
              <Input
                value={brandingSettings.logo_url}
                onChange={(e) =>
                  setBrandingSettings({ ...brandingSettings, logo_url: e.target.value })
                }
                placeholder="https://example.com/logo.png"
                className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}