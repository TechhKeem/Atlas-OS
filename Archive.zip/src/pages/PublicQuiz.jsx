import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { CheckCircle2 } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function PublicQuiz() {
  const [formData, setFormData] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [quizResult, setQuizResult] = useState(null);

  const urlParams = new URLSearchParams(window.location.search);
  const quizId = urlParams.get("quizId");

  const { data: quiz, isLoading } = useQuery({
    queryKey: ["quiz", quizId],
    queryFn: async () => {
      const quizzes = await base44.entities.Quiz.filter({ id: quizId });
      return quizzes[0];
    },
    enabled: !!quizId,
  });

  const { data: bookingPage } = useQuery({
    queryKey: ["bookingPage", quiz?.booking_page_id],
    queryFn: async () => {
      const pages = await base44.entities.BookingPage.filter({ id: quiz.booking_page_id });
      return pages[0];
    },
    enabled: !!quiz?.booking_page_id,
  });

  const submitMutation = useMutation({
    mutationFn: async (data) => {
      // Calculate quiz score
      let totalScore = 0;
      let userScore = 0;

      quiz.fields.forEach(field => {
        const userAnswer = data[field.id];
        
        if (field.type === "select" || field.type === "multiselect") {
          const options = field.options || [];
          if (field.type === "select") {
            const selectedOption = options.find(opt => opt.value === userAnswer);
            if (selectedOption) {
              userScore += selectedOption.score || 0;
              totalScore += Math.max(...options.map(o => o.score || 0));
            }
          } else if (field.type === "multiselect" && Array.isArray(userAnswer)) {
            userAnswer.forEach(answer => {
              const selectedOption = options.find(opt => opt.value === answer);
              if (selectedOption) {
                userScore += selectedOption.score || 0;
              }
            });
            totalScore += options.reduce((sum, o) => sum + (o.score || 0), 0);
          }
        } else if (field.correct_answer) {
          totalScore += field.score_if_correct || 1;
          if (String(userAnswer).toLowerCase().trim() === String(field.correct_answer).toLowerCase().trim()) {
            userScore += field.score_if_correct || 1;
          }
        }
      });

      setQuizResult({ score: userScore, totalScore });

      // Build record data from quiz fields
      const recordData = {
        status: "new",
        custom_fields: {}
      };

      quiz.fields.forEach(field => {
        const value = data[field.id];
        if (value !== undefined && value !== null && value !== "") {
          // Map common fields
          if (field.label.toLowerCase().includes("name")) {
            recordData.client_name = value;
          } else if (field.type === "email") {
            recordData.client_email = value;
          } else if (field.type === "phone") {
            recordData.client_phone = value;
          } else {
            const customFieldName = field.label.toLowerCase().replace(/\s+/g, '_');
            recordData.custom_fields[customFieldName] = value;
          }
        }
      });

      // Add quiz results to custom_fields
      recordData.custom_fields.quiz_score = userScore;
      recordData.custom_fields.quiz_total_score = totalScore;
      recordData.custom_fields.quiz_name = quiz.title;

      if (!recordData.title) {
        recordData.title = recordData.client_name || recordData.client_email || "Quiz submission";
      }

      // Check if a record already exists for this email
      const clientEmail = recordData.client_email;
      if (clientEmail) {
        const existingRecords = await base44.entities.DatabaseRecord.filter({ client_email: clientEmail });
        
        if (existingRecords.length > 0) {
          // Update existing record
          const existingRecord = existingRecords[0];
          const mergedCustomFields = { ...existingRecord.custom_fields, ...recordData.custom_fields };
          return base44.entities.DatabaseRecord.update(existingRecord.id, {
            ...recordData,
            custom_fields: mergedCustomFields
          });
        }
      }

      // Create new record if none exists
      return base44.entities.DatabaseRecord.create(recordData);
    },
    onSuccess: () => {
      if (quiz.redirect_enabled && quiz.redirect_url) {
        window.location.href = quiz.redirect_url;
      } else {
        setSubmitted(true);
      }
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    submitMutation.mutate(formData);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#fafafa] flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-[#20242d] border-t-transparent animate-spin" />
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-screen bg-[#fafafa] flex items-center justify-center">
        <div className="text-center">
          <p className="text-[#666] text-[14px]">Quiz not found</p>
        </div>
      </div>
    );
  }

  if (submitted && quizResult) {
    let resultMessage = "";
    
    // Check if score ranges are defined
    if (quiz.score_ranges && quiz.score_ranges.length > 0) {
      const matchingRange = quiz.score_ranges.find(
        range => quizResult.score >= range.min_score && quizResult.score <= range.max_score
      );
      resultMessage = matchingRange ? matchingRange.message : "Thank you for completing the quiz!";
    } else {
      // Fallback to the default message
      resultMessage = quiz.result_message || "Your score is {{score}} out of {{totalScore}}!";
      resultMessage = resultMessage
        .replace(/{{score}}/g, quizResult.score)
        .replace(/{{totalScore}}/g, quizResult.totalScore);
    }

    return (
      <div className="min-h-screen bg-[#fafafa] flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white border border-[#e8e8e8] p-8 text-center">
          <CheckCircle2 className="h-16 w-16 text-green-600 mx-auto mb-4" />
          <h2 className="text-[20px] font-semibold text-[#20242d] mb-2">
            Quiz Complete!
          </h2>
          <div className="text-[32px] font-bold text-[#20242d] mb-4">
            {quizResult.score} / {quizResult.totalScore}
          </div>
          <p className="text-[14px] text-[#666] whitespace-pre-line">
            {resultMessage}
          </p>
          {bookingPage && (
            <Button
              onClick={() => window.open(createPageUrl(`PublicBooking?slug=${bookingPage.slug}`), "_blank")}
              className="w-full mt-6 h-11 bg-[#20242d] hover:bg-[#2d323d] rounded-none text-[14px]"
            >
              {quiz.booking_button_text || "Book an Appointment"}
            </Button>
          )}
        </div>
      </div>
    );
  }

  const renderField = (field) => {
    const value = formData[field.id] || "";

    switch (field.type) {
      case "textarea":
        return (
          <Textarea
            value={value}
            onChange={(e) => setFormData({ ...formData, [field.id]: e.target.value })}
            placeholder={field.placeholder}
            required={field.required}
            className="rounded-none border-[#e8e8e8]"
          />
        );

      case "select":
        return (
          <Select
            value={value}
            onValueChange={(val) => setFormData({ ...formData, [field.id]: val })}
            required={field.required}
          >
            <SelectTrigger className="rounded-none border-[#e8e8e8]">
              <SelectValue placeholder={field.placeholder || "Select..."} />
            </SelectTrigger>
            <SelectContent className="rounded-none">
              {(field.options || []).map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.value}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case "multiselect":
        return (
          <div className="space-y-2">
            {(field.options || []).map((opt) => (
              <div key={opt.value} className="flex items-center space-x-2">
                <Checkbox
                  checked={(value || []).includes(opt.value)}
                  onCheckedChange={(checked) => {
                    const current = value || [];
                    const updated = checked
                      ? [...current, opt.value]
                      : current.filter((v) => v !== opt.value);
                    setFormData({ ...formData, [field.id]: updated });
                  }}
                />
                <Label className="text-[13px] text-[#666]">{opt.value}</Label>
              </div>
            ))}
          </div>
        );

      case "phone":
        return (
          <Input
            type="tel"
            value={value}
            onChange={(e) => {
              const val = e.target.value.replace(/\D/g, '');
              let formatted = '';
              if (val.length > 0) {
                formatted = '+1 (' + val.substring(0, 3);
                if (val.length >= 4) formatted += ') ' + val.substring(3, 6);
                if (val.length >= 7) formatted += '-' + val.substring(6, 10);
              }
              setFormData({ ...formData, [field.id]: formatted });
            }}
            placeholder={field.placeholder}
            required={field.required}
            className="rounded-none border-[#e8e8e8]"
            maxLength={17}
          />
        );

      default:
        return (
          <Input
            type={field.type}
            value={value}
            onChange={(e) => setFormData({ ...formData, [field.id]: e.target.value })}
            placeholder={field.placeholder}
            required={field.required}
            className="rounded-none border-[#e8e8e8]"
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#fafafa] py-12 px-6">
      <div className="max-w-2xl mx-auto bg-white border border-[#e8e8e8] p-8">
        <h1 className="text-[24px] font-semibold text-[#20242d] mb-2">
          {quiz.title}
        </h1>
        {quiz.description && (
          <p className="text-[14px] text-[#666] mb-8">{quiz.description}</p>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {(quiz.fields || []).map((field) => (
            <div key={field.id} className="space-y-2">
              <Label className="text-[13px] font-medium text-[#20242d]">
                {field.label}
                {field.required && <span className="text-red-500 ml-1">*</span>}
              </Label>
              {renderField(field)}
            </div>
          ))}

          <Button
            type="submit"
            disabled={submitMutation.isPending}
            className="w-full h-10 bg-[#20242d] hover:bg-[#2d323d] rounded-none text-[14px]"
          >
            {submitMutation.isPending ? "Submitting..." : "Submit Quiz"}
          </Button>
        </form>
      </div>
    </div>
  );
}