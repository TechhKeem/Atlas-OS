import Layout from "./Layout.jsx";

import BookingPages from "./BookingPages";

import Calendar from "./Calendar";

import Database from "./Database";

import Forms from "./Forms";

import LeadCapture from "./LeadCapture";

import PublicBooking from "./PublicBooking";

import PublicForm from "./PublicForm";

import PublicQuiz from "./PublicQuiz";

import Quizzes from "./Quizzes";

import Settings from "./Settings";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    BookingPages: BookingPages,
    
    Calendar: Calendar,
    
    Database: Database,
    
    Forms: Forms,
    
    LeadCapture: LeadCapture,
    
    PublicBooking: PublicBooking,
    
    PublicForm: PublicForm,
    
    PublicQuiz: PublicQuiz,
    
    Quizzes: Quizzes,
    
    Settings: Settings,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<BookingPages />} />
                
                
                <Route path="/BookingPages" element={<BookingPages />} />
                
                <Route path="/Calendar" element={<Calendar />} />
                
                <Route path="/Database" element={<Database />} />
                
                <Route path="/Forms" element={<Forms />} />
                
                <Route path="/LeadCapture" element={<LeadCapture />} />
                
                <Route path="/PublicBooking" element={<PublicBooking />} />
                
                <Route path="/PublicForm" element={<PublicForm />} />
                
                <Route path="/PublicQuiz" element={<PublicQuiz />} />
                
                <Route path="/Quizzes" element={<Quizzes />} />
                
                <Route path="/Settings" element={<Settings />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}