
export function createPageUrl(pageName) {
    return '/' + pageName;
}