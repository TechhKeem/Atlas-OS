import { base44 } from './base44Client';


export const Event = base44.entities.Event;

export const DatabaseRecord = base44.entities.DatabaseRecord;

export const BookingPage = base44.entities.BookingPage;

export const Form = base44.entities.Form;

export const Booking = base44.entities.Booking;

export const DatabaseField = base44.entities.DatabaseField;

export const DatabaseView = base44.entities.DatabaseView;

export const Settings = base44.entities.Settings;

export const ConnectedCalendar = base44.entities.ConnectedCalendar;

export const Quiz = base44.entities.Quiz;



// auth sdk:
export const User = base44.auth;