import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, ExternalLink, MoreHorizontal, Clock } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { createPageUrl } from "@/utils";

export default function BookingPageCard({ bookingPage, onEdit, onCopyLink, onPreview }) {
  const bookingUrl = `${window.location.origin}${createPageUrl('PublicBooking')}?slug=${bookingPage.slug}`;

  return (
    <Card className="p-5 border-[#e8e8e8] rounded-none hover:border-[#d0d0d0] transition-colors">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="text-[15px] font-semibold text-[#20242d] truncate">
              {bookingPage.title}
            </h3>
            <Badge
              variant="outline"
              className={`text-[11px] rounded-none ${
                bookingPage.is_active
                  ? "bg-green-50 text-green-700 border-green-200"
                  : "bg-gray-50 text-gray-600 border-gray-200"
              }`}
            >
              {bookingPage.is_active ? "Active" : "Inactive"}
            </Badge>
          </div>
          <p className="text-[13px] text-[#666] line-clamp-2">
            {bookingPage.description || "No description"}
          </p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 text-[#666] hover:text-[#20242d] hover:bg-[#f5f5f5] rounded-none"
            >
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="rounded-none">
            <DropdownMenuItem onClick={() => onEdit(bookingPage)}>
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => window.open(bookingUrl, '_blank')}>
              Preview
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onPreview(bookingPage)}>
              Share & Embed
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="flex items-center gap-4 mb-4 text-[13px] text-[#666]">
        <div className="flex items-center gap-1.5">
          <Clock className="h-4 w-4" />
          <span>{bookingPage.duration_minutes} min</span>
        </div>
      </div>

      <div className="flex items-center gap-2 p-2.5 bg-[#fafafa] border border-[#e8e8e8]">
        <span className="flex-1 text-[12px] text-[#666] truncate font-mono">
          {bookingUrl}
        </span>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onCopyLink(bookingUrl)}
          className="h-7 w-7 p-0 text-[#666] hover:text-[#20242d] hover:bg-[#e8e8e8] rounded-none"
        >
          <Copy className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => window.open(bookingUrl, '_blank')}
          className="h-7 w-7 p-0 text-[#666] hover:text-[#20242d] hover:bg-[#e8e8e8] rounded-none"
        >
          <ExternalLink className="h-3.5 w-3.5" />
        </Button>
      </div>
    </Card>
  );
}