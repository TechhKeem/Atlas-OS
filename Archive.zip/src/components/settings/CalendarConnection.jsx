import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Calendar, RefreshCw, Check, Plug } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

export default function CalendarConnection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCalendarSelection, setShowCalendarSelection] = useState(false);

  const { data: connectedResponse, isLoading: isLoadingConnected } = useQuery({
    queryKey: ["connected-google-calendars"],
    queryFn: async () => {
      const result = await base44.functions.invoke("listGoogleCalendars", {});
      return result.data;
    }
  });

  const { data: availableResponse, isLoading: isLoadingAvailable } = useQuery({
    queryKey: ["available-google-calendars"],
    queryFn: async () => {
      const result = await base44.functions.invoke("listAvailableGoogleCalendars", {});
      return result.data;
    },
    enabled: showCalendarSelection,
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      const result = await base44.functions.invoke("syncGoogleCalendar", {});
      return result.data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["connected-google-calendars"] });
      queryClient.invalidateQueries({ queryKey: ["events"] });
      toast({ title: `Synced ${data.synced} events` });
    }
  });

  const updateCalendarMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return base44.entities.ConnectedCalendar.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["connected-google-calendars"] });
      toast({ title: "Calendar settings updated" });
    }
  });

  const connectCalendarMutation = useMutation({
    mutationFn: async (calendarData) => {
      return base44.entities.ConnectedCalendar.create(calendarData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["connected-google-calendars"] });
      toast({ title: "Calendar connected" });
    },
  });

  const disconnectCalendarMutation = useMutation({
    mutationFn: async (id) => {
      return base44.entities.ConnectedCalendar.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["connected-google-calendars"] });
      toast({ title: "Calendar disconnected" });
    },
  });

  const setPrimaryMutation = useMutation({
    mutationFn: async (calendarId) => {
      const calendars = connectedCalendars || [];
      for (const cal of calendars) {
        if (cal.is_primary) {
          await base44.entities.ConnectedCalendar.update(cal.id, { is_primary: false });
        }
      }
      await base44.entities.ConnectedCalendar.update(calendarId, { is_primary: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["connected-google-calendars"] });
      toast({ title: "Primary calendar updated" });
    },
  });

  const connectedCalendars = connectedResponse?.connected || [];
  const availableCalendars = availableResponse?.calendars || [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[13px] text-[#666]">
            {connectedCalendars.length} calendar{connectedCalendars.length !== 1 ? "s" : ""} connected
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => syncMutation.mutate()}
            disabled={syncMutation.isPending}
            className="h-8 px-3 text-[13px] rounded-none border-[#e8e8e8]"
          >
            <RefreshCw className={`h-4 w-4 mr-1.5 ${syncMutation.isPending ? "animate-spin" : ""}`} />
            Sync Now
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={() => setShowCalendarSelection(true)}
            className="h-8 px-3 text-[13px] rounded-none bg-[#20242d] hover:bg-[#2d323d]"
          >
            <Plug className="h-4 w-4 mr-1.5" />
            Connect Calendar
          </Button>
        </div>
      </div>

      {isLoadingConnected ? (
        <div className="flex items-center justify-center py-8">
          <div className="w-6 h-6 border-2 border-[#20242d] border-t-transparent animate-spin" />
        </div>
      ) : connectedCalendars.length === 0 ? (
        <Card className="rounded-none border-[#e8e8e8]">
          <CardContent className="p-6 text-center">
            <Calendar className="h-12 w-12 mx-auto mb-3 text-[#999]" />
            <p className="text-[13px] text-[#666] mb-3">
              No calendars connected. Click "Connect Calendar" to get started.
            </p>
            <Button
              variant="default"
              onClick={() => setShowCalendarSelection(true)}
              className="h-8 px-3 text-[13px] rounded-none bg-[#20242d] hover:bg-[#2d323d]"
            >
              <Plug className="h-4 w-4 mr-1.5" />
              Connect Calendar
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {connectedCalendars.map((calendar) => (
            <Card key={calendar.id} className="rounded-none border-[#e8e8e8]">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-[14px] font-medium text-[#20242d] truncate">
                        {calendar.calendar_name}
                      </h4>
                      {calendar.is_primary && (
                        <Badge className="bg-[#20242d] text-white text-[10px] rounded-none">
                          PRIMARY
                        </Badge>
                      )}
                    </div>
                    <p className="text-[12px] text-[#666] truncate font-mono">
                      {calendar.calendar_id}
                    </p>
                    {calendar.last_sync && (
                      <p className="text-[11px] text-[#999] mt-1">
                        Last synced: {format(new Date(calendar.last_sync), "MMM d, h:mm a")}
                      </p>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setPrimaryMutation.mutate(calendar.id)}
                    disabled={calendar.is_primary || setPrimaryMutation.isPending}
                    className="h-8 px-3 text-[11px] text-[#666] hover:text-[#20242d] rounded-none"
                  >
                    {calendar.is_primary ? (
                      <>
                        <Check className="h-3 w-3 mr-1" />
                        Primary
                      </>
                    ) : (
                      "Set as Primary"
                    )}
                  </Button>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-[#e8e8e8]">
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={calendar.sync_enabled}
                        onCheckedChange={(checked) =>
                          updateCalendarMutation.mutate({
                            id: calendar.id,
                            data: { sync_enabled: checked }
                          })
                        }
                      />
                      <span className="text-[12px] text-[#666]">Sync Events</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={calendar.check_conflicts}
                        onCheckedChange={(checked) =>
                          updateCalendarMutation.mutate({
                            id: calendar.id,
                            data: { check_conflicts: checked }
                          })
                        }
                      />
                      <span className="text-[12px] text-[#666]">Check Conflicts</span>
                    </div>
                  </div>
                  <Badge
                    variant="outline"
                    className={`text-[10px] rounded-none ${
                      calendar.is_active
                        ? "bg-green-50 text-green-700 border-green-200"
                        : "bg-gray-50 text-gray-600 border-gray-200"
                    }`}
                  >
                    {calendar.is_active ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="pt-2">
        <p className="text-[11px] text-[#999]">
          <strong>Primary calendar:</strong> Where new events are created
          <br />
          <strong>Check conflicts:</strong> Used for availability checking on booking pages
        </p>
      </div>

      <Dialog open={showCalendarSelection} onOpenChange={setShowCalendarSelection}>
        <DialogContent className="sm:max-w-[480px] rounded-none border-[#e8e8e8]">
          <DialogHeader>
            <DialogTitle className="text-[16px] font-semibold text-[#20242d]">
              Connect Google Calendars
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            {isLoadingAvailable ? (
              <div className="flex items-center justify-center py-8">
                <div className="w-6 h-6 border-2 border-[#20242d] border-t-transparent animate-spin" />
              </div>
            ) : availableCalendars.length === 0 ? (
              <p className="text-[13px] text-[#666] text-center py-4">
                No calendars found in your Google account.
              </p>
            ) : (
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {availableCalendars.map((calendar) => {
                  const isConnected = connectedCalendars.some(c => c.calendar_id === calendar.id);
                  const connectedCal = connectedCalendars.find(c => c.calendar_id === calendar.id);
                  
                  return (
                    <div
                      key={calendar.id}
                      className="flex items-center justify-between p-3 border border-[#e8e8e8] hover:bg-[#fafafa] transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-[13px] text-[#20242d] font-medium truncate">
                          {calendar.name}
                        </p>
                        <p className="text-[11px] text-[#999] font-mono truncate">
                          {calendar.id}
                        </p>
                      </div>
                      <Switch
                        checked={isConnected}
                        disabled={connectCalendarMutation.isPending || disconnectCalendarMutation.isPending}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            connectCalendarMutation.mutate({
                              calendar_id: calendar.id,
                              calendar_name: calendar.name,
                              provider: "google",
                              is_primary: connectedCalendars.length === 0,
                              check_conflicts: true,
                              sync_enabled: true,
                              is_active: true,
                            });
                          } else {
                            if (connectedCal) {
                              disconnectCalendarMutation.mutate(connectedCal.id);
                            }
                          }
                        }}
                      />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCalendarSelection(false)}
              className="rounded-none border-[#e8e8e8]"
            >
              Done
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}