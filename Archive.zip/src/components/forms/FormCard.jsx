import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MoreHorizontal, FileText } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import EmbedFormModal from "./EmbedFormModal";

export default function FormCard({ form, onEdit, onDelete }) {
  const [showShareModal, setShowShareModal] = useState(false);
  return (
    <Card className="p-5 border-[#e8e8e8] rounded-none hover:border-[#d0d0d0] transition-colors">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 flex items-center justify-center bg-[#f5f5f5] text-[#20242d]">
            <FileText className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-[15px] font-semibold text-[#20242d]">
              {form.title}
            </h3>
            <p className="text-[12px] text-[#666]">
              {form.fields?.length || 0} fields
            </p>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 text-[#666] hover:text-[#20242d] hover:bg-[#f5f5f5] rounded-none"
            >
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="rounded-none">
            <DropdownMenuItem onClick={() => onEdit(form)}>
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => window.open(`${window.location.origin}/public-form?formId=${form.id}`, '_blank')}>
              Preview
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setShowShareModal(true)}>
              Share & Embed
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => onDelete(form.id)}
              className="text-red-600"
            >
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {form.description && (
        <p className="text-[13px] text-[#666] line-clamp-2 mb-3">
          {form.description}
        </p>
      )}

      <div className="flex items-center gap-2">
        <Badge
          variant="outline"
          className={`text-[11px] rounded-none ${
            form.is_active
              ? "bg-green-50 text-green-700 border-green-200"
              : "bg-gray-50 text-gray-600 border-gray-200"
          }`}
        >
          {form.is_active !== false ? "Active" : "Inactive"}
        </Badge>
      </div>

      <EmbedFormModal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        form={form}
      />
    </Card>
  );
}