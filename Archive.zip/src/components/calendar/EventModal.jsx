import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { format, addHours } from "date-fns";
import { Trash2 } from "lucide-react";

export default function EventModal({
  isOpen,
  onClose,
  event,
  initialDate,
  onSave,
  onDelete
}) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    start_time: "",
    end_time: ""
  });
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (event) {
        setFormData({
          title: event.title || "",
          description: event.description || "",
          start_time: format(new Date(event.start_time), "yyyy-MM-dd'T'HH:mm"),
          end_time: format(new Date(event.end_time), "yyyy-MM-dd'T'HH:mm")
        });
      } else if (initialDate) {
        const startDate = new Date(initialDate);
        const endDate = addHours(startDate, 1);
        setFormData({
          title: "",
          description: "",
          start_time: format(startDate, "yyyy-MM-dd'T'HH:mm"),
          end_time: format(endDate, "yyyy-MM-dd'T'HH:mm")
        });
      } else {
        // Default to current time + 1 hour if no initial date
        const now = new Date();
        const startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() + 1, 0);
        const endDate = addHours(startDate, 1);
        setFormData({
          title: "",
          description: "",
          start_time: format(startDate, "yyyy-MM-dd'T'HH:mm"),
          end_time: format(endDate, "yyyy-MM-dd'T'HH:mm")
        });
      }
    }
  }, [event, initialDate, isOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      ...event,
      ...formData,
      start_time: new Date(formData.start_time).toISOString(),
      end_time: new Date(formData.end_time).toISOString()
    });
  };

  const handleDeleteClick = () => {
    setShowDeleteConfirm(true);
  };

  const handleConfirmDelete = () => {
    if (event?.id && onDelete) {
      onDelete(event.id);
      setShowDeleteConfirm(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[480px] rounded-none border-[#e8e8e8]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-semibold text-[#20242d]">
            {event ? "Edit Event" : "Create Event"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5 py-4">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-[13px] font-medium text-[#20242d]">
              Title
            </Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="Event title"
              className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="start" className="text-[13px] font-medium text-[#20242d]">
                Start
              </Label>
              <Input
                id="start"
                type="datetime-local"
                value={formData.start_time}
                onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="end" className="text-[13px] font-medium text-[#20242d]">
                End
              </Label>
              <Input
                id="end"
                type="datetime-local"
                value={formData.end_time}
                onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                className="h-10 rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-[13px] font-medium text-[#20242d]">
              Description
            </Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Add details..."
              className="min-h-[100px] rounded-none border-[#e8e8e8] focus:border-[#20242d] focus:ring-0 resize-none"
            />
          </div>

          <DialogFooter className="flex justify-between pt-4">
            {event?.id && (
              <Button
                type="button"
                variant="ghost"
                onClick={handleDeleteClick}
                className="text-red-600 hover:text-red-700 hover:bg-red-50 rounded-none"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
            )}
            <div className="flex gap-2 ml-auto">
              <Button
                type="button"
                variant="outline"
                onClick={() => onClose(false)}
                className="rounded-none border-[#e8e8e8]"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-[#20242d] hover:bg-[#2d323d] rounded-none"
                disabled={!formData.title}
              >
                {event ? "Update" : "Create"}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent className="rounded-none border-[#e8e8e8]">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-[16px] font-semibold text-[#20242d]">
              Delete Event?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] text-[#666]">
              This will permanently delete this event from your calendar. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-none border-[#e8e8e8]">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmDelete}
              className="bg-red-600 hover:bg-red-700 text-white rounded-none"
            >
              Delete Event
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Dialog>
  );
}