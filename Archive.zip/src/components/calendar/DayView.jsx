import React, { useState } from "react";
import {
  format,
  isSameDay,
  differenceInMinutes,
  setHours,
  setMinutes,
  addMinutes
} from "date-fns";

const HOUR_HEIGHT = 60;
const START_HOUR = 6;
const END_HOUR = 22;

export default function DayView({ currentDate, events, onEventClick, onTimeSlotClick, onEventDrop }) {
  const [draggedEvent, setDraggedEvent] = useState(null);
  const hours = Array.from({ length: END_HOUR - START_HOUR }, (_, i) => START_HOUR + i);

  const isAllDayEvent = (event) => {
    const start = new Date(event.start_time);
    const end = new Date(event.end_time);
    const durationInHours = differenceInMinutes(end, start) / 60;
    return durationInHours >= 12;
  };

  const dayEvents = events.filter((event) =>
    isSameDay(new Date(event.start_time), currentDate) && !isAllDayEvent(event)
  );

  const dayAllDayEvents = events.filter((event) =>
    isSameDay(new Date(event.start_time), currentDate) && isAllDayEvent(event)
  );

  const getEventStyle = (event) => {
    const start = new Date(event.start_time);
    const end = new Date(event.end_time);
    const startMinutes = start.getHours() * 60 + start.getMinutes() - START_HOUR * 60;
    const duration = differenceInMinutes(end, start);

    return {
      top: `${(startMinutes / 60) * HOUR_HEIGHT}px`,
      height: `${Math.max((duration / 60) * HOUR_HEIGHT, 24)}px`
    };
  };

  const handleTimeSlotClick = (hour) => {
    const clickedTime = setMinutes(setHours(currentDate, hour), 0);
    onTimeSlotClick(clickedTime);
  };

  const handleDragStart = (e, event) => {
    setDraggedEvent(event);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e, hour) => {
    e.preventDefault();
    if (!draggedEvent || !onEventDrop) return;

    const newStartTime = setMinutes(setHours(currentDate, hour), 0);
    const originalStart = new Date(draggedEvent.start_time);
    const originalEnd = new Date(draggedEvent.end_time);
    const duration = differenceInMinutes(originalEnd, originalStart);
    const newEndTime = addMinutes(newStartTime, duration);

    onEventDrop(draggedEvent.id, newStartTime.toISOString(), newEndTime.toISOString());
    setDraggedEvent(null);
  };

  const handleDragEnd = () => {
    setDraggedEvent(null);
  };

  return (
    <div className="flex flex-col h-full bg-white overflow-hidden">
      {/* All-day events */}
      {dayAllDayEvents.length > 0 && (
        <div className="flex-shrink-0 p-2 bg-[#f5f5f5] border-b border-[#e8e8e8] flex flex-wrap gap-2">
          <span className="text-[11px] text-[#666] font-medium">All day:</span>
          {dayAllDayEvents.map(event => (
            <div
              key={event.id}
              className="text-[11px] px-2 py-1 bg-[#20242d]/50 text-white cursor-pointer hover:bg-[#20242d]/60 transition-colors"
              onClick={() => onEventClick(event)}
            >
              {event.title}
            </div>
          ))}
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* Time labels */}
        <div className="w-12 md:w-20 flex-shrink-0 border-r border-[#e8e8e8] pt-8">
        {hours.map((hour) => (
          <div
            key={hour}
            className="relative"
            style={{ height: HOUR_HEIGHT }}
          >
            <span className="absolute -top-2 right-2 md:right-4 text-[10px] md:text-[12px] text-[#999]">
              {format(setHours(new Date(), hour), "h a")}
            </span>
          </div>
        ))}
        </div>

        {/* Day column */}
        <div className="flex-1 overflow-y-auto">
        <div className="relative pt-8">
          {/* Hour slots */}
          {hours.map((hour) => (
            <div
              key={hour}
              className="border-b border-[#e8e8e8] cursor-pointer hover:bg-[#fafafa] transition-colors"
              style={{ height: HOUR_HEIGHT }}
              onClick={() => handleTimeSlotClick(hour)}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, hour)}
            />
          ))}

          {/* Events */}
          <div className="absolute inset-0 pt-8 pointer-events-none px-2 md:px-4">
            {dayEvents.map((event) => {
              const isPastOrDeclined = new Date(event.end_time) < new Date() || event.status === 'cancelled';
              return (
                <div
                  key={event.id}
                  draggable
                  onDragStart={(e) => handleDragStart(e, event)}
                  onDragEnd={handleDragEnd}
                  className={`absolute left-2 right-2 md:left-4 md:right-4 px-2 md:px-4 py-1 md:py-2 bg-[#20242d] text-white overflow-hidden cursor-move pointer-events-auto hover:bg-[#2d323d] transition-colors ${isPastOrDeclined ? 'opacity-60' : ''}`}
                  style={getEventStyle(event)}
                  onClick={() => onEventClick(event)}
                >
                  <div className="text-[11px] md:text-[13px] font-medium truncate">
                    {event.title}
                  </div>
                  <div className="text-[10px] md:text-[12px] opacity-80 mt-0.5">
                    {format(new Date(event.start_time), "h:mm a")} –{" "}
                    {format(new Date(event.end_time), "h:mm a")}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
        </div>
      </div>
    </div>
  );
}