
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import {
  Database,
  Calendar,
  FileText,
  Link2,
  Settings,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Menu,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";

const navItems = [
  { name: "Database", icon: Database, page: "Database" },
  { name: "Calendar", icon: Calendar, page: "Calendar" },
  { name: "Lead Capture", icon: FileText, page: "LeadCapture" },
  { name: "Booking Pages", icon: Link2, page: "BookingPages" },
  { name: "Settings", icon: Settings, page: "Settings" },
];

export default function Layout({ children, currentPageName }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [user, setUser] = useState(null);
  const location = useLocation();

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (e) {
        // Not logged in
      }
    };
    loadUser();
  }, []);

  // Public pages - no layout
  if (currentPageName === "PublicBooking" || currentPageName === "PublicForm" || currentPageName === "PublicQuiz") {
    return <>{children}</>;
  }

  const handleLogout = async () => {
    try {
      await base44.auth.logout();
    } catch (error) {
      console.error('Logout error:', error);
      window.location.reload();
    }
  };

  return (
    <TooltipProvider>
      <Toaster />
      <div className="flex min-h-screen bg-[#fafafa]">
        {/* Mobile Header */}
        <div className="md:hidden fixed top-0 left-0 right-0 h-14 bg-white border-b border-[#e8e8e8] z-50 flex items-center justify-between px-4">
          <span className="text-[15px] font-semibold tracking-tight text-[#20242d]">
            Schedule
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="h-8 w-8 p-0"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {/* Mobile Menu Overlay */}
        {mobileMenuOpen && (
          <div
            className="md:hidden fixed inset-0 bg-black/20 z-40"
            onClick={() => setMobileMenuOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside
          className={`fixed left-0 top-0 h-full bg-white border-r border-[#e8e8e8] z-40 transition-all duration-300 ease-in-out ${
            collapsed ? "w-16" : "w-56"
          } ${mobileMenuOpen ? "translate-x-0" : "-translate-x-full"} md:translate-x-0`}
        >
          <div className="flex flex-col h-full">
            {/* Logo */}
            <div className="h-14 flex items-center justify-between px-4 border-b border-[#e8e8e8]">
              {!collapsed && (
                <span className="text-[15px] font-semibold tracking-tight text-[#20242d]">
                  Schedule
                </span>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setCollapsed(!collapsed)}
                className="h-8 w-8 p-0 text-[#20242d] hover:bg-[#f5f5f5]"
              >
                {collapsed ? (
                  <ChevronRight className="h-4 w-4" />
                ) : (
                  <ChevronLeft className="h-4 w-4" />
                )}
              </Button>
            </div>

            {/* Navigation */}
            <nav className="flex-1 py-4 px-2">
              <ul className="space-y-1">
                {navItems.map((item) => {
                  const isActive = currentPageName === item.page;
                  const NavIcon = item.icon;

                  const linkElement = (
                    <Link
                      to={createPageUrl(item.page)}
                      onClick={mobileMenuOpen ? () => setMobileMenuOpen(false) : undefined}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-none transition-colors ${
                        isActive
                          ? "bg-[#20242d] text-white"
                          : "text-[#20242d] hover:bg-[#f5f5f5]"
                      }`}
                    >
                      <NavIcon className="h-[18px] w-[18px] flex-shrink-0" />
                      {!collapsed && (
                        <span className="text-[14px] font-medium">{item.name}</span>
                      )}
                    </Link>
                  );

                  if (mobileMenuOpen) {
                    return <li key={item.name}>{linkElement}</li>;
                  }

                  if (collapsed) {
                    return (
                      <li key={item.name} className="hidden md:block">
                        <Tooltip delayDuration={0}>
                          <TooltipTrigger asChild>{linkElement}</TooltipTrigger>
                          <TooltipContent side="right" className="bg-[#20242d] text-white border-0">
                            {item.name}
                          </TooltipContent>
                        </Tooltip>
                      </li>
                    );
                  }

                  return <li key={item.name} className="hidden md:block">{linkElement}</li>;
                })}
              </ul>
            </nav>

            {/* User section */}
            {user && (
              <div className="p-3 border-t border-[#e8e8e8]">
                <div className={`flex items-center ${collapsed ? "justify-center" : "gap-3"}`}>
                  <div className="h-8 w-8 rounded-none bg-[#20242d] text-white flex items-center justify-center text-sm font-medium flex-shrink-0">
                    {user.full_name?.charAt(0)?.toUpperCase() || user.email?.charAt(0)?.toUpperCase()}
                  </div>
                  {!collapsed && (
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] font-medium text-[#20242d] truncate">
                        {user.full_name || user.email}
                      </p>
                    </div>
                  )}
                  {!collapsed && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleLogout}
                      className="h-8 w-8 p-0 text-[#20242d] hover:bg-[#f5f5f5]"
                    >
                      <LogOut className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            )}
          </div>
        </aside>

        {/* Main content */}
        <main
          className={`flex-1 transition-all duration-300 ease-in-out pt-14 md:pt-0 ${
            collapsed ? "md:ml-16" : "md:ml-56"
          }`}
        >
          {children}
        </main>
      </div>
    </TooltipProvider>
  );
}
