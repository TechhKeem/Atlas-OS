import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { addDays, addWeeks, addMonths, subDays, subWeeks, subMonths, setHours, setMinutes } from "date-fns";
import { useToast } from "@/components/ui/use-toast";
import CalendarHeader from "../components/calendar/CalendarHeader";
import MonthView from "../components/calendar/MonthView";
import WeekView from "../components/calendar/WeekView";
import DayView from "../components/calendar/DayView";
import EventModal from "../components/calendar/EventModal";

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState("week");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [initialDate, setInitialDate] = useState(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: events = [], isLoading, refetch } = useQuery({
    queryKey: ["events"],
    queryFn: async () => {
      // Sync from Google Calendar first
      try {
        await base44.functions.invoke('syncGoogleCalendar', {});
      } catch (error) {
        console.error('Sync error:', error);
      }
      // Then fetch all events
      return base44.entities.Event.filter({ status: "active" }, "-start_time");
    },
    refetchInterval: 60000 // Refresh every minute
  });

  const createEventMutation = useMutation({
    mutationFn: async (eventData) => {
      const response = await base44.functions.invoke('createGoogleCalendarEvent', {
        title: eventData.title,
        description: eventData.description,
        start_time: eventData.start_time,
        end_time: eventData.end_time
      });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["events"] });
      setIsModalOpen(false);
      setSelectedEvent(null);
      setInitialDate(null);
      toast({ title: "Event created successfully", duration: 10000 });
    },
    onError: (error) => {
      console.error('Create event error:', error);
      toast({ 
        title: "Failed to create event", 
        description: error?.response?.data?.error || 'An error occurred',
        variant: "destructive",
        duration: 10000
      });
    }
  });

  const updateEventMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      const response = await base44.functions.invoke('updateGoogleCalendarEvent', {
        event_id: id,
        title: data.title,
        description: data.description,
        start_time: data.start_time,
        end_time: data.end_time
      });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["events"] });
      setIsModalOpen(false);
      setSelectedEvent(null);
      toast({ title: "Event updated successfully", duration: 10000 });
    },
    onError: (error) => {
      console.error('Update event error:', error);
      toast({ 
        title: "Failed to update event", 
        description: error?.response?.data?.error || 'An error occurred',
        variant: "destructive",
        duration: 10000
      });
    }
  });

  const deleteEventMutation = useMutation({
    mutationFn: async (id) => {
      // Delete from Google Calendar via backend function
      const response = await base44.functions.invoke('deleteGoogleCalendarEvent', {
        event_id: id
      });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["events"] });
      setIsModalOpen(false);
      setSelectedEvent(null);
      toast({ title: "Event deleted successfully", duration: 10000 });
    },
    onError: (error) => {
      toast({ 
        title: "Failed to delete event", 
        description: error?.response?.data?.error || 'An error occurred',
        variant: "destructive",
        duration: 10000
      });
    }
  });

  const handlePrevious = () => {
    if (view === "day") setCurrentDate(subDays(currentDate, 1));
    else if (view === "week") setCurrentDate(subWeeks(currentDate, 1));
    else setCurrentDate(subMonths(currentDate, 1));
  };

  const handleNext = () => {
    if (view === "day") setCurrentDate(addDays(currentDate, 1));
    else if (view === "week") setCurrentDate(addWeeks(currentDate, 1));
    else setCurrentDate(addMonths(currentDate, 1));
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  const handleCreateEvent = () => {
    setSelectedEvent(null);
    const now = new Date();
    setInitialDate(setMinutes(setHours(now, now.getHours() + 1), 0));
    setIsModalOpen(true);
  };

  const handleEventClick = (event) => {
    setSelectedEvent(event);
    setInitialDate(null);
    setIsModalOpen(true);
  };

  const handleTimeSlotClick = (time) => {
    setSelectedEvent(null);
    setInitialDate(time);
    setIsModalOpen(true);
  };

  const handleDateClick = (date) => {
    setCurrentDate(date);
    setView("day");
  };

  const handleSaveEvent = (eventData) => {
    if (eventData.id) {
      updateEventMutation.mutate({
        id: eventData.id,
        data: {
          title: eventData.title,
          description: eventData.description,
          start_time: eventData.start_time,
          end_time: eventData.end_time
        }
      });
    } else {
      createEventMutation.mutate(eventData);
    }
  };

  const handleEventDrop = (eventId, newStartTime, newEndTime) => {
    const event = events.find(e => e.id === eventId);
    if (!event) return;

    updateEventMutation.mutate(
      {
        id: eventId,
        data: {
          title: event.title,
          description: event.description,
          start_time: newStartTime,
          end_time: newEndTime
        }
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["events"] });
          toast({ title: "Event rescheduled successfully", duration: 10000 });
        }
      }
    );
  };

  const handleDeleteEvent = (id) => {
    deleteEventMutation.mutate(id);
  };

  return (
    <div className="h-screen flex flex-col bg-white overflow-hidden">
      <CalendarHeader
        currentDate={currentDate}
        view={view}
        onViewChange={setView}
        onPrevious={handlePrevious}
        onNext={handleNext}
        onToday={handleToday}
        onCreateEvent={handleCreateEvent}
      />

      <div className="flex-1 overflow-auto">
        {isLoading ? (
          <div className="h-full flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-[#20242d] border-t-transparent animate-spin" />
          </div>
        ) : (
          <>
            {view === "month" && (
              <MonthView
                currentDate={currentDate}
                events={events}
                onEventClick={handleEventClick}
                onDateClick={handleDateClick}
                onEventDrop={handleEventDrop}
              />
            )}
            {view === "week" && (
              <WeekView
                currentDate={currentDate}
                events={events}
                onEventClick={handleEventClick}
                onTimeSlotClick={handleTimeSlotClick}
                onEventDrop={handleEventDrop}
              />
            )}
            {view === "day" && (
              <DayView
                currentDate={currentDate}
                events={events}
                onEventClick={handleEventClick}
                onTimeSlotClick={handleTimeSlotClick}
                onEventDrop={handleEventDrop}
              />
            )}
          </>
        )}
      </div>

      <EventModal
        isOpen={isModalOpen}
        onClose={(open) => {
          if (!open) {
            setIsModalOpen(false);
            setSelectedEvent(null);
            setInitialDate(null);
          }
        }}
        event={selectedEvent}
        initialDate={initialDate}
        onSave={handleSaveEvent}
        onDelete={handleDeleteEvent}
      />
    </div>
  );
}